# Summary

This is a standalone repo that contains a hello world test demonstrating use of the Datagen library to program a 
Cambria test card and generate downstream and upstream PCIe traffic.

# Environment Requirements

* SVOS SUT
* Cambria-R card

# Build Instructions

* On build server, enter schroot "svos-buster" (needed for libsv dependencies)
* Navigate to top level of repo and run *make*
* Transfer *hello_world.out* to SUT and run with *./hello_world.out*

# Source Overview

## Hello World

**Description:** Simple test flow with examples of:
* PCIe downstream read and verify
* PCIe downstream write and verify
* PCIe upstream read and verify
* PCIe upstream write and verify

**Source files:**
* hello_world.*


## Datagen

**Description:** Library that provides object-oriented interface for building streams of vectors and writing these vectors to provided VM MMIO space.

**Source files:**
* include/cambria-datagen/*
* src/datagen.cpp
* src/cycles.cpp
* include/StandardRuntime/*
* include/cambria-registers/*
* include/pciexpress.h


## Cambria Card Representation

**Description:** Light classes providing organization and access to test card VMs, targets, and control/error registers.

**Source files:** 
* include/cambria.h
* src/cambria.cpp


## PCIe Device Discovery:

**Description:** Provides functions that take in VID/DID and search /sys/devices to find the associated device's BAR address. (Code based on abstract-pci.c in Breker repo, modified specifically for Cambria card discovery)

**Source files:**
* src/pcie_setup.cpp


## Memory Target Allocation

**Description:** Provides functions to allocate memory targets through SVOS. (Code taken unmodified from abstract-memalloc.c)

**Source files:**
* include/abstract.h
* src/abstract-memalloc.c
