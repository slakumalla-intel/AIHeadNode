#include <stdio.h>
#include <unistd.h>
#include <cstring>
#include "cambria-datagen/datagen.h"
#include "cambria.h"
#include "abstract.h"
#include "hello_world.h"

const uint16_t DEVICE_ID = 0x0D52;
const uint16_t VENDOR_ID = 0x8086;
const unsigned MAX_VECTORS = 32000;	// Calculated based on Cambria spec

int main() {
	abstract_pci_info_t *pcie_info;
	TrafficStream traffic(MAX_VECTORS);
	
	// Collect test card PCIe info from /sys/devices
	pcie_info = abstract_pci_info_get(VENDOR_ID, DEVICE_ID);
	
	if (!pcie_info) {
		printf("NULL pcie_info, failed.\n");
		return 1;
	}

	print_pcie_info(pcie_info);
	printf("\n");


	// Instantiate Cambria card object for Vector Machine (VM) and Virtual Target (VT) interactions
	CambriaCard card(pcie_info);


	// Downstream Read
	int bytesToRead = 16;
	int droffset = 0;
	uint8_t drbuf[bytesToRead];
	uint8_t drVerifyBuf[bytesToRead];
	int bytesRead = card.vt[0].Read(drbuf, droffset, bytesToRead);

	generateIncrementPattern(drVerifyBuf, bytesToRead, card.vt[0].targetBaseAddrPhys + droffset);

	printf("Verifying downstream read...\n");
	for (int i = 0; i < bytesToRead; i++) {
		unsigned char actual = drbuf[i];
		unsigned char expected = drVerifyBuf[i];
		printf("Byte %d | ", i);
		if (actual == expected)
			printf("MATCH    | Actual %x | Expected %x\n", actual, expected);
		else
			printf("MISMATCH | Actual %x | Expected %x\n", actual, expected);
	}
	printf("\n");


	// Downstream Write
	int bytesToWrite = 4;
	int dwoffset = 0;
	uint8_t dwVerifyBuf[bytesToWrite];
	generateIncrementPattern(dwVerifyBuf, bytesToWrite, card.vt[0].targetBaseAddrPhys + dwoffset);

	int bytesWritten = card.vt[0].Write(dwVerifyBuf, dwoffset, bytesToWrite);

	printf("Verifying downstream write...\n");
	if (card.vt[0].DidWriteError()) {
		printf("Downstream write failed\n");
		card.vt[0].LogErrors();
	}
	else
		printf("Downstream write passed\n");

	printf("\n");


	// Upstream Read
	int urlength = 8; // Bytes
	int uralignment = 0;
	void *urvirt = abstract_memalloc(urlength, MEM_WB, uralignment);	// Allocate memory for card to target
	void *urphys = abstract_memalloc_virt_to_phys(urvirt);

	generateIncrementPattern(((uint8_t *) urvirt), urlength, (uint64_t) urphys);	// Load memory target with expected data

	MemReadVector *r = static_cast<MemReadVector *>(traffic.AddCycle(new MemReadVector(urlength/4)));	// Convert read length from bytes to dwords
	r->SetAddress((uint64_t) urphys);	// Test card targets physical address


	// Upstream Write
	int uwlength = 8;
	int uwalignment = 0;
	void *uwvirt = abstract_memalloc(urlength, MEM_WB, uralignment);	// Allocate memory for card to target
	void *uwphys = abstract_memalloc_virt_to_phys(uwvirt);
	memset(uwvirt, 0, uwlength);

	MemWriteVector *w = static_cast<MemWriteVector *>(traffic.AddCycle(new MemWriteVector(uwlength/4)));	// Convert write length from bytes to dwords
	w->SetAddress((uint64_t) uwphys);	// Test card targets physical address
	w->SetEnd();	// Last vector in stream


	// Send vectors to card, run Vector Machine 0
	traffic.Serialize((uint32_t*) card.vm[0].bufferBaseAddr);
	card.vm[0].Enable();
	card.vm[0].Start();

	if (card.vm[0].PollUntilDone())
		printf("Card completed successfully.\n");
	else
		printf("Timed out waiting for completion.\n");
	
	printf("\n");

	// Verify Upstream Read
	printf("Verifying upstream read...\n");

	if (card.vm[0].DidReadError()) {
		printf("Upstream read failed\n");
		card.vm[0].LogErrors();
	}
	else
		printf("Upstream read passed\n");
	
	printf("\n");
	

	// Verify Upstream Write
	printf("Verifying upstream write...\n");

	uint8_t uwVerifyBuf[uwlength];
	generateIncrementPattern(uwVerifyBuf, uwlength, (uint64_t) uwphys);

	for (int i = 0; i < uwlength; i++) {
		uint8_t actual = ((uint8_t *) uwvirt)[i];
		uint8_t expected = uwVerifyBuf[i];
		printf("Byte %d | ", i);
		if (actual == expected)
			printf("MATCH    | Actual %x | Expected %x\n", actual, expected);
		else
			printf("MISMATCH | Actual %x | Expected %x\n", actual, expected);
	}

	return 0;
}


void generateIncrementPattern(uint8_t *buf, int n, uint64_t addr) {
	const uint64_t mask1 = 0x3c0000;	// Addr[21:18]
	const uint64_t mask2 = 0x1ffc;		// Addr[12:2]
	const uint64_t mask3 = 0x1fffc;		// Addr[16:2]
	memset(buf, 0, n);
	for (int i = 0; i < n; i+=4) {
		uint32_t temp = 0;
		temp |= (addr & mask1) << 10;		  // D[31:28] = Addr[21:18]
		temp |= ((addr & mask2) | 0x2) << 15; // D[27:16] = Addr[12:2] & 1
		temp |= ((addr & mask3) >> 2) << 1;	  // D[15:0]  = Addr[16:2] & 0

		memcpy((buf + i), &temp, 4);
		addr += 4;
	}

	return;
}

