#ifndef __HELLOWORLD_H__
#define __HELLOWORLD_H__

#define ENV_LINUX
void print_pcie_info(abstract_pci_info_t *pcie_info);
void generateIncrementPattern(uint8_t *buf, int n, uint64_t addr);

#endif

