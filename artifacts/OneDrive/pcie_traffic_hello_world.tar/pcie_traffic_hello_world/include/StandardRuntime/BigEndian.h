/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2019 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
///
/// \file BigEndian.h
///
/// This file contains BigEndian data types
/// WARNING: This Library is under testing and is NOT ready for use.
///
#ifndef __BIG_ENDIAN_H__
#define __BIG_ENDIAN_H__

#include <stdint.h>

/// Swap the bytes of 16, 32, or 64 bit literals
template <typename T> T SwapBytes(T value);

// Big-endian template class
template <typename T> class BigEndian
{
	/// This data is stored in big-endian format so DMA consumers see it properly
	T m_data;

public:
	/// C-tor: default - no initializer - do nothing
	BigEndian() {}

	/// C-tor: copy - copy the data preserving the big-endian format
	BigEndian(const BigEndian &d) : m_data(d.m_data) {}

	/// C-tor: little-endian initializer - swap the bytes before storing in the structure
	BigEndian(T d) : m_data(SwapBytes<T>(d)) {}

	/// Run-time Assignment: assign to BigEndian object - preserve format
	BigEndian &operator=(const BigEndian &d)
	{
		if (&d != this) {
			m_data = d.m_data;
		}
		return *this;
	}

	/// Run-time Assignment: assign to BigEndian object - preserve format
	volatile BigEndian &operator=(volatile BigEndian &d) volatile
	{
		if (&d != this) {
			m_data = d.m_data;
		}
		return *this;
	}

	/// Run-time Assignment: assign literal to BigEndian object need to swap format
	volatile BigEndian &operator=(const T &d) volatile
	{
		m_data = SwapBytes<T>(d);
		return *this;
	}

	/// Run-time Cast: to little-endian - swap bytes with BSWAP
	operator T() const { return SwapBytes<T>(m_data); }

	/// Run-time Cast: to little-endian - swap bytes with BSWAP
	operator T() const volatile { return SwapBytes<T>(m_data); }
};

template <> inline uint16_t maestro::SwapBytes<uint16_t>(uint16_t data) { return __builtin_bswap16(data); }

template <> inline uint32_t maestro::SwapBytes<uint32_t>(uint32_t data) { return __builtin_bswap32(data); }

template <> inline uint64_t maestro::SwapBytes<uint64_t>(uint64_t data) { return __builtin_bswap64(data); }

template <> inline int16_t maestro::SwapBytes<int16_t>(int16_t data) { return __builtin_bswap16(data); }

template <> inline int32_t maestro::SwapBytes<int32_t>(int32_t data) { return __builtin_bswap32(data); }

template <> inline int64_t maestro::SwapBytes<int64_t>(int64_t data) { return __builtin_bswap64(data); }

#endif // __BIG_ENDIAN_H__
