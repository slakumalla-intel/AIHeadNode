#ifndef __ABSTRACT_MEMALLOC_H__
#define __ABSTRACT_MEMALLOC_H__

static void *svos_alloc(size_t length, int flags, size_t alignment);
void *svos_alloc_virt_to_phys(void *virt);

#endif
