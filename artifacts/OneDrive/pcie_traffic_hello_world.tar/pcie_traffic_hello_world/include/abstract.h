/*******************************************************************************
********************************************************************************
***                                                                           **
***                           INTEL CONFIDENTIAL                              **
***                                                                           **
***                  Copyright (c) 2021 Intel Corporation.                    **
***                           All Rights Reserved.                            **
***                                                                           **
***  The source code contained or described herein and all documents related  **
***  to the source code ("Material") are owned by Intel Corporation or its    **
***  suppliers or licensors.  Title to the Material remains with Intel        **
***  Corporation or its suppliers and licensors.  The Material contains trade **
***  secrets and proprietary and confidential information of Intel or its     **
***  suppliers and licensors.  The Material is protected by worldwide         **
***  copyright and trade secret laws and treaty provisions. No part of the    **
***  Material may be used, copied, reproduced, modified, published, uploaded, **
***  posted, transmitted, distributed, or disclosed in any way without        **
***  Intel's prior express written permission.                                **
***                                                                           **
***  No license under any patent, copyright, trade secret or other            **
***  intellectual property right is granted to or conferred upon you by       **
***  disclosure or delivery of the Materials, either expressly, by            **
***  implication, inducement, estoppel or otherwise.  Any license under such  **
***  intellectual property rights must be express and approved by Intel in    **
***  writing.                                                                 **
***                                                                           **
********************************************************************************
******** 10 ****** 20 ****** 30 ****** 40 ****** 50 ****** 60 ****** 70 *******/

#ifndef ABSTRACT_H
#define ABSTRACT_H

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#ifdef __cplusplus
extern "C" {
#endif

#include <stddef.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include <linux/membarrier.h>
#include <time.h>
#include <errno.h>


#define MEM_UC  (0x00000001)	/* Uncached */
#define MEM_WB	(0x00000002)	/* Write back */
#define MEM_WC	(0x00000003)	/* Write combining */
#define MEM_WT	(0x00000004)	/* Write through */
#define MEM_WP	(0x00000005)	/* Write protect */

typedef struct abstract_pci_addr {
	bool writable;
	uint64_t size;
	uint64_t phys_addr;
	void *virt_addr_uc;
	void *virt_addr;
} abstract_pci_addr_t;

const int MAX_BARS = 6;

typedef struct abstract_pci_info {
	char *path;			/* PCI /sysfs path name */
	char *config_path;		/* PCI config sysfs path */
	uint16_t  vendor_id;		/* PCI Vendor ID */
	uint16_t  device_id;		/* PCI Device ID */
	uint8_t cfg_bus;
	uint8_t cfg_dev;
	uint8_t cfg_func;
	abstract_pci_addr_t cfg;	/* Config space */
	abstract_pci_addr_t bar[6];	/* BAR 0..5 */
	struct abstract_pci_info	*next;	/* next in list */
} abstract_pci_info_t;

typedef int (*abstract_func_t)(void *arg);

extern bool abstract_thread_should_terminate(void);
extern int abstract_thread_create(void **handle, const int cpu,
	const int policy, const int prio, const size_t stack_size,
	abstract_func_t func, void *arg);
extern int abstract_thread_join(void *handle);
extern int abstract_thread_signal(void *handle);
extern int abstract_thread_force_kill(void *handle);
extern int abstract_thread_terminate(void *handle);
extern int abstract_thread_free(void *handle);
extern int abstract_thread_set_terminate_handler(void *handle,
	void (*handler)(void *data), void *data);
extern int abstract_thread_id(void *handle);
extern int abstract_getcpu(unsigned int *cpu, unsigned int *node);
extern int abstract_set_affinity(void *handle, const int cpu);

/*
 *   thread synchronization
 */
extern int abstract_sync_destroy(void **handle);
extern int abstract_sync_create(void **handle);
extern int abstract_sync_wait(void **handle);
extern int abstract_sync_broadcast(void **handle, int waiters);

extern void *abstract_memalloc(size_t length, int flags, size_t alignment);
extern void *abstract_memalloc_phys(void *phys, size_t length, int flags, size_t alignment);
extern int abstract_memfree(void *addr, size_t length);
extern void *abstract_memalloc_virt_to_phys(void *virt);

/*
 *  Backtracing
 */
extern void abstract_fault_catch(void);
extern void abstract_print_backtrace(void);

/*
 *   MSR read/write
 */
extern int abstract_rdmsr(const int cpu, const uint32_t msr, uint64_t *data);
extern int abstract_wrmsr(const int cpu, const uint32_t msr, uint64_t data);

/*
 *   PCI
 */

extern uint64_t abstract_virt_to_phys(const void *addr);
extern abstract_pci_info_t *abstract_pci_info_get(const uint16_t vendor_id, const uint16_t device_id);

/*
 *   Misc PMON shims
 */
static inline uint64_t simutils_read_msr(const uint32_t msr)
{
	uint64_t data;
	unsigned int cpu, node;

	if (abstract_getcpu(&cpu, &node) < 0) {
		data = ~(uint64_t)0;
	} else {
		int ret;
		ret = abstract_rdmsr((int)cpu, msr, &data);
		if (ret < 0) {
			data = ~(uint64_t)0;
			(void)fprintf(stderr, "rdmsr %" PRIx32 " -> %" PRIx64 "\n", msr, data);
		}
	}
	return data;
}

static inline void simutils_write_msr(const uint32_t msr, const uint64_t data)
{
	unsigned int cpu, node;

	if (abstract_getcpu(&cpu, &node) == 0 ) {
		int ret;

		ret = abstract_wrmsr((int)cpu, msr, data);
		if (ret < 0)
			(void)fprintf(stderr, "wrmsr %" PRIx32 " %" PRIx64 " -> %d\n", msr, data, ret);
	}
}

/*
 *  pmon_config_barrier_sync()
 *  	pmon helper, barrier sync via mfence and membarrier system call
 */
static inline void pmon_config_barrier_sync(void)
{
	__asm__ __volatile__("mfence" :::);
#if defined(__NR_membarrier)
	int ret;

	ret = syscall(__NR_membarrier, MEMBARRIER_CMD_GLOBAL, 0, 0);

	(void)ret;
#endif
}

extern uint64_t mem_read(const uint64_t addr, const uint64_t offset, const size_t size);
extern void mem_write(const uint64_t addr, const uint64_t offset, const size_t size, const uint64_t value);

static inline void abstract_delay_ns(const uint64_t ns)
{
	struct timespec req, rem;
	uint64_t ns_left = ns;

	while (ns_left != 0) {
		req.tv_sec = ns / 1000000000;
		req.tv_nsec = ns % 1000000000;

		(void)memset(&rem, 0, sizeof(rem));
		if (nanosleep(&req, &rem) == 0)
			break;
		if (errno == EINTR) {
			uint64_t ns_rem;

			ns_rem = (rem.tv_sec * 1000000000) +
				 rem.tv_nsec;
			if (ns_left < ns_rem)
				break;
			ns_left -= ns_rem;
		}
	}
}

#ifdef __cplusplus
}
#endif

#endif
