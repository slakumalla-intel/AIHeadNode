/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2022 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details This file defines the CambriaCycle classes

#ifndef __CAMBRIA_CYCLES_H__
#define __CAMBRIA_CYCLES_H__

#include "cambria-datagen/format.h"
#include "pciexpress.h"
#include <vector>

enum class VectorType : unsigned {
	Reserved = 0x0,
	Pause,
	LoopCommand,
	InternalAccess,
	Delay,
	PciInterrupt,
	UpperAddress,
	PowerManagement,
	MemoryRead,
	MemoryWrite,
	IoRead,
	IoWrite,
	ConfigRead,
	ConfigWrite,
	Message,
	MsiInterrupt,
	Prefix = 0x16,
	Enqueue = 0x19,
};

enum class AtomicOpType : unsigned {
	Reserved = 0x0,
	FetchAdd,
	Swap,
	CAS,
};

enum class Granularity : unsigned { _8nsPerTick = 0, _1usPerTick, _1msPerTick, _1secPerTick };

enum class EndBit : unsigned { On = 0, Off };

enum class LockBit : unsigned { On = 0, Off };

enum class Retrigger : unsigned { On = 0, Off };

enum class BusMasterOverride : unsigned { On = 0, Off };

class CambriaCycle
{
protected:
	VectorFormat m_format;
	unsigned m_offset = 0;

	CambriaCycle(const VectorType type) {
	       	m_format.dword0 = static_cast<unsigned>(type);
		m_format.dword1 = 0;
	        m_format.dword2 = 0;
	        m_format.dword3 = 0;
	}
public:
	virtual ~CambriaCycle() {}
	virtual int GetCount() = 0;
	virtual void LogCycle();

	// Serialize takes base pointer and current offset so vectors needing fixups can use EmbedPointer
	virtual void Serialize(VectorFormat *base, unsigned *offset);

	unsigned GetOffset() { return m_offset; }
};

class PauseVector : public CambriaCycle
{
private:
	PauseFormat *m_pause = reinterpret_cast<PauseFormat *>(&m_format);

public:
	enum PauseType {
		PauseNone = 0x0,
		TaggedVector = 0x1,
		IntFlagWrite = 0x2,
		ExtFlagWrite = 0x4,
		ExtTriggerIn = 0x8,
		VMSync = 0x10,
		VectorSentLinkLayer = 0x20
	};

	enum PmPauseType {
		PmPauseNone = 0x0,
		PmWakeDelayTimerExpire = 0x2,
		PmActiveStateNakMsgTlpRcvd = 0x10,
		PmTurnOffMsgTlpRcvdInD3 = 0x20,
		PmPmeStatus = 0x40,
		NonD0State = 0x200,
		D0State = 0x400,
		TxL0s = 0x800,
		CplToSend = 0x1000,
		ErrMsgToSend = 0x2000,
		ValidDSateChangeInNonD0 = 0x4000,
		ValidNoDStateChangeInNonD0 = 0x8000
	};

	enum PmPauseType2 {
		PmPause2None = 0x0,
		Recovery = 0x1,
		NotRecovery = 0x2,
		L1Idle = 0x4,
		NotL1Idle = 0x8,
		L2Idle = 0x10,
		NotL2Idle = 0x20,
		RecoveryEntry = 0x40,
		L0 = 0x80,
	};

	friend PauseType operator|(PauseType a, PauseType b) { return (PauseType)((int)a | (int)b); }
	friend PmPauseType operator|(PmPauseType a, PmPauseType b) { return (PmPauseType)((int)a | (int)b); }
	friend PmPauseType2 operator|(PmPauseType2 a, PmPauseType2 b) { return (PmPauseType2)((int)a | (int)b); }

	PauseVector() : CambriaCycle(VectorType::Pause) {}
	PauseVector(enum PauseVector::PauseType pauseType,
	    enum PauseVector::PmPauseType pmPauseType = PmPauseType::PmPauseNone,
	    enum PauseVector::PmPauseType2 pmPauseType2 = PmPauseType2::PmPause2None, uint16_t delay = 0,
	    Granularity gran = Granularity::_8nsPerTick);
	virtual ~PauseVector() {}

	void SetPauseType(enum PauseType type) { m_pause->pauseType = type; }
	void SetPmPauseType(enum PmPauseType type) { m_pause->pmPauseType = type; }
	void SetPmPauseType2(enum PmPauseType2 type) { m_pause->pmPauseType2 = type; }
	void SetDelay(uint16_t count, Granularity gran);
	void SetWaitVmEmpty() { m_pause->waitVMEmpty = 1; }
	void SetWaitAllVmEmpty() { m_pause->waitAllVMEmpty = 1; }

	virtual int GetCount() override { return 1; }
};

class LoopVector : public CambriaCycle
{
private:
	LoopCommandFormat *m_loop = reinterpret_cast<LoopCommandFormat *>(&m_format);

public:
	LoopVector() : CambriaCycle(VectorType::LoopCommand) {}
	virtual ~LoopVector() {}

	void SetCount(uint8_t count) { m_loop->loopCount = count; }
	void SetCommand() { m_loop->lc = 1; }
	void SetEnd() { m_loop->end = 1; }

	virtual int GetCount() override { return 1; }
};

class LoopStart : public LoopVector
{
public:
	LoopStart(uint8_t count);
	virtual ~LoopStart() {}
};

class LoopEnd : public LoopVector
{
public:
	LoopEnd();
	virtual ~LoopEnd() {}
};

class SinglePollLoopStart : public LoopVector
{
public:
	SinglePollLoopStart();
	virtual ~SinglePollLoopStart() {}
};

class SinglePollLoopEnd : public LoopVector
{
public:
	SinglePollLoopEnd();
	virtual ~SinglePollLoopEnd() {}
};

class InternalAccess : public CambriaCycle
{
private:
	InternalAccessFormat *m_internalaccess = reinterpret_cast<InternalAccessFormat *>(&m_format);

public:
	InternalAccess() : CambriaCycle(VectorType::InternalAccess) {}
	virtual ~InternalAccess() {}

	enum ByteEnable {
		FIRST = 0xE,  /*1110b - First*/
		SECOND = 0xD, /*1101b - Second*/
		THIRD = 0xB,  /*1011b - Third*/
		LAST = 0x7,   /*0111b - Last*/
		ALL = ((uint8_t)FIRST & (uint8_t)SECOND & (uint8_t)THIRD & (uint8_t)LAST)
	};

	enum class Command : unsigned {
		WriteToEVBuff = 0x0,
		WriteToReg,
		IntSinglePollNotSticky,
		ReadEVToLocalSticky = 0x4,
		ReadEVToGlobalSticky,
		ReadCfgRegToLocalSticky,
		ReadCfgRegToGlobalSticky,
		WriteToEVFromLocalSticky,
		WriteToEVFromGlobalSticky,
		WriteToCfgFromLocalSticky,
		WriteToCfgFromGlobalSticky,
		InternalSinglePollLocalSticky,
		InternalSinglePollGlobalSticky,
	};

	// Not an enum class so multiple can be combined
	enum SinglePollType {
		NoPoll = 0,
		Internal = 0x1,
		PMEStatusZero = 0x2,
		InD0 = 0x4,
		NotInD0 = 0x8,
		PMETurnOff = 0x10,
	};
	friend SinglePollType operator|(SinglePollType a, SinglePollType b) { return (SinglePollType)((int)a | (int)b); }

	void ProgramCommandA(unsigned offset, uint32_t data, uint8_t be, LockBit lock = LockBit::Off,
	    Retrigger retrigger = Retrigger::Off, EndBit endbit = EndBit::Off);
	void ProgramCommandB(unsigned offset, uint32_t data, uint8_t be, LockBit lock = LockBit::Off,
	    Retrigger retrigger = Retrigger::Off, EndBit endbit = EndBit::Off);

	// Addr should be dword aligned
	void SetAddressA(unsigned addr);
	void SetAddressB(unsigned addr);

	void SetAddressRange() { m_internalaccess->ar = 1; }

	void SetByteEnablesA(uint8_t be) { m_internalaccess->beA = be; }
	void SetByteEnablesB(uint8_t be) { m_internalaccess->beB = be; }
	void SetLockA() { m_internalaccess->aLock = 1; }
	void SetLockB() { m_internalaccess->bLock = 1; }
	void SetEndA() { m_internalaccess->endA = 1; }
	void SetEndB() { m_internalaccess->endB = 1; }
	void SetRetriggerA() { m_internalaccess->ta = 1; }
	void SetRetriggerB() { m_internalaccess->tb = 1; }
	void SetCmd(Command cmd);
	void SetDataA(uint32_t value) { m_internalaccess->data = value; }
	void SetDataB(uint32_t value);
	void SetSinglePoll(enum SinglePollType type);

	virtual int GetCount() override { return 1; }
};

class DummyVector : public InternalAccess
{
public:
	DummyVector(uint32_t data, LockBit lock = LockBit::On, EndBit endbit = EndBit::Off);
	virtual ~DummyVector() {}
};

class IntAccessWriteReg : public InternalAccess
{
public:
	IntAccessWriteReg();
	IntAccessWriteReg(unsigned offset, uint32_t data, uint8_t be, LockBit lock = LockBit::Off,
	    Retrigger retrigger = Retrigger::Off, EndBit endbit = EndBit::Off);
	virtual ~IntAccessWriteReg() {}
};

class SetRegisterBits : public InternalAccess
{
public:
	SetRegisterBits(unsigned offset, uint32_t mask, LockBit lock = LockBit::Off, EndBit endbit = EndBit::Off);
	virtual ~SetRegisterBits() {}
};

class SetRegisterBit : public InternalAccess
{
public:
	SetRegisterBit(unsigned offset, uint32_t bitpos, LockBit lock = LockBit::Off, EndBit endbit = EndBit::Off);
	virtual ~SetRegisterBit() {}
};

class ClearRegisterBit : public InternalAccess
{
public:
	ClearRegisterBit(unsigned offset, uint32_t bitpos, LockBit lock = LockBit::Off, EndBit endbit = EndBit::Off);
	virtual ~ClearRegisterBit() {}
};

class ReadCfgToSticky : public InternalAccess
{
public:
	ReadCfgToSticky(unsigned offset, uint8_t be = 0, LockBit lock = LockBit::On);
	virtual ~ReadCfgToSticky() {}
};

class WriteCfgFromSticky : public InternalAccess
{
public:
	WriteCfgFromSticky(unsigned offset, uint8_t be = 0, LockBit lock = LockBit::On);
	virtual ~WriteCfgFromSticky() {}
};

class PollSingle : public InternalAccess
{
public:
	PollSingle(enum SinglePollType type);
	virtual ~PollSingle() {}
};

class PollSingleLocalSticky : public InternalAccess
{
public:
	PollSingleLocalSticky(uint32_t value, uint32_t mask);
	virtual ~PollSingleLocalSticky() {}
};

class DelayVector : public CambriaCycle
{
private:
	DelayFormat *m_delay = reinterpret_cast<DelayFormat *>(&m_format);

public:
	DelayVector(uint16_t count = 0, Granularity gran = Granularity::_8nsPerTick, uint16_t signal = 0);
	virtual ~DelayVector() {}

	void SetDelay(uint16_t count, Granularity gran);
	void SetSignal(uint16_t signal);

	virtual int GetCount() override { return 1; }
};
/*
class PciInterruptVector : public CambriaCycle
{
private:
    PciInterruptFormat *m_intx = reinterpret_cast<PciInterruptFormat *>(&m_format);

public:
    enum class Pin : unsigned {
        Reserved = 0x0,
        IntA = 0x1,
        IntB = 0x2,
        IntC = 0x4,
        IntD = 0x8,
    };

    PciInterruptVector() : CambriaCycle(VectorType::PciInterrupt) {}
    virtual ~PciInterruptVector() {}
    virtual int GetCount() override { return 1; }

    void SetInterruptId(unsigned id) { m_intx->intrId = id; }
    void SetPin(enum Pin pin) { m_intx->intrPin = static_cast<unsigned>(pin); }
    enum Pin GetPin() { return static_cast<Pin>(m_intx->intrPin); }
};
*/
class UpperAddressVector : public CambriaCycle
{
private:
	UpperAddressFormat *m_upperaddress = reinterpret_cast<UpperAddressFormat *>(&m_format);

public:
	enum class TransactionError : unsigned {
		NoError = 0x0,
		UndefinedTlpFmtType = 0x2,
		IoCfgReqLenOfWrDataExceedsMaxPayload = 0x3,
		TlpSpans4kBoundaryOrLenNotEqualData = 0x4,
		UnmappedTcPassesToForceMalformed = 0x5,
		FirstAndLastByteEnableChange = 0x6,
		TdInverted = 0x7,
		Upper3BitsTagChangeValueMalformed = 0x8,
		Upper3BitsTagChangeValue = 0x9,
	};

	UpperAddressVector() : CambriaCycle(VectorType::UpperAddress){};
	virtual ~UpperAddressVector() {}

	void SetHighAddress(uint32_t address) { m_upperaddress->address = address; }

	void SetAtomicOp(AtomicOpType opType) { m_upperaddress->atomOpType = static_cast<unsigned>(opType); }
	AtomicOpType GetAtomicOp() { return static_cast<AtomicOpType>(m_upperaddress->atomOpType); }
	void SetAtomicIndex(unsigned index) { m_upperaddress->atomIdx = index; }
	unsigned GetAtomicIndex() { return m_upperaddress->atomIdx; }
	virtual int GetCount() override { return 1; }
	virtual void LogCycle() override;

	void SetAltRouting(const uint8_t bus, const uint8_t number);
	void SetRequestorId(unsigned busNum, unsigned devNum, unsigned funcNum);
	void SetPostedTag(unsigned tag) { m_upperaddress->postedtag = tag & 0x1F; }
	void SetNoDataCompare() { m_upperaddress->nc = 1; }
	void SetPattGenAddr(uint16_t pattGenAddr) { m_upperaddress->pattGenAddr = pattGenAddr & 0x3FF; }
	void SetBusNum(uint8_t busnum) { m_upperaddress->busNum = busnum; }
	void SetDeviceNum(uint8_t devnum) { m_upperaddress->devNum = devnum & 0x1f; }
	void SetFunctionNum(uint8_t funcnum) { m_upperaddress->funcNum = funcnum & 0x7; }
	void SetTlErrorType(TransactionError tlErr) { m_upperaddress->tlErrType = static_cast<unsigned>(tlErr); }
	void SetTlSideband(unsigned data) { m_upperaddress->tlErrSideband = data & 0xfff; }
	void SetVectorSent() { m_upperaddress->vs = 1; }
	bool IsAtomicCycle() { return m_upperaddress->atomOpType ? true : false; }
};

class PMVector : public CambriaCycle
{
private:
	PowerFormat *m_power = reinterpret_cast<PowerFormat *>(&m_format);

public:
	enum class Command : unsigned {
		EnterL1 = 0x1,
		ExitL1 = 0x2,
		GenericSuperLock = 0x3,
		EnterL2L3 = 0x4,
		PciPmSuperLock = 0x5,
		ExitL2L3 = 0x6,
		AspmSuperLock = 0x7,
		ClearPmActvStateNakCnt = 0x8,
		AssertWakebPin = 0x9,
		ClrPMReqAckCnt = 0xA,
		ClrExtInputPauseCnt = 0xB,
		SendSkpOrderedSet = 0xC,
		UnfrzCounters = 0xD,
		ClrErrRecovEntryCnt = 0xE,
	};

	PMVector(PMVector::Command cmd, LockBit lock = LockBit::Off, BusMasterOverride bmo = BusMasterOverride::Off);
	virtual ~PMVector() {}

	void SetCommand(Command command) { m_power->pmCmd = static_cast<unsigned>(command); }
	void SetLock() { m_power->ll = 1; }
	void SetEnd() { m_power->end = 1; }

	void SetBusMasterOverride() { m_power->bo = 0x1; }

	virtual int GetCount() override { return 1; }
};

class AspmSuperLock : public PMVector
{
public:
	AspmSuperLock(bool enter, EndBit endbit = EndBit::Off);
	virtual ~AspmSuperLock() {}
};

class GenericSuperLock : public PMVector
{
public:
	GenericSuperLock(bool enter, EndBit endbit = EndBit::Off);
	virtual ~GenericSuperLock() {}
};

class PciPmSuperLock : public PMVector
{
public:
	PciPmSuperLock(bool enter, EndBit endbit = EndBit::Off);
	virtual ~PciPmSuperLock() {}
};

class MemoryVector : public CambriaCycle
{
protected:
	MemoryVectorFormat *m_memory = reinterpret_cast<MemoryVectorFormat *>(&m_format);
	UpperAddressVector m_upperAddr;
	unsigned m_sizeInBytes = 0;

	enum class NextFeatures : unsigned { Constant = 0x0, Increment, Decrement };
	enum class NextByteEnable : unsigned { Constant = 0x0, Increment, Shift, Invert };
	enum class DataPattern : unsigned { Increment = 0x0, ROL, Analog, ROI };

public:
	MemoryVector(const VectorType type, unsigned length) : CambriaCycle(type), m_upperAddr() { SetLength(length); }
	virtual ~MemoryVector() {}

	VectorType GetType() { return static_cast<VectorType>(m_memory->vectorType); }
	UpperAddressVector &GetUpperAddress() { return m_upperAddr; }

	unsigned GetSizeInBytes() { return m_sizeInBytes; }

	virtual void LogCycle() override;

	virtual void SetLength(unsigned len);
	virtual unsigned GetLength() { return m_memory->length + 1; } // Convert back from Cambria encoding
	void SetZeroLength() { m_memory->z = 1; };
	unsigned GetZeroLength() { return m_memory->z; }

	void SetAddress(uint64_t address);
	void SetLowAddress(uint32_t address) { m_memory->address = (address >> 2); }

	void SetDataPattern(DataPattern dpat) { m_memory->dpat = static_cast<unsigned>(dpat); }
	DataPattern GetDataPattern() { return static_cast<DataPattern>(m_memory->dpat); }

	void SetTrafficClass(unsigned tc) { m_memory->tc = tc; }
	void SetNoSnoop() { m_memory->s = 1; }
	bool GetNoSnoop() { return (m_memory->s == 1) ? true : false; }
	void SetOrdering() { m_memory->o = 1; }
	void SetDigest() { m_memory->td = 1; }
	void SetPoison() { m_memory->ep = 1; }
	void Set64BitAddress() { m_memory->addr64 = 1; }
	void SetWaitCount(unsigned wait) { m_memory->wc = wait; }
	unsigned GetWaitCount() { return m_memory->wc; }
	void SetAddressTranslation(unsigned at) { m_memory->at = at; }
	unsigned GetAddressTranslation() { return m_memory->at; }

	void SetAltRouting(const uint8_t bus, const uint8_t number);

	void SetFirstBE(unsigned firstBE) { m_memory->firstDWBE = ~(firstBE & 0xF); } // Cambria uses inverse of pcie spec
	unsigned GetFirstBE() { return ~m_memory->firstDWBE & 0xF; }

	void SetLastBE(unsigned lastBE) { m_memory->lastDWBE = ~(lastBE & 0xF); } // Cambria uses inverse of pcie spec
	unsigned GetLastBE() { return ~m_memory->lastDWBE & 0xF; }

	void SetTag() { m_memory->t = 1; }
	void ClearTag() { m_memory->t = 0; }
	void SetEnd() { m_memory->end = 1; }

	void SetLockFirst() { m_memory->lf = 1; }
	void SetLockLast() { m_memory->ll = 1; }

	void CalcTotalTransferLength();

	unsigned GetRepeat() { return m_memory->repeat1; }
	void SetRepeat(unsigned count) { m_memory->repeat1 = count; }
	unsigned GetAddressAdvance() { return m_memory->addrAdv; }
	void SetAddressAdvance(unsigned advance) { m_memory->addrAdv = advance; }
	unsigned GetNextLength() { return m_memory->nl; }
	void SetNextLength(unsigned next) { m_memory->nl = next; }
	unsigned GetNextAddressAdvance() { return m_memory->naa; }
	void SetNextAddressAdvance(unsigned next) { m_memory->naa = next; }
	unsigned GetNextWaitCount() { return m_memory->nwc; }
	void SetNextWaitCount(unsigned next) { m_memory->nwc = next; }
	unsigned GetNextFDBE() { return m_memory->nbef; }
	void SetNextFDBE(unsigned next);
	unsigned GetNextLDBE() { return m_memory->nbel; }
	void SetNextLDBE(unsigned next);

	void UpdateNextFeatures(unsigned r, uint8_t &fbe, uint8_t &lbe, unsigned &addrAdv, unsigned &length);
	void UpdateNextAddressAdvance(unsigned &addrAdv);
	void UpdateNextLength(unsigned &length);
	void UpdateNextFBE(unsigned r, uint8_t &fbe);
	void UpdateNextLBE(unsigned r, uint8_t &lbe);

	virtual int GetCount() override { return 2; } // Include Upper Address
	virtual void Serialize(VectorFormat *base, unsigned *offset) override;
};

class MemReadVector : public MemoryVector
{
public:
	MemReadVector(unsigned length) : MemoryVector(VectorType::MemoryRead, length){};
	virtual ~MemReadVector() {}
};

class MemWriteVector : public MemoryVector
{
public:
	MemWriteVector(unsigned length) : MemoryVector(VectorType::MemoryWrite, length){};
	virtual ~MemWriteVector() {}
};

struct AtomicData {
	union {
		struct {
			uint64_t m_LowerData;
			uint64_t m_UpperData;
		};
		uint32_t dwords[4];
	} m_data;

	AtomicData();
	AtomicData(uint64_t lowerData, uint64_t upperData);
};

class AtomicVector : public MemReadVector
{
private:
	AtomicData m_operand;
	AtomicData m_compare;
	AtomicData m_verify;
	std::vector<CambriaCycle *> m_sequence;
	PauseVector m_pauseOnTag;

	void CreateSequence(unsigned lengthInDwords);
	void CalculateVerify(unsigned lengthInDwords);

public:
	AtomicVector(const AtomicOpType type, const unsigned length, const AtomicData &operand, const AtomicData &compare);
	virtual ~AtomicVector();

	virtual void SetLength(unsigned len) override;
	virtual unsigned GetLength() override;

	void SetAtomicOp(AtomicOpType opType) { m_upperAddr.SetAtomicOp(opType); }
	AtomicOpType GetAtomicOp() { return m_upperAddr.GetAtomicOp(); }
	void SetAtomicIndex(unsigned index) { m_upperAddr.SetAtomicIndex(index); }
	unsigned GetAtomicIndex() { return m_upperAddr.GetAtomicIndex(); }
	bool IsAtomicCycle() { return m_upperAddr.IsAtomicCycle(); }

	AtomicData &GetOperand() { return m_operand; }
	AtomicData &GetCompare() { return m_compare; }
	AtomicData &GetVerify() { return m_verify; }

	virtual int GetCount() override;
	virtual void Serialize(VectorFormat *base, unsigned *offset) override;

	void ClearByteEnables()
	{ // Byte Enables are rsvd for atomics
		m_memory->firstDWBE = 0;
		m_memory->lastDWBE = 0;
	}
};

class IoVector : public CambriaCycle
{
private:
	IoVectorFormat *m_io = reinterpret_cast<IoVectorFormat *>(&m_format);

public:
	IoVector(const VectorType type);
	virtual ~IoVector() {}

	void SetAddress(unsigned address) { m_io->address = (address >> 2); }

	void SetFirstBE(unsigned firstBE) { m_io->firstDWBE = ~(firstBE & 0xF); } // Cambria uses inverse of pcie spec
	unsigned GetFirstBE() { return ~m_io->firstDWBE & 0xF; }

	virtual int GetCount() override { return 1; }
};

class IoReadVector : public IoVector
{
public:
	IoReadVector() : IoVector(VectorType::IoRead) {}
	virtual ~IoReadVector() {}
};

class IoWriteVector : public IoVector
{
public:
	IoWriteVector() : IoVector(VectorType::IoWrite) {}
	virtual ~IoWriteVector() {}
};

class ConfigVector : public CambriaCycle
{
private:
	ConfigVectorFormat *m_config = reinterpret_cast<ConfigVectorFormat *>(&m_format);

public:
	ConfigVector(const VectorType type, unsigned bus, unsigned device, unsigned function, unsigned offset);
	virtual ~ConfigVector() {}

	void SetBus(unsigned bus) { m_config->busNum = bus; }
	void SetDevice(unsigned device) { m_config->deviceNum = device; }
	void SetFunction(unsigned function) { m_config->funcNum = function; }
	void SetOffset(unsigned offset);

	virtual int GetCount() override { return 1; }
};

class ConfigReadVector : public ConfigVector
{
public:
	ConfigReadVector(unsigned bus, unsigned device, unsigned function, unsigned offset)
	    : ConfigVector(VectorType::ConfigRead, bus, device, function, offset)
	{
	}
	virtual ~ConfigReadVector() {}
};

class ConfigWriteVector : public ConfigVector
{
public:
	ConfigWriteVector(unsigned bus, unsigned device, unsigned function, unsigned offset)
	    : ConfigVector(VectorType::ConfigWrite, bus, device, function, offset)
	{
	}
	virtual ~ConfigWriteVector() {}
};

class MessageVector : public CambriaCycle
{
private:
	MessageFormat *m_message = reinterpret_cast<MessageFormat *>(&m_format);
	UpperAddressVector *m_upperAddr = nullptr; // Used to optionally inject posted tag

public:
	MessageVector(const MsgCode code, const enum MsgRoute route, LockBit lock = LockBit::Off,
	    BusMasterOverride bmo = BusMasterOverride::Off);
	virtual ~MessageVector();
	virtual void Serialize(VectorFormat *base, unsigned *offset) override;

	UpperAddressVector *GetOrCreateUpperAddress();

	uint8_t GetCode() { return m_message->msgCode; }
	void SetCode(uint8_t code) { m_message->msgCode = code; }
	void SetCode(MsgCode code) { m_message->msgCode = static_cast<unsigned>(code); }
	MsgRoute GetRoute();
	void SetRoute(enum MsgRoute route);
	void SetWithData() { m_message->d = 1; }
	bool IsVDM();
	void SetDestinationID(uint16_t id);
	void SetVendorID(uint16_t id);
	void SetVendorDef(uint32_t def);
	void SetTrafficClass(unsigned tc) { m_message->tc = tc; }
	unsigned GetTrafficClass() { return m_message->tc; }
	void SetNoSnoop() { m_message->s = 1; }
	void SetOrdering() { m_message->o = 1; }
	void SetDigest() { m_message->td = 1; }
	void SetPoison() { m_message->ep = 1; }
	void SetLength(unsigned len);
	void SetDataPattern(unsigned pattern) { m_message->dpat = pattern; }
	void SetLock() { m_message->ll = 1; }
	void SetWaitCount(unsigned wait) { m_message->wc = wait; }
	void SetMP() { m_message->mp = 1; }
	void SetHeaderDword2(uint32_t dword2) { m_message->upperAddr = dword2; }
	void SetHeaderDword3(uint32_t dword3);
	uint32_t GetHeaderDword2() { return m_message->upperAddr; };
	void SetBusMasterOverride() { m_message->busMasterOverride = 0x1; }
	void SetAddressTranslation(unsigned at) { m_message->at = at; }

	virtual int GetCount() override { return (m_upperAddr == nullptr) ? 1 : 2; }
};

class LtrMessageVector : public MessageVector
{
public:
	struct LtrFormat {
		uint16_t m_value : 10;
		uint16_t m_scale : 3;
		uint16_t m_reserved : 2;
		uint16_t m_required : 1;
	};
	struct LtrFields {
		union {
			struct {
				LtrFormat m_SnoopLatency;
				LtrFormat m_NoSnoopLatency;
			} fields;
			uint32_t val = 0;
		};
	};

	LtrMessageVector(uint32_t ltrVal);
	virtual ~LtrMessageVector() {}
};

class MctpMessageVector : public MessageVector
{
private:
	static const uint16_t VendorIdDmtfVdms = 0x1AB4; // Vendor ID for DMTF VDMs
	static const uint8_t MctpHdrVer = 0x1;

public:
	struct MctpTransportHeader {
		uint8_t rsvd4 : 4;
		uint8_t hdrVer : 4;
		uint8_t dstEpId : 8;
		uint8_t srcEpId : 8;
		uint8_t som : 1;
		uint8_t eom : 1;
		uint8_t pkgSeqNum : 2;
		uint8_t tagOwner : 1;
		uint8_t msgTag : 3;
	};
	MctpMessageVector(const enum MsgRoute route);
	virtual ~MctpMessageVector() {}

	void SetPciTargetId(uint16_t target, MsgRoute route);

	void SetMctpTransportHeader(
	    uint8_t dstEpId, uint8_t srcEpId, uint8_t som, uint8_t eom, uint8_t pktSeqNum, uint8_t to, uint8_t msgTag);
};

/*
class MsiInterruptVector : public CambriaCycle
{
private:
    MsiInterruptFormat *m_msi = reinterpret_cast<MsiInterruptFormat *>(&m_format);

public:
    MsiInterruptVector() : CambriaCycle(VectorType::MsiInterrupt) {}
    virtual ~MsiInterruptVector() {}

    virtual int GetCount() override { return 1; }

    void SetAddress(uint64_t address) { m_msi->address = (address >> 2); }
    void SetData(uint64_t data) { m_msi->msiData = data; }
};
*/

#endif // __CAMBRIA_CYCLES_H__
