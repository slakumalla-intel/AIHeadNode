/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2021 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details This file defines the CambriaDataGen classes

#ifndef __CAMBRIA_DATAGEN_H__
#define __CAMBRIA_DATAGEN_H__

#include "cambria-datagen/cycles.h"
#include <vector>

/// \brief Responsible for data generation for a single Cambria VM.
class Stream
{
private:
	std::vector<CambriaCycle *> m_cycles{};
	const unsigned m_maxVectors = 0;
	unsigned m_numVectors = 0;

protected:
	unsigned m_vm = 0;
	unsigned m_stream = 0;

public:
	Stream(unsigned maxVectors);
	virtual ~Stream();

	void SetVmNumber(unsigned num) { m_vm = num; }
	void SetStreamNumber(unsigned num) { m_stream = num; }

	virtual void Generate() = 0;
	void Serialize(uint32_t *buffer);

	bool HasCycles() { return !m_cycles.empty(); }
	unsigned VectorCount() { return m_numVectors; }
	CambriaCycle *AddCycle(CambriaCycle *cyc, bool checkSpace = true);
	bool CheckSpace(unsigned count);
};

class TrafficStream : public Stream
{
private:
public:
	TrafficStream(unsigned maxVectors);
	virtual ~TrafficStream() {}

	virtual void Generate() override {}
};

class EventStream : public Stream
{
private:
	bool PortTrace = false;
	bool CreditCheck = false;

protected:
	// Default is VM 0 Stream 0.
	unsigned TrafficVM = 0;
	unsigned TrafficStream = 0;

	bool AssertClkReq = false;
	uint16_t ClkReqAssertDelayCount = 2;
	Granularity ClkReqAssertDelayGran = Granularity::_1msPerTick;
	uint16_t ClkReqDeassertDelayCount = 2;
	Granularity ClkReqDeassertDelayGran = Granularity::_1msPerTick;

public:
	EventStream(unsigned maxVectors);
	virtual ~EventStream() {}

	enum class ErrorKind { EnableBitslip = 0x1, DisableBitslip = 0x2, EnableBadEIdle = 0x4, DisableBadEIdle = 0x8 };

	void SetTrafficVM(unsigned vm) { TrafficVM = vm; }
	void SetTrafficStream(unsigned stream) { TrafficStream = stream; }

	void SetPortTrace(bool val) { PortTrace = val; }
	bool GetPortTrace() { return PortTrace; }
	void SetCreditCheck(bool val) { CreditCheck = val; }
	bool GetCreditCheck() { return CreditCheck; }

	void SetAssertClkReq(bool val) { AssertClkReq = val; }
	void SetClkReqAssertDelayCount(uint16_t count) { ClkReqAssertDelayCount = count; }
	void SetClkReqAssertDelayGran(Granularity gran) { ClkReqAssertDelayGran = gran; }
	void SetClkReqDeassertDelayCount(uint16_t count) { ClkReqDeassertDelayCount = count; }
	void SetClkReqDeassertDelayGran(Granularity gran) { ClkReqDeassertDelayGran = gran; }

	void ClearEventStatus();
	void InsertPollForLTSSM(uint32_t linkState, uint32_t mask = 0xFF00FFFF);
	void InsertDebugVectors(uint8_t value);
	void DisableTxL0s();
	void RestoreTxL0s();
	void InsertSwitchToLocalClock();
	void InsertSwitchToSlotClock();
	void InsertDeassertClockReq();
	void InsertAssertClockReq();
	void InsertErrorInjectSequence(ErrorKind kind);
	void TagVectorSent();
};

class ActiveL1TransitionEvent : public EventStream
{
private:
	bool GuaranteedHostExit = false;
	bool GuaranteedDevExit = false;
	bool ExitFromAspmL1Timer = true;
	uint16_t ExitPauseCount = 1;
	Granularity ExitPauseGran = Granularity::_1usPerTick;

	void _createWakePause();

public:
	ActiveL1TransitionEvent(unsigned vm, unsigned maxVectors);
	virtual ~ActiveL1TransitionEvent() {}

	virtual void Generate() override;

	void SetGuaranteedHostExit(bool val) { GuaranteedHostExit = val; }
	void SetGuaranteedDevExit(bool val) { GuaranteedDevExit = val; }
	void SetExitFromAspmL1Timer(bool val) { ExitFromAspmL1Timer = val; }
	void SetExitTimerPauseCount(uint16_t count) { ExitPauseCount = count; }
	void SetExitTimerPauseGran(Granularity gran) { ExitPauseGran = gran; }
};

class PciPmBaseEvent : public EventStream
{
private:
	uint16_t PmeResendTimerCount = 0;
	Granularity PmeResendTimerGran = Granularity::_1usPerTick;

protected:
	PciPmBaseEvent(unsigned maxVectors);
	virtual ~PciPmBaseEvent() {}

	void _DoPmeMessaging();

public:
	void PmeResendTimerPauseCount(uint16_t count) { PmeResendTimerCount = count; }
	uint16_t PmeResendTimerPauseCount() { return PmeResendTimerCount; }
	void PmeResendTimerPauseGran(Granularity gran) { PmeResendTimerGran = gran; }
	Granularity PmeResendTimerPauseGran() { return PmeResendTimerGran; }
};

class PciPmL1BaseEvent : public PciPmBaseEvent
{
private:
	bool RequestReentry = true;
	uint16_t StallL1DStateCount = 0;
	Granularity StallL1DStateGran = Granularity::_8nsPerTick;
	uint16_t PmeTimerCount = 0;
	Granularity PmeTimerGran = Granularity::_8nsPerTick;

protected:
	PciPmL1BaseEvent(unsigned maxVectors);
	virtual ~PciPmL1BaseEvent() {}

	void _EnterL1();

public:
	void RequestReentryToL1(bool request) { RequestReentry = request; }
	bool RequestReentryToL1() { return RequestReentry; }
	void StallL1DStatePauseCount(uint16_t count) { StallL1DStateCount = count; }
	uint16_t StallL1DStatePauseCount() { return StallL1DStateCount; }
	void StallL1DStatePauseGran(Granularity gran) { StallL1DStateGran = gran; }
	Granularity StallL1DStatePauseGran() { return StallL1DStateGran; }
	void PmeTimerPauseCount(uint16_t count) { PmeTimerCount = count; }
	uint16_t PmeTimerPauseCount() { return PmeTimerCount; }
	void PmeTimerPauseGran(Granularity gran) { PmeTimerGran = gran; }
	Granularity PmeTimerPauseGran() { return PmeTimerGran; }
};

class PciPmL1TransitionEvent : public PciPmL1BaseEvent
{
private:
	unsigned RetrigStream = 2;
	uint16_t RetrigTimer = 0xFFFF;

public:
	PciPmL1TransitionEvent(unsigned maxVectors);
	virtual ~PciPmL1TransitionEvent() {}

	virtual void Generate() override;

	void RetriggerStream(unsigned stream) { RetrigStream = stream; }
	unsigned RetriggerStream() { return RetrigStream; }
	void RetriggerTimer(uint16_t timer) { RetrigTimer = timer; }
	bool RetriggerTimer() { return RetrigTimer; }
};

class PciPmL1RetrigEvent : public PciPmL1BaseEvent
{
public:
	PciPmL1RetrigEvent(unsigned maxVectors);
	virtual ~PciPmL1RetrigEvent() {}

	virtual void Generate() override;
};

class PciPmL23TransitionEvent : public PciPmBaseEvent
{
private:
	bool EnterL1InsteadOfL23 = false;
	uint16_t StallL23DStateCount = 0;
	Granularity StallL23DStateGran = Granularity::_8nsPerTick;
	uint16_t WakeTimerCount = 0;
	Granularity WakeTimerGran = Granularity::_8nsPerTick;

public:
	PciPmL23TransitionEvent(unsigned maxVectors);
	virtual ~PciPmL23TransitionEvent() {}

	virtual void Generate() override;

	void SetEnterL1InsteadOfL23() { EnterL1InsteadOfL23 = true; }
	void StallL23DStatePauseCount(uint16_t count) { StallL23DStateCount = count; }
	uint16_t StallL23DStatePauseCount() { return StallL23DStateCount; }
	void StallL23DStatePauseGran(Granularity gran) { StallL23DStateGran = gran; }
	Granularity StallL23DStatePauseGran() { return StallL23DStateGran; }
	void WakeTimerPauseCount(uint16_t count) { WakeTimerCount = count; }
	uint16_t WakeTimerPauseCount() { return WakeTimerCount; }
	void WakeTimerPauseGran(Granularity gran) { WakeTimerGran = gran; }
	Granularity WakeTimerPauseGran() { return WakeTimerGran; }
};

#endif // __CAMBRIA_DATAGEN_H__
