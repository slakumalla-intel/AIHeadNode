/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2020 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details This file defines the Arden vector formats

#ifndef __CAMBRIA_FORMAT_H__
#define __CAMBRIA_FORMAT_H__

#include <stdint.h>

// forward declaration
class CambriaVector;

struct VectorFormat {
	uint32_t dword0 = 0;
	uint32_t dword1 = 0;
	uint32_t dword2 = 0;
	uint32_t dword3 = 0;
};

struct PauseFormat {
	uint32_t vectorType : 5;  // Vector Type
	uint32_t : 1;             // Reserved
	uint32_t end : 1;         // E Bit for last or not-last vector
	uint32_t : 1;             // Reserved
	uint32_t gran : 2;        // Wake delay count granularity
	uint32_t : 6;             // Reserved
	uint32_t delayCount : 16; // Wake delay count for use with PM wake delay

	uint32_t pauseType : 6;       // Generic pause type
	uint32_t waitAllVMEmpty : 1;  // Wait until all VMs are empty
	uint32_t waitVMEmpty : 1;     // Wait until VM is empty
	uint32_t extInPauseType : 16; // Pause waiting for a specific EXT-INPUT signal state (see spec)
	uint32_t pmPauseType2 : 8;    // Power management pause types

	uint32_t pmPauseType : 16;  // Power management pause types
	uint32_t tlpPauseType : 16; // Vendor-specific message TLP pause types

	uint32_t vmSync : 6; // VM sync for VM 0-5 (see spec)
	uint32_t : 26;       // Reserved
};

struct LoopCommandFormat {
	uint32_t vectorType : 5; // vector type
	uint32_t : 1;            // Reserved
	uint32_t end : 1;        // end (0=single pool loop end; 1=loop start
	uint32_t : 9;            // Reserved
	uint32_t loopCount : 8;  // iteration count value (0=single poll; 1-255=loop count)
	uint32_t : 8;            // Reserved

	uint32_t : 15;   // Reserved
	uint32_t lc : 1; // Loop Command (0=loop start, 1=loop end)
	uint32_t : 16;   // Reserved

	uint32_t : 32; // Reserved

	uint32_t : 32; // Reserved
};

struct InternalAccessFormat {
	uint32_t vectorType : 5;  // Vector Type
	uint32_t endB : 1;        // End Bit for command B
	uint32_t endA : 1;        // E Bit for last or not-last vector (for command A)
	uint32_t bLock : 1;       // Lock bit for command B
	uint32_t aLock : 1;       // Lock bit for command A
	uint32_t a16 : 1;         // Address for A command [16]
	uint32_t b16 : 1;         // Address for B command [16]
	uint32_t ar : 1;          // Address Range (RNR)
	uint32_t n1 : 1;          // PM active state Nack received
	uint32_t ps : 1;          // PME status is zero
	uint32_t to : 1;          // PM turn off message received
	uint32_t ip : 1;          // Internal single poll loop flag
	uint32_t bdataLower : 16; // Data for B command lower word

	uint32_t cmd : 4;         // Internal access command
	uint32_t beA : 4;         // byte enable for writes for Command A
	uint32_t beB : 4;         // byte enable for writes for Command B
	uint32_t s0 : 1;          // single poll on single poll 0 message
	uint32_t s1 : 1;          // single poll on single poll 1 message
	uint32_t s2 : 1;          // single poll on single poll 2 message
	uint32_t s3 : 1;          // single poll on single poll 3 message
	uint32_t bdataUpper : 16; // Data for B command upper word
	uint32_t ta : 1;          // Command A- Start retrigger timer
	uint32_t dx : 1;          // Single poll on NOT D0 state
	uint32_t address : 14;    // Address for A command [15:2]

	uint32_t tb : 1;        // Command B - Start retrigger timer
	uint32_t d0 : 1;        // Single poll on D0 state
	uint32_t bAddress : 14; // Address for B command [15:2]

	uint32_t data; // data for internal write for A command
};

struct DelayFormat {
	uint32_t vectorType : 5;  // Vector Type
	uint32_t : 1;             // Reserved
	uint32_t end : 1;         // E Bit for last or not-last vector
	uint32_t : 1;             // Reserved
	uint32_t gran : 2;        // granularity
	uint32_t : 2;             // Reserved
	uint32_t trigOut : 4;     // Trig out pulse width
	uint32_t delayCount : 16; // Delay Count (0 is no delay)

	union {
		struct {
			uint16_t d0 : 1; // ext out data  0
			uint16_t v0 : 1; // ext out valid 0
			uint16_t d1 : 1; // ext out data  1
			uint16_t v1 : 1; // ext out valid 1
			uint16_t d2 : 1; // ext out data  2
			uint16_t v2 : 1; // ext out valid 2
			uint16_t d3 : 1; // ext out data  3
			uint16_t v3 : 1; // ext out valid 3
			uint16_t d4 : 1; // ext out data  4
			uint16_t v4 : 1; // ext out valid 4
			uint16_t d5 : 1; // ext out data  5
			uint16_t v5 : 1; // ext out valid 5
			uint16_t d6 : 1; // ext out data  6
			uint16_t v6 : 1; // ext out valid 6
			uint16_t td : 1; // trig out data 7
			uint16_t tv : 1; // trig out valid 7
		} bit;
		uint16_t signal : 16;
	} extSignal;

	uint16_t : 16; // Reserved
	uint32_t : 32; // Reserved
	uint32_t : 32; // Reserved
};

struct PciInterruptFormat {
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t e : 1;          // E Bit for last or not-last vector
	uint32_t : 9;            // Reserved
	uint32_t ph : 2;         // Processing hint
	uint32_t at : 2;         // Address Type
	uint32_t ln : 1;         // Lightweight notification
	uint32_t id : 1;         // ID based ordering
	uint32_t t8 : 1;         // Tag bit 8
	uint32_t t9 : 1;         // Tag bit 9
	uint32_t : 8;            // Reserved
	uint32_t : 4;            // Reserved
	uint32_t intrPin : 4;    // Interrupt pin (PCI)
	uint32_t intrId : 5;     // Interrupt ID to ident source of intr
	uint32_t tc : 3;         // Traffic Class
	uint32_t a : 1;          // Assert Message override
	uint32_t s : 1;          // snoop attribute
	uint32_t o : 1;          // order attribute
	uint32_t : 1;            // Reserved

	// Duarte New Prop
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.
	uint32_t : 11;                  // Reserved

	uint32_t ep : 1;          // see PCI Express Spec
	uint32_t td : 1;          // see PCI Express Spec
	uint32_t swAddress1 : 30; // sw usable
	uint32_t swAddress2;      // sw usable
};

struct UpperAddressFormat {
	// Dword0
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t end : 1;        // E Bit for last or not-last vector
	uint32_t : 1;            // Reserved
	uint32_t busNum : 8;     // Bus number if it needs to be varied
	uint32_t : 6;            // Reserved
	uint32_t vs : 1;         // Vector sent to link layer
	uint32_t : 1;            // Reserved
	uint32_t postedtag : 5;  // tag value for posted write TLP requests
	uint32_t st0 : 3;        // [2:0] Steering tag table select

	// Dword1
	uint32_t tsIndex : 3;      // time stamp index
	uint32_t oo : 1;           // OBFF override
	uint32_t tsCmd : 4;        // time stamp command
	uint32_t funcNum : 3;      // Function number if it needs to be varied
	uint32_t devNum : 5;       // Device number if it needs to be varied
	uint32_t pattGenAddr : 11; // Address for pattern generation
	uint32_t : 1;              // Reserved
	uint32_t atomIdx : 3;      // Atomic data index select
	uint32_t st1 : 1;          // [3] Steering tag table select

	// Dword2
	uint32_t : 12;               // Reserved
	uint32_t tlErrType : 4;      // tl error type encoding
	uint32_t tlErrSideband : 12; // tl error sideband data
	uint32_t atomOpType : 2;     // Atomic operation type
	uint32_t tph : 1;            // TLP processing hint
	uint32_t nc : 1;             // No data compare

	// Dword3
	uint32_t address; // upper address
};

struct PowerFormat {
	uint32_t vectorType : 5; // vector type
	uint32_t : 1;            // Reserved
	uint32_t end : 1;        // end (0=not last vector in stream; 1=last vector in stream)
	uint32_t : 1;            // Reserved
	uint32_t ll : 1;         // Lock Last (0=disable arbiter lock; 1=lock the arbiter to this VM at vector end)
	uint32_t res2 : 23;      // Reserved

	uint32_t pmCmd : 5; // power management command
	uint32_t : 15;      // Reserved
	uint32_t bo : 1;    // bus master override
	uint32_t : 11;      // Reserved

	uint32_t : 32;
};

struct MemoryVectorFormat {
	// Dword 0
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t end : 1;        // E Bit for last or not-last vector
	uint32_t lf : 1;         // LF - lock first
	uint32_t ll : 1;         // LL - lock last
	uint32_t diff0 : 3;      //
	uint32_t t : 1;          // tag for pause event release
	uint32_t diff1 : 3;      //
	uint32_t ph : 2;         // Processing hint
	uint32_t at : 2;         // Address Type
	uint32_t ln : 1;         // Lightweight notification
	uint32_t id : 1;         // ID based ordering
	uint32_t t8 : 1;         // Tag bit 8
	uint32_t t9 : 1;         // Tag bit 9
	uint32_t repeat1 : 8;    // repeat vector R1 times
	// Dword 1
	uint32_t firstDWBE : 4;         // First DW BE
	uint32_t lastDWBE : 4;          // Last DW BE
	uint32_t reqID : 1;             // Derive Requestor ID from Upper address vect
	uint32_t pattGenrAddr : 1;      // Generate data based on Upper address vector
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.
	uint32_t diff2 : 1;             //
	uint32_t z : 1;                 // zero length cycle
	uint32_t tc : 3;                // Transaction class
	uint32_t lm : 1;                // Loop Modification
	uint32_t s : 1;                 // snoop attribute
	uint32_t o : 1;                 // order attribute
	uint32_t nl : 2;                // next length
	uint32_t addr64 : 1;            // 64 Bit address size indicator bit
	uint32_t diff3 : 1;             //
	uint32_t : 1;                   // Reserved
	uint32_t wc : 6;                // wait count - clks to delay vect req at the arb
	uint32_t nwc : 2;               // next wait count
	// Dword2
	uint32_t ep : 1;       // see PCI Express Spec
	uint32_t td : 1;       // see PCI Express Spec
	uint32_t address : 30; // target address
	// Dword3
	uint32_t nbef : 2;     // next byte enable first
	uint32_t nbel : 2;     // next byte enable last
	uint32_t naa : 2;      // next address advance
	uint32_t addrAdv : 10; // address advance
	uint32_t dpat : 2;     // data pattern
	uint32_t ndp : 2;      // next data pattern
	uint32_t length : 10;  // length in DWORDs
	uint32_t : 1;          // Reserved
	uint32_t tg : 1;       // TGEN hooks (reserved for A Step)
};

struct MemoryReadFormat {
	// Dword 0
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t end : 1;        // E Bit for last or not-last vector
	uint32_t lf : 1;         // LF - lock first
	uint32_t ll : 1;         // LL - lock last
	uint32_t tr : 2;         //
	uint32_t to : 1;         //
	uint32_t t : 1;          // tag for pause event release
	uint32_t p : 3;          //
	uint32_t ph : 2;         // Processing hint
	uint32_t at : 2;         // Address Type
	uint32_t ln : 1;         // Lightweight notification
	uint32_t id : 1;         // ID based ordering
	uint32_t t8 : 1;         // Tag bit 8
	uint32_t t9 : 1;         // Tag bit 9
	uint32_t repeat1 : 8;    // repeat vector R1 times
	// Dword 1
	uint32_t firstDWBE : 4;         // First DW BE
	uint32_t lastDWBE : 4;          // Last DW BE
	uint32_t reqID : 1;             // Derive Requestor ID from Upper address vect
	uint32_t pattGenrAddr : 1;      // Generate data based on Upper address vector
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.
	uint32_t lt : 1;                //
	uint32_t z : 1;                 // zero length cycle
	uint32_t tc : 3;                // Transaction class
	uint32_t lm : 1;                // Loop Modification
	uint32_t s : 1;                 // snoop attribute
	uint32_t o : 1;                 // order attribute
	uint32_t nl : 2;                // next length
	uint32_t addr64 : 1;            // 64 Bit address size indicator bit
	uint32_t lk : 1;                //
	uint32_t : 1;                   // Reserved
	uint32_t wc : 6;                // wait count - clks to delay vect req at the arb
	uint32_t nwc : 2;               // next wait count
	// Dword2
	uint32_t ep : 1;       // see PCI Express Spec
	uint32_t td : 1;       // see PCI Express Spec
	uint32_t address : 30; // target address
	// Dword3
	uint32_t nbef : 2;     // next byte enable first
	uint32_t nbel : 2;     // next byte enable last
	uint32_t naa : 2;      // next address advance
	uint32_t addrAdv : 10; // address advance
	uint32_t dpat : 2;     // data pattern
	uint32_t ndp : 2;      // next data pattern
	uint32_t length : 10;  // length in DWORDs
	uint32_t : 1;          // Reserved
	uint32_t tg : 1;       // TGEN hooks (reserved for A Step)
};

struct MemoryWriteFormat {
	// Dword 0
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t end : 1;        // E Bit for last or not-last vector
	uint32_t lf : 1;         // LF - lock first
	uint32_t ll : 1;         // LL - lock last
	uint32_t b : 1;          // byte count enable (writes) or zero length read (reads)
	uint32_t bcSel : 2;      // byte count select
	uint32_t : 1;            // tag for pause event release
	uint32_t : 3;            //
	uint32_t ph : 2;         // Processing hint
	uint32_t at : 2;         // Address Type
	uint32_t ln : 1;         // Lightweight notification
	uint32_t id : 1;         // ID based ordering
	uint32_t t8 : 1;         // Tag bit 8
	uint32_t t9 : 1;         // Tag bit 9
	uint32_t repeat1 : 8;    // repeat vector R1 times
	// Dword 1
	uint32_t firstDWBE : 4;         // First DW BE
	uint32_t lastDWBE : 4;          // Last DW BE
	uint32_t reqID : 1;             // Derive Requestor ID from Upper address vect
	uint32_t pattGenrAddr : 1;      // Generate data based on Upper address vector
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.
	uint32_t : 1;                   //
	uint32_t z : 1;                 // zero length cycle
	uint32_t tc : 3;                // Transaction class
	uint32_t lm : 1;                // Loop Modification
	uint32_t s : 1;                 // snoop attribute
	uint32_t o : 1;                 // order attribute
	uint32_t nl : 2;                // next length
	uint32_t addr64 : 1;            // 64 Bit address size indicator bit
	uint32_t : 2;                   // Reserved
	uint32_t wc : 6;                // wait count - clks to delay vect req at the arb
	uint32_t nwc : 2;               // next wait count
	// Dword2
	uint32_t ep : 1;       // see PCI Express Spec
	uint32_t td : 1;       // see PCI Express Spec
	uint32_t address : 30; // target address
	// Dword3
	uint32_t nbef : 2;     // next byte enable first
	uint32_t nbel : 2;     // next byte enable last
	uint32_t naa : 2;      // next address advance
	uint32_t addrAdv : 10; // address advance
	uint32_t dpat : 2;     // data pattern
	uint32_t ndp : 2;      // next data pattern
	uint32_t length : 10;  // length in DWORDs
	uint32_t : 1;          // Reserved
	uint32_t tg : 1;       // TGEN hooks (reserved for A Step)
};

// TODO :scrub fields
struct IoVectorFormat {
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t e : 1;          // E Bit for last or not-last vector
	uint32_t lf : 1;         // LF - lock first
	uint32_t ll : 1;         // LL - lock last
	uint32_t b : 1;          // byte count enable (writes) or zero length read (reads)
	uint32_t bcSel : 2;      // byte count select
	uint32_t t : 1;          // tag for pause event release
	uint32_t p : 1;          // poll
	uint32_t : 1;            // reserved
	uint32_t eu : 1;         // Update EV buffer (bypass auto-compare)
	uint32_t tlpDelay : 8;   // Inter packet delay
	uint32_t repeat1 : 8;    // repeat vector R1 times
	uint32_t firstDWBE : 4;  // First DW BE
	uint32_t : 4;            // Reserved

	// Duarte New prop
	uint32_t reqID : 1;             // Derive Requestor ID from Upper address vect
	uint32_t pattGenrAddr : 1;      // Generate data based on Upper address vector
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.

	uint32_t lt : 1;       // LT request bit
	uint32_t z : 1;        // zero length cycle
	uint32_t tc : 3;       // Transaction class
	uint32_t lm : 1;       // Loop Modification
	uint32_t s : 1;        // snoop attribute
	uint32_t o : 1;        // order attribute
	uint32_t : 4;          // Reserved
	uint32_t dl : 1;       // delay after last packet only
	uint32_t wc : 6;       // wait count - clks to delay vect req at the arb
	uint32_t nwc : 2;      // next wait count
	uint32_t ep : 1;       // see PCI Express Spec
	uint32_t td : 1;       // see PCI Express Spec
	uint32_t address : 30; // target address
	uint32_t nbef : 2;     // next byte enable first
	uint32_t : 14;         // Reserved
	uint32_t dpat : 2;     // data pattern
	uint32_t ndp : 2;      // next data pattern
	uint32_t : 11;         // Reserved
	uint32_t tg : 1;       // TGEN hooks (reserved for A Step)
};

// TODO :scrub fields
struct ConfigVectorFormat {
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t e : 1;          // E Bit for last or not-last vector
	uint32_t : 1;            // Reserved
	uint32_t ll : 1;         // LL - lock last
	uint32_t tr : 2;         // target range selector
	uint32_t to : 1;         // transaction ordering
	uint32_t t : 1;          // tag for pause event release
	uint32_t p : 1;          // poll
	uint32_t io : 1;         // IO Write request with custom data in DW3/ also is the uint8_t su:1;
	uint32_t eu : 1;         // Update EV buffer (bypass auto-compare)
	uint32_t tlpDelay : 8;   // Inter packet delay
	uint32_t : 8;            // Reserved
	uint32_t firstDWBE : 4;  // First DW BE
	uint32_t : 6;            // Reserved
	uint32_t tu : 1;         // Trusted configuration read request
	uint32_t lt : 1;         // LT request bit
	uint32_t z : 1;          // zero length cycle
	uint32_t tc : 3;         // Transaction class
	uint32_t : 1;            // Reserved
	uint32_t s : 1;          // snoop attribute
	uint32_t o : 1;          // order attribute
	uint32_t : 1;            // Reserved

	// Duarte New Prop
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.
	uint32_t : 1;                   // Reserved

	uint32_t tp : 1;             // Configuration Type selector
	uint32_t : 1;                // Reserved
	uint32_t wc : 6;             // wait count - clks to delay vect req at the arb
	uint32_t : 2;                // Reserved
	uint32_t ep : 1;             // see PCI Express Spec
	uint32_t td : 1;             // see PCI Express Spec
	uint32_t regNum : 6;         // Register Number
	uint32_t extRegAddr : 4;     // Extended PCI configuration Register number
	uint32_t evBufferVerify : 1; // Bit to enable EV buffer verify of config reads
	uint32_t : 3;                // Reserved
	uint32_t funcNum : 3;        // Function Number
	uint32_t deviceNum : 5;      // Device Number
	uint32_t busNum : 8;         // BusNumber
	uint32_t data;               // data for writes
};

struct MessageFormat {
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t end : 1;        // E Bit for last or not-last vector
	uint32_t : 1;            // Reserved
	uint32_t ll : 1;         // LL - lock last
	uint32_t : 3;            // Reserved
	uint32_t t : 1;          // tag for pause event release
	uint32_t : 1;            // reserved
	uint32_t mp : 1;         // Message Pattern Address
	uint32_t ri : 1;         //
	uint32_t ph : 2;         // Processing hint
	uint32_t at : 2;         // Address Type
	uint32_t ln : 1;         // Lightweight notification
	uint32_t id : 1;         // ID based ordering
	uint32_t t8 : 1;         // Tag bit 8
	uint32_t t9 : 1;         // Tag bit 9
	uint32_t msgCode : 8;    // Message Code (See PCI Express Spec for details)

	uint32_t length : 10;     // Length in DWORDS only applic. when D bit is set
	uint32_t route : 3;       // Message Routing Field
	uint32_t tc : 3;          // Traffic Class
	uint32_t d : 1;           // Message Vector Type
	uint32_t s : 1;           // snoop attribute
	uint32_t o : 1;           // order attribute
	uint32_t itag_vector : 1; // Indicates message is an itag vector

	// Duarte New Prop
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.
	uint32_t dpat : 3;              // data pattern

	uint32_t wc : 6;       // wait count - clks to delay vect req at the arb
	uint32_t addrLow : 2;  // address[1:0]
	uint32_t ep : 1;       // see PCI Express Spec
	uint32_t td : 1;       // see PCI Express Spec
	uint32_t address : 30; // Target Address
	uint32_t upperAddr;    // Upper Target Address
};

struct MsiInterruptFormat {
	uint32_t vectorType : 5; // Vector Type
	uint32_t : 1;            // Reserved
	uint32_t e : 1;          // E Bit for last or not-last vector
	uint32_t : 1;            // Reserved
	uint32_t ll : 1;         // LL - lock last
	uint32_t : 7;            // Reserved
	uint32_t ph : 2;         // Processing hint
	uint32_t at : 2;         // Address Type
	uint32_t ln : 1;         // Lightweight notification
	uint32_t id : 1;         // ID based ordering
	uint32_t t8 : 1;         // Tag bit 8
	uint32_t t9 : 1;         //  Tag bit 9
	uint32_t : 8;            // Reserved
	uint32_t firstDWBE : 4;  // First DW BE
	uint32_t : 2;            // Reserved
	uint32_t intrPin : 2;    // Interrupt Pin
	uint32_t intrId : 5;     // Interrupt ID
	uint32_t tc : 3;         // Traffic Class

	// Duarte New prop
	uint32_t reqID : 1; // Derive Requestor ID from Upper address vect

	uint32_t s : 1;  // snoop attribute
	uint32_t o : 1;  // order attribute
	uint32_t ds : 1; // Disable Status update

	// Duarte New Prop
	uint32_t busMasterOverride : 1; // Overide the bus Master enable bit.

	uint32_t addr64 : 1; // 64 Bit address size indicator bit

	uint32_t writeDataSource : 2; // Sticky Write Data Source
	uint32_t : 8;                 // Reserved
	uint32_t ep : 1;              // see PCI Express Spec
	uint32_t td : 1;              // see PCI Express Spec
	uint32_t address : 30;        // Target Address
	uint32_t msiData;             // MSI data
};

#endif // __CAMBRIA_FORMAT_H__
