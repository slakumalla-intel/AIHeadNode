/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2021 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/

/// \details     Contains register definitions for cambria_rnr_func0_cfg
/* RegFile Description: The Config and Status Registers for a Cambria Core
Physical Function n
Cambria Core FN0 Config Space */

#ifndef __CAMBRIA_RNR_FUNC0_CFG_REGS_H__
#define __CAMBRIA_RNR_FUNC0_CFG_REGS_H__

// #include "registeraccess/MaestroRegisterAccess.h" - STANDALONE
namespace cambria_rnr_func0_cfgFmt
{

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* PCI standard identification for Intel */
		uint16_t VID : 16;
	};
} FORMAT_0;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Cambria for PCIe */
		uint16_t DID : 16;
	};
} FORMAT_1;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0:	All of device's I/O space is disabled. All slave IO requests are treated as Unsupported Requests[br]
1:	Enable the I/O address range defined in the IOBASE and IOLIMIT registers */
		uint16_t IOE : 1;
		/* 0:	All of device's memory space is disabled. All slave memory requests are treated as Unsupported
Requests[br]
1:	Enable the memory address ranges defined in the MBASE and MLIMIT registers */
		uint16_t MSE : 1;
		/* 0:	This device is prevented from making memory or IO requests to its primary bus. Note that according to
PCI
Specification, as MSI interrupt messages are in-band memory writes, disabling the bus master enable bit prevents this
device from generating MSI interrupt messages[br]
1:	This device is allowed to issue requests to its primary bus. Completions for previously issued memory read
requests on the primary bus will be issued when the data is available[br]
This bit does not affect forwarding of Completions, Error Messages, nor PCI style Interrupts */
		uint16_t BME : 1;
		/* Not Applicable or Implemented. Hardwired to 0. */
		uint16_t SCE : 1;
		/* Not Applicable or Implemented. Hardwired to 0.  */
		uint16_t MWIE : 1;
		/* Not Applicable or Implemented. Hardwired to 0. */
		uint16_t VGAPS : 1;
		/* This bit controls the logging of poisoned TLPs in the Status Register */
		uint16_t PERRE : 1;
		/* Not Applicable or Implemented. Hardwired to 0. */
		uint16_t IDSEL : 1;
		/* This bit, when set, enables reporting of non-fatal and fatal errors detected by the device to the Root
		 * Complex. Note that errors are reported if enabled either through this bit or through the PCI-Express specific
		 * bits in the Device Control Register. */
		uint16_t SERRE : 1;
		/* Not Applicable or Implemented. Hardwired to 0. */
		uint16_t FB2B : 1;
		/* 0:	This device is permitted to generate INTx interrupt messages[br]
1:	This device is prevented from generating interrupt messages through registers or vectors.[br] Any INTx interrupts
already asserted are de-asserted when this bit is set, however, any status bits are not cleared. User must clear those
status bits before re-enabling the interrupts */
		uint16_t INTAD : 1;
		uint16_t RESV11 : 5;
	};
} FORMAT_2;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t RESV0 : 3;
		/*  Indicates that an interrupt message is pending internally to the device. Only PME and Hot Plug sources feed
into this status bit (not PCI INTA-INTD assert and deassert messages). The INTA Assertion Disable bit,
PCICMD1[lb]10[rb], has no effect on this bit.[br]
Note that INTA emulation interrupts received across the link are not reflected in this bit. */
		uint16_t INTS : 1;
		/*  Indicates that a capabilities list is present. Hardwired to 1. */
		uint16_t CAPL : 1;
		/*  Not Applicable or Implemented. Hardwired to 0. */
		uint16_t CAP66 : 1;
		uint16_t RESV6 : 1;
		/*  Not Applicable or Implemented. Hardwired to 0. */
		uint16_t FB2B : 1;
		/* If the Parity Error Response bit in the PCI Command register is set, this bit is set when a Poisoned
		 * Completion is received or a Poisoned Request is transmitted */
		uint16_t PMDPE : 1;
		/*  This device is not subtractively decoded on bus 0. This bit field is therefore hardwired to 00 to indicate
		 * that the device uses the fastest possible decode. */
		uint16_t DEVT : 2;
		/*  This bit is set when a completion with Completer Abort status is transmitted. */
		uint16_t STAS : 1;
		/* This bit is set when a completion with Completer Abort status */
		uint16_t RTAS : 1;
		/*  This bit is set when a completion with Unsupported Request status is received. */
		uint16_t RMAS : 1;
		/*  This bit is set when an ERR_FATAL or ERR_NONFATAL condition and the SERR Enable bit in the Command register
		 * is '1'. */
		uint16_t SSE : 1;
		/*  This bit is set when a poisoned TLP is received. */
		uint16_t DPE : 1;
	};
} FORMAT_3;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RID : 8;
		uint32_t PI : 8;
		uint32_t SUBCC : 8;
		uint32_t BCC : 8;
	};
} FORMAT_4;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* implemented for legacy compatibility purposes but has no effect on any PCI Express device behavior */
		uint32_t CLS : 8;
		/* does not apply to PCI Express */
		uint32_t LT : 8;
		/* Indicates that this is a multi-function device.  */
		uint32_t HTR : 8;
		/* Not Supported */
		uint32_t BIST : 8;
	};
} FORMAT_5;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MSI : 1;
		uint32_t BITDECODER : 2;
		/* This value is controlled by bit 23 of Prefetchability Control Register */
		uint32_t PREFETCH : 1;
		/* Hardwired to 2MB */
		uint32_t RS : 17;
		uint32_t BA : 11;
	};
} FORMAT_6;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t UBA : 32;
	};
} FORMAT_7;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* STRAP#13 | COMMENT[br]
00b,01b,10b | Request IO Space[br]
	11b | Will not Request IO Space */
		uint32_t IOSI : 1;
		uint32_t RESV1 : 1;
		/* 0, 256B, 512B, or 1024B */
		uint32_t RS256B : 6;
		/* STRAP#13 | ACCESS | COMMENT[br]
	10b | RW | Programmable Address for 256B[br]
00b,01b,11b | RO | None or 1024B or 512B */
		uint32_t RS512B : 1;
		/* STRAP#13 | ACCESS | COMMENT[br]
01b,10b	| RW | Programmable Address for 512B & 256B[br]
00b,11b	| RO | None or 1024B */
		uint32_t RS1024B : 1;
		/* STRAP#13 | ACCESS | COMMENT[br]
00b,01b,10b | RW | Programmable Address[br]
	11b | RO | Will not Request Space */
		uint32_t BA : 22;
	};
} FORMAT_8;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 32;
	};
} FORMAT_9;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MSI : 1;
		uint32_t RESV1 : 1;
		/* set by STRAP_BAR4_64 */
		uint32_t BITDECODE : 1;
		/* set by STRAP_BAR4_PREF */
		uint32_t PREFETCH : 1;
		/* Hardwired */
		uint32_t RS : 20;
		/* Resizable BAR Control Register settings control the size requested.[br]Resizable BAR Control Register[12:8] |
		   ACCESS | COMMENT[br]
		                        4 | RW | 16MB Request Size[br]
		                        5 | RO | 32MB Request Size */
		uint32_t BA1 : 1;
		uint32_t BA : 7;
	};
} FORMAT_10;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* The first capability in the list is the Subsystem ID and Subsystem Vendor ID Capability.  */
		uint8_t CAPPTR1 : 8;
	};
} FORMAT_12;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Used to communicate interrupt line routing information.  BIOS Requirement: POST software writes the routing
		 * information into this register as it initializes and configures the system. The value indicates to which
		 * input of the system interrupt controller this device's interrupt pin is connected. */
		uint8_t INTCON : 8;
	};
} FORMAT_13;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* STRAP #14	DEFAULT	INTERRUPT PIN[br]
xx	000	DISABLED[br]
00	001	INT A[br]
01	010	INT B[br]
10	011	INT C[br]
11	1xx	INT D */
		uint8_t INTPIN : 3;
		uint8_t RESV3 : 5;
	};
} FORMAT_14;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint8_t RESV0 : 8;
	};
} FORMAT_15;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates the PCI Express Capability structure. This field must return a Capability ID of 10h indicating that
		 * this is a PCI Express Capability structure */
		uint16_t CID : 8;
		/* This field contains the offset to the next PCI Capability structure */
		uint16_t PNC : 8;
	};
} FORMAT_17;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t PCIECV : 4;
		/* Indicates the specific type of this PCI Express Function[br]
  4'h0: PCI Express Endpoint[br]
  4'h1: Legacy PCI Express Endpoint[br]
  4'h4: Root Port (Stub)[br]
  4'h9: RCiEP */
		uint16_t DPT : 4;
		/* The PCI Express Link associated with this port is connected to a slot. */
		uint16_t SI : 1;
		/* This field indicates which MSI/MSI-X vector is used for the interrupt message generated in association with
any of the status bits of this Capability structure.[br]
Device does not automatically adjust the value in this register so it has been implemented as RW so software can update
the field with a proper value. */
		uint16_t IMN : 5;
		uint16_t RESV14 : 2;
	};
} FORMAT_18;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Value is determined by STRAP[br]
000b	128B[br]
001b	256B[br]
010b	512B */
		uint32_t MPSS : 3;
		/* No Function Number bits are used for Phantom Functions. Multi-Function Devices are permitted to implement up
		 * to 8 independent Functions. */
		uint32_t PFS : 2;
		/* Hardwired to indicate support for 8-bit Tags as a Requester.  */
		uint32_t ETFS : 1;
		/* This field indicates the acceptable total latency that an Endpoint can withstand due to the transition from
		 * L0s state to the L0 state. */
		uint32_t EL0AL : 3;
		/* This field indicates the acceptable latency that an Endpoint can withstand due to the transition from L1
		 * state to the L0 state. */
		uint32_t EL1AL : 3;
		/* Not Applicable or Implemented. Hardwired to 0. */
		uint32_t RESV12 : 3;
		/* Indicates that this device implements the functionality defined in the Error Reporting ECN as required by the
		 * PCI Express 1.1 spec. */
		uint32_t RBER : 1;
		/* When set indicates that the Function supports the ERR_COR Subclass field in ERR_COR Messages, allowing
		 * different subclasses to be distinguished */
		uint32_t ERRCORSC : 1;
		uint32_t RESV17 : 1;
		/* SET_SLOT_POWER_LIMIT message value will be captured but not used. */
		uint32_t CSPL1 : 8;
		/* SET_SLOT_POWER_LIMIT message value will be captured but not used. */
		uint32_t CSPL : 2;
		/* Not true FLR. Registers will not reset. Only incoming cycles will be discarded. */
		uint32_t FLRC : 1;
		/* Not Applicable or Implemented. Hardwired to 0. */
		uint32_t RESV29 : 3;
	};
} FORMAT_19;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When set, in conjunction with other bits, enables signaling of ERR_CORR messages. Note all these generated
		 * error messages will report Function Number 0 in the Requester ID field. */
		uint16_t CERE : 1;
		/* When set, in conjunction with other bits, enables signaling of ERR_NONFATAL  messages. Note all these
		 * generated error messages will report Function Number 0 in the Requester ID field. */
		uint16_t NERE : 1;
		/* When set, in conjunction with other bits, enables signaling of ERR_FATAL messages. Note all these generated
		 * error messages will report Function Number 0 in the Requester ID field. */
		uint16_t FERE : 1;
		/* When set, allows signaling ERR_NONFATAL, ERR_FATAL, or ERR_CORR to the Root Control register when detecting
		 * an unmasked Unsupported Request (UR).  An ERR_CORR is signaled when an unmasked Advisory Non-Fatal UR is
		 * received.  An ERR_FATAL or ERR_NONFATAL is sent to the Root Control register when an uncorrectable
		 * non-Advisory UR is received with the severity bit set in the Uncorrectable Error Severity register. */
		uint16_t URRE : 1;
		/* No associated functionality. Software should verify setting for legal vector programming. */
		uint16_t ERO : 1;
		/* This field sets maximum TLP payload size for the Function. As a Receiver, the Function must handle TLPs as
large as the set value. As a Transmitter, the Function must not generate TLPs exceeding the set value[br]
For this ARI Device, Max_Payload_Size is determined solely by the setting in Function 0. The settings in the other
Functions always return whatever value software programmed for each, but otherwise are ignored by the component.[br]
Defined encodings for this field are:[br]
000b: 128 bytes max payload size[br]
001b: 256 bytes max payload size[br]
010b: 512 bytes max payload size[br]
others: reserved */
		uint16_t MPS : 3;
		/* Enabling this does not automatically allow more than 32 NP requests outstanding. User must also set the
		 * Maximum Number of Outstanding Non-Posted Requests field to a larger value as well. */
		uint16_t ETFE : 1;
		/* Not supported */
		uint16_t PFE : 1;
		uint16_t AUXPPM : 1;
		/* No associated functionality. Controlled through vector programming. */
		uint16_t ENS : 1;
		/* 000 - 128B[br]
001 - 256B[br]
010 - 512B[br]
011 - 1024B[br]
100 - 2048B[br]
101 - 4096B[br]
Read requests will be split that the read request size is within this limit. This is a length based split meaning this
is not treated as an address boundary. For example: If the bits are programmed to 'b000', then a read request of size
130B is split into two smaller requests; first request of 128B and a second request of 2B. */
		uint16_t MRRS : 3;
		/* OPEN: Change to real? Note: This is not true FLR. Registers will not reset. Only incoming cycles will be
		 * discarded based on register settings.  The FLR will be applied to all functions concurrently. */
		uint16_t IFLR : 1;
	};
} FORMAT_20;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When set this bit indicates that correctable error(s) were detected. Errors are logged in this register
		 * regardless of whether error reporting is enabled or not in the Device Control register.   When Advanced Error
		 * Handling is enabled, errors are logged in this register regardless of the settings of the correctable error
		 * mask register. */
		uint16_t CED : 1;
		/* When set this bit indicates that non-fatal error(s) were detected. Errors are logged in this register
		 * regardless of whether error reporting is enabled or not in the Device Control register.   When Advanced Error
		 * Handling is enabled, errors are logged in this register regardless of the settings of the uncorrectable error
		 * mask register. */
		uint16_t NFED : 1;
		/* When set this bit indicates that fatal error(s) were detected. Errors are logged in this register regardless
		 * of whether error reporting is enabled or not in the Device Control register. When Advanced Error Handling is
		 * enabled, errors are logged in this register regardless of the settings of the uncorrectable error mask
		 * register.  */
		uint16_t FED : 1;
		/* When set this bit indicates that the Device received an Unsupported Request. Errors are logged in this
		 * register regardless of whether error reporting is enabled or not in the Device Control Register.
		 * Additionally, the Non-Fatal Error Detected bit or the Fatal Error Detected bit is set according to the
		 * setting of the Unsupported Request Error Severity bit. In production systems setting the Fatal Error Detected
		 * bit is not an option as support for AER will not be reported. */
		uint16_t URD : 1;
		uint16_t APD : 1;
		/* 0: All pending transactions (including completions for any outstanding non-posted requests on any used
virtual channel) have been completed.[br]
1: Indicates that the device has transaction(s) pending (including completions for any outstanding non-posted requests
for all used Traffic Classes). */
		uint16_t TP : 1;
		uint16_t EPRD : 1;
		uint16_t RESV7 : 9;
	};
} FORMAT_21;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* This field indicates the maximum Link speed of the associated Port.[br]
0001b	2.5 GT/s[br]
0010b	5.0 GT/s[br]
0011b	8.0 GT/s[br]
0100b	16.0 GT/s[br]

0101b	32.0 GT/s

Note: All other values are reserved. */
		uint32_t MLS : 4;
		/* Indicates the maximum number of lanes supported for this link.[br]
00 0001b	x1[br]
00 0010b	x2[br]
00 0100b	x4[br]
00 1000b	x8[br]
01 0000b	x16 */
		uint32_t MLW : 6;
		/* STRAP_L1SUP, STRAP_L0sSUP[br]
00  No ASPM Support[br]
01	L0s Supported[br]
10	L1 Supported[br]
11	L0s and L1 Supported */
		uint32_t ASPMSUP : 2;
		/* Indicates the length of time this Port requires to complete the transition from L0s to L0. This is not the
value which controls the actual latency. If L0s is not supported, the value is undefined.[br]
100b	Local clock source - Async clock mode[br]
011b	Clock from connector - Common clock mode */
		uint32_t L0SEL : 3;
		/* Indicates the length of time this Port requires to complete the transition from ASPM L1 to L0. If ASPM L1 is
		 * not supported, the value is undefined. */
		uint32_t L1EL : 3;
		/* 0 - Reference Clock Must Be On Always, however the CLKREQ# signal may be asserted during L1 Substates[br]
1 - Reference Clock May Be Turned Off in L1 and L2/3[br]
Note: In common clock mode [ where the reference is driven from the motherboard, the clock must never be turned off.
When the clock source is not from the motherboard [ locally supplied], then it may be turned off. */
		uint32_t CPMC : 1;
		/* For a Downstream Port, this bit must be set to 1b if the component supports the optional capability of
detecting and reporting a Surprise Down error condition.[br]
For Upstream Ports and components that do not support this optional capability, this bit must be hardwired to 0b. */
		uint32_t SLDERC : 1;
		uint32_t DLLLERC : 1;
		uint32_t LBNC : 1;
		/* Software is permitted to use the value of this bit to help determine whether to enable ASPM or whether to run
		 * ASPM compliance tests. */
		uint32_t ASPMOC : 1;
		uint32_t RESV23 : 1;
		/* Indicates the PCI Express port number for the given PCI Express link. */
		uint32_t PN : 8;
	};
} FORMAT_22;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Controls the level of Active State Power Management enabled on the given link.[br]00:		Disabled[br]
01:		L0s Entry Enabled[br]
10:		L1 Entry Enabled[br]
11:		L0s and L1 Entry Enabled[br]
Note: 'L0s Entry Enabled' enables the Transmitter to enter L0s. If L0s is supported, the Receiver must be capable of
entering L0s even when the Transmitter is disabled from entering L0s (00b or 10b). */
		uint16_t ASPMCTL : 2;
		uint16_t RESV2 : 1;
		/*  0 - 64B[br]
1- 128B[br]
Note: User can program the Root port's RCB value in this bit [lb]RCB Hint[rb] when the device is configured as an
endpoint. That information will be used for error detection in the device. The RCB value for end points is always 128B
irrespective of the programmed value. */
		uint16_t RCB : 1;
		/* End Points cannot disable link */
		uint16_t DL : 1;
		/* End Points cannot force link to retrain */
		uint16_t RL : 1;
		/* 0:	Indicates that this component and the component at the opposite end of this Link are operating with
asynchronous reference clock.[br]
1:	Indicates that this component and the component at the opposite end of this Link are operating with a distributed
common reference clock.[br]
Value is not considered by the device. User must program appropriate exit latencies per the setting of this bit. */
		uint16_t CCC : 1;
		/* 0:  Standard Fast Training Sequence (FTS).[br]
1:  Forces the transmission of additional ordered sets when exiting the L0s state and when in the Recovery state. This
mode provides external devices (e.g., logic analyzers) monitoring the Link time to achieve bit and symbol lock before
the link enters L0 and resumes communication. */
		uint16_t ES : 1;
		uint16_t ECPM : 1;
		/* When set to 1b this bit disables hardware from changing the link width for reasons other than attempting to
		 * correct unreliable link operation by reducing link width. */
		uint16_t HAWD : 1;
		uint16_t LBMIE : 1;
		uint16_t LABIE : 1;
		uint16_t RESV12 : 4;
	};
} FORMAT_23;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This field indicates the negotiated Link speed of the given PCI Express Link.Defined encodings are:[br]
0001b - 2.5 GT/s PCI Express Link[br]
0010b - 5.0 GT/s PCI Express Link[br]
0011b - 8.0 GT/s PCI Express Link[br]
0100b - 16 GT/s PCI Express Link[br]
0101b - 32 GT/s PCI Express Link[br]
All other encodings are reserved. The value in this field is undefined when the Link is not up. */
		uint16_t CLS : 4;
		/* Indicates negotiated link width.  This field is valid only when the link is in the L0, L0s, or L1 states
(after link width negotiation is successfully completed).[br]
00h:		Reserved[br]
01h:		X1[br]
02h:		X2[br]
04h:		X4[br]
08h:		X8[br]
10h:		X16[br]
All other encodings are reserved. */
		uint16_t NLW : 6;
		uint16_t UNDEF : 1;
		/* Indicates that the Physical Layer LTSSM is in the Configuration or Recovery state, or that 1b was written to
		 * the Retrain Link bit but Link training has not yet begun. Hardware clears this bit when the LTSSM exits the
		 * Configuration/Recovery state once Link training is complete. Value is Reserved when operating as an endpoint.
		 */
		uint16_t LNKTRN : 1;
		/* 0:	The device uses an independent clock irrespective of the presence of a reference on the connector.[br]
1:	The device uses the same physical reference clock that the platform provides on the connector. */
		uint16_t SCC : 1;
		/* This bit indicates the status of the Data Link Control and Management State Machine. It returns a 1b to
		 * indicate the DL_Active state, 0b otherwise. */
		uint16_t DLLLA : 1;
		/*  This bit is set to 1b by hardware to indicate that either of the following has occurred without the port
transitioning through DL_Down status:A link retraining initiated by a write of 1b to the Retrain Link bit has completed
Hardware has autonomously changed link speed or width to attempt to correct unreliable link operation, either through an
LTSSM timeout or a higher level process */
		uint16_t LBMS : 1;
		/*  This bit is set to 1b by hardware to indicate that hardware has autonomously changed link speed or width,
		 * without the port transitioning through DL_Down status, for reasons other than to attempt to correct
		 * unreliable link operation.    This bit must be set when the upstream component receives eight consecutive TS1
		 * or TS2 ordered sets with the Autonomous Change bit set. */
		uint16_t LABS : 1;
	};
} FORMAT_24;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When set to 1b, this bit indicates that an Attention Button for this slot is electrically controlled by the
		 * chassis. */
		uint32_t ABP : 1;
		/* When set to 1b, this bit indicates that a software programmable Power Controller is implemented for this
		 * slot/adapter (depending on form factor). */
		uint32_t PCP : 1;
		/* When set to 1b, this bit indicates that an MRL Sensor is implemented on the chassis for this slot. */
		uint32_t MSP : 1;
		/* When set to 1b, this bit indicates that an Attention Indicator is electrically controlled by the chassis */
		uint32_t AIP : 1;
		/* When set to 1b, this bit indicates that a Power Indicator is electrically controlled by the chassis for this
		 * slot */
		uint32_t PIP : 1;
		/* When set to 1b, this bit indicates that an adapter present in this slot might be removed from the system
		 * without any prior notification. This is a form factor specific capability. this bit is an indication to the
		 * operating system to allow for such removal without impacting continued software operation */
		uint32_t HPS : 1;
		/* When set to 1b, this bit indicates that this slot is capable of supporting hot-plug operations */
		uint32_t HPC : 1;
		/* No Associated Functionality */
		uint32_t SPLV : 8;
		/* No Associated Functionality */
		uint32_t SPLS : 2;
		uint32_t EIP : 1;
		uint32_t NCCS : 1;
		/* Indicates the physical slot number attached to this Port. */
		uint32_t PSN : 13;
	};
} FORMAT_25;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t ABPE : 1;
		uint16_t PFDE : 1;
		uint16_t MSCE : 1;
		uint16_t PDCE : 1;
		uint16_t CCI : 1;
		uint16_t HPIE : 1;
		uint16_t AIC : 2;
		uint16_t PIC : 2;
		uint16_t PCC : 1;
		uint16_t EIC : 1;
		uint16_t DLLSCE : 1;
		uint16_t RESV13 : 3;
	};
} FORMAT_26;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t ABP : 1;
		uint16_t PFD : 1;
		uint16_t MSC : 1;
		uint16_t PDC : 1;
		uint16_t CC : 1;
		uint16_t MSS : 1;
		uint16_t PDS : 1;
		uint16_t EIS : 1;
		uint16_t DLLSC : 1;
		uint16_t RESV9 : 7;
	};
} FORMAT_27;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Range A:  50us to 10ms[br]
  Range B:  10ms to 250ms[br]
  Range C:  250ms to 4s[br]
  Range D:  4s to 64s */
		uint32_t CTRS : 4;
		/* A value of 1b indicates support for the Completion Timeout Disable mechanism */
		uint32_t CTDS : 1;
		uint32_t ARIFS : 1;
		uint32_t AORS : 1;
		uint32_t AOCS1 : 1;
		uint32_t AOCS : 1;
		uint32_t CASAOC : 1;
		uint32_t NROPRPRP : 1;
		uint32_t LTRMS : 1;
		/* TPH Completer supported, Extended TPH Completer not supported. */
		uint32_t TPHCS : 2;
		uint32_t LNSCLS : 2;
		uint32_t TAG10CS : 1;
		uint32_t TAG10RS : 1;
		/* OBFF supported using WAKE# signaling only */
		uint32_t OBFFS : 2;
		/* Function supports a 2-bit definition of the Fmt field. */
		uint32_t EFFS : 1;
		uint32_t EETLPPS : 1;
		/* 1 End-End TLP Prefix */
		uint32_t MEETLPP : 2;
		/* Not Supported */
		uint32_t EPRS : 2;
		uint32_t EPRIR : 1;
		uint32_t RESV27 : 1;
		uint32_t DMWRCS : 1;
		/* This field indicates the largest DMWr TLP that this Function can receive.[br]
Defined Encodings are:[br]
00b  DMWr TLPs up to 64 bytes are supported[br]
01b  DMWr TLPs up to 128 bytes are supported[br]
10b  Reserved[br]
11b  Reserved */
		uint32_t DMWRLEN : 2;
		uint32_t FRSS : 1;
	};
} FORMAT_28;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* There is no functionality from this field. Use the Completion Timeout Register to set the value. */
		uint16_t CTV : 4;
		/* When set, this disables the Completion Timeout mechanism or if bit 0 of Completion Timeout Timer is set the
		 * timeout mechanism will also be disabled. */
		uint16_t CTD : 1;
		/* Hardwired. */
		uint16_t ARIFE : 1;
		uint16_t AORE : 1;
		/* Hardwired. */
		uint16_t AOEB : 1;
		uint16_t IDORE : 1;
		uint16_t IDOCE : 1;
		/* Enables the Latency Tolerance Requirement Reporting (LTR) mechanism. The values that will be provided in the
		 * LTR Message are specified in Latency Tolerance Reporting Values Register. */
		uint16_t LTRME : 1;
		uint16_t EPRR : 1;
		/* This bit, in combination with the Extended Tag Field Enable bit in the Device Control register, determines
		 * how many Tag field bits a Requester is permitted to use. When the 10-Bit Tag Requester Enable bit is Set, the
		 * Requester is permitted to use 10-Bit Tags.[br]No associated functionality. Software should verify setting for
		 * legal vector programming. */
		uint16_t TAG10E : 1;
		/* 00b: Disabled[br]
01b: Enabled using Message signaling [lb]variation a[rb][br]
10b: Enabled using Message signaling [lb]variation b[rb]][br]
11b: Enabled using WAKEB signaling, only one this device supports */
		uint16_t OBFFE : 2;
		/*  Hardwired */
		uint16_t EETLPPB : 1;
	};
} FORMAT_29;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t RESV0 : 16;
	};
} FORMAT_30;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 1;
		/*  This field indicates the supported Link speeds(s) of the associated Port. For each bit, a value of 1b
indicates that the corresponding Link speed is supported; otherwise, the Link seed is not supported.[br]
Bit 0 - 2.5 GT/s[br]
Bit 1 - 5.0 GT/s[br]
Bit 2 - 8.0 GT/s[br]
Bit 3 - 16.0 GT/s[br]
Bit 4 - 32.0 GT/s[br]
Bits 6:5 - reserved[br]
For each bit, a value of 1b indicates that the corresponding Link speed is supported; otherwise, the Link speed is not
supported[br] */
		uint32_t SLNKSPV : 7;
		uint32_t CS : 1;
		/* If this field is non-zero, it indicates that the Port, when operating at the indicated speed(s) supports SRIS
and also supports software control of the SKP Ordered Set transmission scheduling rate[br]
Bit 0 - 2.5 GT/s[br]
Bit 1 - 5.0 GT/s[br]
Bit 2 - 8.0 GT/s[br]
Bit 3 - 16.0 GT/s[br]
Bit 4 - 32.0 GT/s[br]
Bits 6:5 - reserved[br] */
		uint32_t LSOSGSSV : 7;
		/* If this field is non-zero, it indicates that the Port, when operating at the indicated speed(s) supports SRIS
and also supports receiving SKP OS at the rate defined for SRNS while running in SRIS.[br]
Bit 0 - 2.5 GT/s[br]
Bit 1 - 5.0 GT/s[br]
Bit 2 - 8.0 GT/s[br]
Bit 3 - 16.0 GT/s[br]
Bit 4 - 32.0 GT/s[br]
Bits 6:5 - reserved[br] */
		uint32_t LSOSRSSV : 7;
		/* Indicates that the associated Port supports detection and reporting of Retimer presence. */
		uint32_t RPDS : 1;
		/* Indicates that the associated Port supports detection and reporting of two Retimers presence */
		uint32_t TRPDS : 1;
		uint32_t RESV25 : 6;
		uint32_t DRSS : 1;
	};
} FORMAT_31;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* For a Downstream Port (root), sets upper limit on Link operational speed advertised in traning sequences. For
both Upstream and Downstream Ports, sets the target compliance mode speed when Enter Compliance bit forces Link into
compliance mode.[br]
0001b - 2.5Gb/s Target Link Speed[br]
0010b - 5 Gb/s Target Link Speed[br]
0011b - 8 Gb/s Target Link Speed[br]
0100b - 16 Gb/s Target Link Speed[br]

0101b - 32 Gb/s Target Link Speed[br]

Note: All other values are reserved. */
		uint16_t TLS : 4;
		/* Software is permitted to force a link to enter Compliance mode at the speed indicated in the Target Link
		 * Speed field by setting this bit to 1b in both components on a link and then initiating a hot reset on the
		 * link. */
		uint16_t EC : 1;
		/* When set to 1b this bit disables hardware from changing the link speed for reasons other than attempting to
		 * correct unreliable link operation by reducing link speed. Note: Initial transition to the highest supported
		 * common link speed is not blocked by this control bit. */
		uint16_t HASD : 1;
		/* When operating at 5.0 GT/s speed, this bit is used to control the transmit de-emphasis of the link in
specific situations.[br]0b:  -6 dB[br]
1b:  -3.5 dB[br]
This bit is not applicable for Endpoint */
		uint16_t SD : 1;
		/*  This field controls the value of the non-deemphasized voltage level at the Transmitter pins.[br]000: Normal
operating range[br]
others: see PCIe spec for details[br]
This register is intended for debug, compliance testing purposes only. System firmware and software is allowed to modify
this register only during debug or compliance testing. In all other cases, the system must ensure that this register is
set to the default value. */
		uint16_t TM : 3;
		/*  When set, the device transmits Modified Compliance pattern if the LTSSM enters Polling.Compliance substate.
		 */
		uint16_t EMC : 1;
		/*  When set to 1b, the LTSSM is required to send SKP Ordered Sets between sequences when sending the Compliance
		 * Pattern or Modified Compliance Pattern. This field is only applicable when the link is operating at 2.5 GT/s
		 * or 5 GT/s data rates only. */
		uint16_t CSOS : 1;
		/*  For 8.0 GT/s Data Rate: This sets the Transmitter Preset level in Polling.Compliance state if the entry
occurred due to the Enter Compliance bit being 1b. The Encodings are defined in PCIe section 4.2.3.2[br]
For 5.0 GT/s Data Rate: This sets the de-emphasis level in Polling.Compliance state if the entry occurred due to the
Enter Compliance bit being 1b.[br]
0000b:  -6 dB[br]
0001b:  -3.5 dB[br]
When the Link is operating at 2.5 GT/s, the setting of this has no effect. */
		uint16_t CD : 4;
	};
} FORMAT_32;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When the Link is operating at 5GT/s speed, this bit reflects the level of de-emphasis. The value is undefined
at other speeds.[br]0b -  -6 dB[br]
1b -  -3.5 dB[br]
_curr_deemp_level */
		uint16_t CDL : 1;
		/* When set to 1b, this indicates that the Transmitter Equalization procedure has completed.[br]_eqcmplt */
		uint16_t EQCMPLT : 1;
		/* When set to 1b, this indicates that Phase 1 of the Transmitter Equalization procedure has successfully
		 * completed.[br]_eqph1succ */
		uint16_t EQPH1SUCC : 1;
		/*  When set to 1b, this indicates that Phase 2 of the Transmitter Equalization procedure has successfully
		 * completed.[br]_eqph2succ */
		uint16_t EQPH2SUCC : 1;
		/*  When set to 1b, this indicates that Phase 3 of the Transmitter Equalization procedure has successfully
		 * completed.[br]_eqph3succ */
		uint16_t EQPH3SUCC : 1;
		/*  This bit is set by hardware to request Link equalization process to be performed on the link. See PCIe
		 * section 4.2.3 for details.[br]_lnkeqreq */
		uint16_t LER : 1;
		uint16_t RPD : 1;
		uint16_t TRPD : 1;
		uint16_t CR : 2;
		uint16_t RESV10 : 2;
		uint16_t DCP : 3;
		uint16_t DRSMR : 1;
	};
} FORMAT_33;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t MSIE : 1;
		/* Hardwired for 4 vectors requested */
		uint16_t MMC : 3;
		/* 000b: 1 vector allocated[br]001b: 2 vectors allocated[br]010b: 4 vectors allocated */
		uint16_t MME : 3;
		uint16_t AC : 1;
		uint16_t PVMCAP : 1;
		uint16_t EMDCAP : 1;
		uint16_t EMDEN : 1;
		uint16_t RESV11 : 5;
	};
} FORMAT_38;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 2;
		/* Address[lb]31:2[rb] of MSI Msg (posted memory write) for Register Based Interrupts */
		uint32_t MA : 30;
	};
} FORMAT_39;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Address[lb]63:32[rb] of MSI Msg (posted memory write) for Register Based Interrupts */
		uint32_t MUA : 32;
	};
} FORMAT_40;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  CHECK above for generation of these two data bits. */
		uint16_t RESV0 : 2;
		/*  Data payload for MSI Msg (posted memory write) for register based interrupts.[br]
  INT PIN | MSI DATA[lb]15:2[rb] | MSI DATA[lb]1:0[rb][br]
A | MSIDATA: DATA[lb]15:2[rb] | INTRCTL: BITS[lb]25:24[rb][br]
B | MSIDATA: DATA[lb]15:2[rb] | INTRCTL: BITS[lb]27:26[rb][br]
C | MSIDATA: DATA[lb]15:2[rb] | INTRCTL: BITS[lb]29:28[rb][br]
D | MSIDATA: DATA[lb]15:2[rb] | INTRCTL: BITS[lb]31:30[rb][br]
Byte enables will be generated to allow modification of bytes 0 and 1 only. Bytes 2,3 are not enabled
[lb]de-asserted[rb] User must program the lower 2 bits to be used for MSI data in the Interrupt Control Register
(INTRCTL) */
		uint16_t MD : 14;
	};
} FORMAT_41;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Version - A value of 011b indicates that this function complies with revision 1.2 of the PCI Power Management
		 * Interface Specification. */
		uint16_t PCIPMCV : 3;
		/* Does not apply to PCIe and must be hardwired to 0 */
		uint16_t PMECLK : 1;
		/* Function is guaranteed to be ready to successfully complete valid accesses immediately after being set to D0
		 */
		uint16_t RESV4 : 1;
		/* Hardwired to 0 to indicate that special initialization of this device is NOT required before generic class
		 * device driver is to use it. */
		uint16_t DSI : 1;
		/* Hardwired to 0 to indicate that there are no Vaux auxiliary current requirements. */
		uint16_t AUXC : 3;
		uint16_t D1PSS : 1;
		uint16_t D2PSS : 1;
		/* This field indicates the power states in which this device may indicate PME wake via PCI Express
messaging.[br]
xxxx 1b : PME can be asserted from D0[br]
xxx1 xb : PME can be asserted from D1[br]
xx1x xb : PME can be asserted from D2[br]
x1xx xb : PME can be asserted from D3hot[br]
1xxx xb : PME can be asserted from D3cold[br]
Note: D3Cold wake is supported only when locally powered and clocked */
		uint16_t PMES : 5;
	};
} FORMAT_43;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates the current power state of this device and can be used to set the device into a new power state. If
software attempts to write an unsupported state to this field, write operation must complete normally on the bus, but
the data is discarded and no state change occurs.[br]
00:		D0[br]
01:		D1[br]
10:		D2[br]
11:		D3hot */
		uint32_t PS : 2;
		uint32_t RESV2 : 1;
		/* When set to 1 this bit indicates that a device transitioning from D3hot to D0 because the power state
		 * commands does not perform an internal reset. Config context is preserved. Upon transition no additional
		 * operating sys intervention is required to preserve configuration context beyond writing the power state bits.
		 * When clear the devices do not perform an internal reset upon transitioning from D3hot to D0 via software
		 * control of the power state bits. Regardless of this bit the devices that transition from a D3hot to D0 by a
		 * system or bus segment reset will return to the device state D0 unintialized with only PME context preserved
		 * if PME is supported and enabled. */
		uint32_t NSR : 1;
		uint32_t RESV4 : 4;
		/* 0: the Function is not permitted to generate PME[br]
1:	The Function is permitted to generate a PME */
		uint32_t PMEEN : 1;
		/* Indicates that this device does not support the power management data register. */
		uint32_t DSEL : 4;
		/* Indicates that this device does not support the power management data register. */
		uint32_t DSCALE : 2;
		/* Outstanding PM_PME Message. The PM_PME Message will continue to send until this bit is cleared. */
		uint32_t PMESTS : 1;
		uint32_t RESV16 : 16;
	};
} FORMAT_44;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* This field is a PCI-SIG defined ID number that indicates the nature and format of the extended capability.
		 * Extended Capability ID for the Advanced Error Reporting Capability is 0001h. */
		uint32_t PCIEECID : 16;
		/* This field is a PCI-SIG defined version number that indicates the version of the capability structure
		 * present. Must be 1h for this version of the specification. */
		uint32_t CV : 4;
		/* This field contains the offset to the next PCI Express capability structure or 000h if no other items exist
		 * in the linked list of capabilities. */
		uint32_t NCO : 12;
	};
} FORMAT_45;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* For future RW1CS implementations; software must use 0 for writes to bits. */
		uint32_t RESV0 : 4;
		/* Ack or Nak received with sequence number out of bounds */
		uint32_t DLPES : 1;
		uint32_t RESV5 : 1;
		/* For future RW/1C/P implementations; software must use 0 for writes to bits. */
		uint32_t RESV6 : 6;
		uint32_t PTLPS : 1;
		uint32_t FCPES : 1;
		/* Note: the originating TLP Request will not be captured in the header log */
		uint32_t CTS : 1;
		uint32_t CAS : 1;
		uint32_t UCS : 1;
		uint32_t ROS : 1;
		uint32_t MTLPS : 1;
		uint32_t ECRCES : 1;
		/* Note: TLPs that are detected as Unsupported Requests [due PCIe rules] or requests out of address range
		 * [decode miss] or Messages that do not match any of the enabled message code comparators will set this bit.
		 * However, they will not cause the first error pointer and packet header to be logged. */
		uint32_t URES : 1;
		uint32_t RESV21 : 1;
		uint32_t UIES : 1;
		uint32_t RESV23 : 1;
		uint32_t RESV24 : 1;
		uint32_t RESV25 : 1;
		uint32_t RESV26 : 1;
		uint32_t RESV27 : 1;
		/* For future RW1CS implementations; software must use 0 for writes to bits. */
		uint32_t RESV28 : 4;
	};
} FORMAT_46;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 4;
		uint32_t DLPEM : 1;
		uint32_t RESV5 : 1;
		uint32_t RESV6 : 6;
		uint32_t PTLPM : 1;
		uint32_t FCPEM : 1;
		uint32_t CTM : 1;
		uint32_t CAM : 1;
		uint32_t UCM : 1;
		uint32_t ROM : 1;
		uint32_t MTLPM : 1;
		uint32_t ECRCEM : 1;
		uint32_t UREM : 1;
		uint32_t RESV21 : 1;
		uint32_t UIEM : 1;
		uint32_t RESV23 : 1;
		uint32_t RESV24 : 1;
		uint32_t RESV25 : 1;
		uint32_t RESV26 : 1;
		uint32_t RESV27 : 1;
		uint32_t RESV28 : 4;
	};
} FORMAT_47;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Physical layer receiver error occurred */
		uint32_t RES : 1;
		/* For future RW1CS implementations; software must use 0 for writes to bits. */
		uint32_t RESV1 : 5;
		/* When set, indicates a valid TLP with incorrect LCRC or sequence number was received. */
		uint32_t BTLPS : 1;
		/* When set, indicates a valid DLLP with incorrect LCRC was received. */
		uint32_t BDLLPS : 1;
		/* Recovery Threshold number of replays without forward progress */
		uint32_t RNRS : 1;
		/* For future RW1CS implementations; software must use 0 for writes to bits. */
		uint32_t RESV12 : 3;
		uint32_t RTTS : 1;
		/* When set, indicates that an Advisory Non-Fatal Error occurred. */
		uint32_t ANFES : 1;
		uint32_t RESV14 : 1;
		uint32_t HLOS : 1;
		/*   For future RW1CS implementations; software must use 0 for writes to bits. */
		uint32_t RESV16 : 16;
	};
} FORMAT_49;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t REM : 1;
		uint32_t RESV1 : 5;
		uint32_t BTLPM : 1;
		uint32_t BDLLPM : 1;
		uint32_t RNRM : 1;
		uint32_t RESV9 : 3;
		uint32_t RTTM : 1;
		uint32_t ANFEM : 1;
		uint32_t RESV14 : 1;
		uint32_t HLOM : 1;
		uint32_t RESV16 : 16;
	};
} FORMAT_50;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Note: TLPs detected as Unsupported Requests will not cause this value to update nor have their headers
		 * captured in the Header Log Register */
		uint32_t FEP : 5;
		uint32_t ECRCGC : 1;
		uint32_t ECRCGE : 1;
		uint32_t ECRCCC : 1;
		uint32_t ECRCCE : 1;
		uint32_t MHRC : 1;
		/*  Allows 2 TLP Headers to be logged. */
		uint32_t MHRE : 1;
		uint32_t TLPPRELOG : 1;
		/* Indicates that the Function DOES NOT record the prefix/header of Request TLPs that experience a Completion
  Timeout error.[br]
  Note: core has a separate Completion Timeout Info Register */
		uint32_t CPLTOPRELOG : 1;
		uint32_t RESV13 : 19;
	};
} FORMAT_51;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Bytes 0,1,2,3 */
		uint32_t TLPHL : 32;
	};
} FORMAT_52;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Bytes 0,1,2,3 */
		uint32_t TLPPRELOG0 : 32;
	};
} FORMAT_56;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Bytes 0,1,2,3 */
		uint32_t TLPPRELOG1 : 32;
	};
} FORMAT_57;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Bytes 0,1,2,3 */
		uint32_t TLPPRELOG2 : 32;
	};
} FORMAT_58;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Bytes 0,1,2,3 */
		uint32_t TLPPRELOG3 : 32;
	};
} FORMAT_59;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DWMRRRS : 1;
		uint32_t RESV1 : 31;
	};
} FORMAT_61;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* The Function is allowed to initiate DMWr Requests only if this bit and the Bus Master Enable bit in the
		 * Command register are both Set */
		uint32_t DWMREN : 1;
		uint32_t DWMREB : 1;
		uint32_t RESV2 : 30;
	};
} FORMAT_62;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates the number of (extended) Virtual Channels in addition to the default VC supported by the device. */
		uint32_t EVCC : 3;
		uint32_t RESV3 : 1;
		/* Indicates the number of (extended) Virtual Channels in addition to the default VC belonging to the
		 * low-priority VC (LPVC) group that has the lowest priority with respect to other VC resources in a
		 * strict-priority VC Arbitration.The value of 0 in this field implies strict VC arbitration. */
		uint32_t LPEVCC : 3;
		uint32_t RESV7 : 1;
		uint32_t RC : 2;
		uint32_t PATES : 2;
		uint32_t RESV12 : 20;
	};
} FORMAT_65;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Indicates the types of VC Arbitration supported by the Function for the LPVC group.Each bit location within
this field corresponds to a VC Arbitration
Capability defined below. When more than 1 bit in this field is Set, it indicates that the Port can be configured to
provide different VC arbitration services.
Defined bit positions are:[br]
Bit 0 Hardware fixed arbitration scheme, e.g., Round Robin[br]
Bit 1 Weighted Round Robin (WRR) arbitration with 32 phases[br]
Bit 2 WRR arbitration with 64 phases[br]
Bit 3 WRR arbitration with 128 phases[br]
Bits 4-7 Reserved */
		uint32_t VCAC : 8;
		uint32_t RESV8 : 16;
		/* Indicates the location of the VC Arbitration Table. This field contains the zero-based offset of the table in
		 * DQWORDS (16 bytes) from the base address of the Virtual Channel Capability Structure. A value of 0 indicates
		 * that the table is not present (due to fixed VC priority). */
		uint32_t VCATO : 8;
	};
} FORMAT_66;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Used for software to update the VC Arbitration Table when VC arbitration uses the VC Arbitration Table. As a
		 * VC Arbitration Table is never used by this component this field will never be used. */
		uint16_t LVCAT : 1;
		/* This field will be programmed by software to the only possible value as indicated in the VC Arbitration
		 * Capability field. */
		uint16_t VCAS : 3;
		uint16_t RESV4 : 12;
	};
} FORMAT_67;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t VCATS : 1;
		uint16_t RESV1 : 15;
	};
} FORMAT_68;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Each Bit Location within this field corresponds to a Function Arbitration Capability defined below. When more
than 1 bit in this field is Set, it indicates that
the VC resource can be configured to provide different arbitration services.[br]
Defined bit positions are:[br]
Bit 0 Non-configurable hardware-fixed arbitration scheme, e.g., Round Robin (RR)[br]
Bit 1 Weighted Round Robin (WRR) arbitration with 32 phases[br]
Bit 2 WRR arbitration with 64 phases[br]
Bit 3 WRR arbitration with 128 phases[br]
Bit 4 Time-based WRR with 128 phases[br]
Bit 5 WRR arbitration with 256 phases[br]
Bits 6-7 Reserved */
		uint32_t FAC : 8;
		uint32_t RESV8 : 8;
		uint32_t RESV16 : 7;
		uint32_t RESV23 : 1;
		/* Indicates the location of the Function Arbitration Table associated with the VC resource. A value of 00h
		 * indicates that the table is not present. */
		uint32_t RESV24 : 8;
	};
} FORMAT_69;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Traffic Class 0 is always routed to VC0. */
		uint32_t TC0VC0M : 1;
		/* Indicates the TCs (Traffic Classes) that are mapped to the VC resource. Bit locations within this field
		 * correspond to TC values. For example, when bit 7 is set in this field, TC7 is mapped to this VC resource.
		 * When more than one bit in this field is set, it indicates that multiple TCs are mapped to the VC resource. In
		 * order to remove one or more TCs from the TC/VC Map of an enabled VC, software must ensure that no new or
		 * outstanding transactions with the TC labels are targeted at the given Link. */
		uint32_t TCVC0M : 7;
		uint32_t RESV8 : 8;
		uint32_t RESV16 : 1;
		uint32_t RESV17 : 3;
		uint32_t RESV20 : 4;
		/* Assigns a VC ID to the VC resource. For VC0 this is hardwired to 000b */
		uint32_t VC0ID : 3;
		uint32_t RESV27 : 4;
		/* For VC0 this is hardwired to 1 and read only as VC0 can never be disabled. */
		uint32_t VC0E : 1;
	};
} FORMAT_70;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t RESV0 : 1;
		/* 0: The VC negotiation is complete.[br]
1:	The VC resource is still in the process of negotiation (initialization or disabling).[br]
The value of this bit is defined only when the Link is in the DL_Active state and the Virtual Channel is enabled (its VC
Enable bit is Set). It is cleared when the link successfully exits the FC_INIT2 state.
Before using a Virtual Channel, software must check whether the VC Negotiation Pending fields for that Virtual Channel
are cleared in both Components on a Link. */
		uint16_t VC0NP : 1;
		uint16_t RESV2 : 14;
	};
} FORMAT_71;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 8;
		uint32_t RESV8 : 7;
		uint32_t RSNPT : 1;
		uint32_t RESV16 : 7;
		uint32_t RESV23 : 1;
		uint32_t RESV24 : 8;
	};
} FORMAT_77;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Value indicates the maximum number of Multicast Groups that the component supports, encoded as M-1 */
		uint16_t MCMG : 6;
		uint16_t RESV6 : 2;
		/* The log2 of the Multicast Window size requested. */
		uint16_t MCWSR : 6;
		uint16_t RESV14 : 1;
		uint16_t MCECRCRS : 1;
	};
} FORMAT_81;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Value indicates the number of Multicast Groups configured for use, encoded as N-1 */
		uint16_t MCNG : 6;
		uint16_t RESV6 : 9;
		uint16_t MCEN : 1;
	};
} FORMAT_82;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* The location of the LSB of the Multicast Group number within the address */
		uint32_t MCIP : 6;
		uint32_t RESV6 : 6;
		uint32_t MCRL : 20;
	};
} FORMAT_83;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MCRU : 32;
	};
} FORMAT_84;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  For each bit that is Set, this function gets a copy of any Multicast TLPs for the associated Multicast
		 * Group. Bits above MC_Num_Group are ignored */
		uint32_t MCRL : 32;
	};
} FORMAT_85;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  For each bit that is Set, this function is blocked from sending TLPs to the associated Multicast Group. Bits
		 * above MC_Num_Group are ignored */
		uint32_t MCBAL : 32;
	};
} FORMAT_87;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  For each bit that is Set, this function is blocked from sending TLPs to the associated Multicast Group. Bits
		 * above MC_Num_Group are ignored */
		uint32_t MCBAU : 32;
	};
} FORMAT_88;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  For each bit that is Set, this function is blocked from sending TLPs containing Untranslated Addresses to
		 * the associated Multicast Group. Bits above MC_Num_Group are ignored */
		uint32_t MCBUL : 32;
	};
} FORMAT_89;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  For each bit that is Set, this function is blocked from sending TLPs containing Untranslated Addresses to
		 * the associated Multicast Group. Bits above MC_Num_Group are ignored */
		uint32_t MCBUU : 32;
	};
} FORMAT_90;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*   Along with the Latency Scale field, this register conveys the maximum Latency Value that a device should
		 * send. Value should not be longer than the Completion Timeout value. */
		uint16_t MSLV : 10;
		/*  000: 1ns[br]
001: 32 ns[br]
010: 1,024 ns[br]
011: 32,768 ns[br]
100: 1,048,576 ns[br]
101: 33,554,432 ns[br]
others: Not permitted */
		uint16_t LS : 3;
		uint16_t RESV13 : 3;
	};
} FORMAT_92;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*   Along with the Latency Scale field, this register conveys the maximum Latency Value that a device should
		 * send. Value should not be longer than the Completion Timeout value. */
		uint16_t MNSLV : 10;
		/*  000: 1ns[br]
001: 32 ns[br]
010: 1,024 ns[br]
011: 32,768 ns[br]
100: 1,048,576 ns[br]
101: 33,554,432 ns[br]
others: Not permitted */
		uint16_t LS : 3;
		uint16_t RESV13 : 3;
	};
} FORMAT_93;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Indicates the Function is capable of generating Requests without using ST. */
		uint32_t NSTMS : 1;
		uint32_t IVMS : 1;
		uint32_t DSMS : 1;
		uint32_t RESV3 : 5;
		uint32_t ETPHRS : 1;
		/*  Value indicates if and where ST table is located.[br]00: ST Table is not present[br]
01: ST Table is located in the TPH Requester Extended Capability Structure[br]
10: ST Table is located in MSI-X Table structure[br]
11: Reserved */
		uint32_t STTI : 2;
		uint32_t RESV11 : 5;
		/*  Number of table entries supported, encoded as N-1. */
		uint32_t STTS : 11;
		uint32_t RESV27 : 5;
	};
} FORMAT_95;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates the ST mode of operation selected[br]000: No Table Mode - a value of all zeros is used in the ST
field when present in a request.[br]
001: Interrupt Vector Mode (not supported)[br]
010: Device Specific Mode - ST value used is selected by the ST Table index programmed in the vector.[br]
others: reserved */
		uint32_t STMS : 3;
		uint32_t RESV3 : 5;
		/* 00: Function is not permitted to issue transactions with TPH or Extended TPH as Requester[br]
01: Function is permitted to issue transactions with TPH as Requester and is not permitted to issue transactions with
Extended TPH as Requester[br]
10: Reserved[br]
11: Function is permitted to issue transactions with TPH and Extended TPH as Requester */
		uint32_t TPHRE : 2;
		uint32_t RESV10 : 22;
	};
} FORMAT_96;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  The contents of this field are used as the ST value when selected */
		uint16_t STE : 16;
	};
} FORMAT_97;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*   The number of Invalidate Requests that the Function can accept before putting backpressure on the upstream
		 * connection. If 0 0000b, the Function can accept 32 Invalidate Requests. */
		uint16_t IQD : 5;
		/*  If Set, indicates the Untranslated Address is always aligned to a 4096 byte boundary. This bit permits
		 * software to distinguish between implementations compatible with earlier version of this specification that
		 * permitted a requester to supply anything in bits [11:2]. */
		uint16_t PAR : 1;
		/* If Set, the Function supports Invalidation Requests that have the Global Invalidate bit Set. If Clear, the
		 * Function ignores the Global Invalidate bit in all Invalidate Requests */
		uint16_t GLINVSUP : 1;
		/* Indicates this function may set the RO bit in Translation Requests when Enable Relaxed Ordering bit is set in
		 * the Device Control Register of the PCI Express Capability Structure. */
		uint16_t ROSUP : 1;
		uint16_t RESV7 : 8;
	};
} FORMAT_114;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This value indicates to the Function the minimum number of 4096-byte blocks that is indicated in a
		 * Translation Completion or Invalidate Requests. */
		uint16_t STU : 5;
		uint16_t RESV5 : 10;
		/*  When Set, the Function is enabled to cache translations. */
		uint16_t ENABLE : 1;
	};
} FORMAT_115;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 4;
		/*  Indicates the sizes which this BAR is capable of operating at.[br]Bit 8 - 16 MB[br]
Bit 9 - 32 MB */
		uint32_t CS : 20;
		uint32_t RESV24 : 8;
	};
} FORMAT_117;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Points to the beginning of the BAR that is resizable.BAR4 located at offset 20h - Memory Targets */
		uint32_t BARI : 3;
		uint32_t RESV3 : 2;
		/*  Indicates the total number of resizable BARs in the capability structure for this function. */
		uint32_t NRBAR : 3;
		/* This is the operating BAR size.[br]4h - 16 MB[br]
5h - 32 MB[br]
all others are unsupported[br] */
		uint32_t BARS : 5;
		uint32_t RESV13 : 19;
	};
} FORMAT_118;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t MFVCFGC : 1;
		uint16_t ACSFGC : 1;
		uint16_t RESV2 : 6;
		/* indicates the Function Number of the next higher numbered Function in the Device, or 00h if there are no
		 * higher numbered Functions */
		uint16_t NFN : 8;
	};
} FORMAT_120;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t MFVCFGE : 1;
		uint16_t ACSFGE : 1;
		uint16_t RESV2 : 2;
		uint16_t FG : 3;
		uint16_t RESV7 : 9;
	};
} FORMAT_121;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When this register is 1b and a 1b is written to the Link Retrain register with Target Link Speed set to
		 * 8GT/s, the Downstream Port must perform Transmitter Equalization. Software must guarentee that no
		 * transactions are pending in the Link while the Link is in Recovery when this bit is set to 1b. */
		uint32_t PE : 1;
		/* When set this bit enables the generation of interrupt to indicate that the Link Equalization Request bit has
		 * been set. */
		uint32_t LERI : 1;
		/* When this bit is Set, Deferrable Memory Write Requests that target going out this Egress Port must be
		 * blocked. */
		uint32_t DMWRREB : 1;
		uint32_t RESV3 : 6;
		/* When the Link is in L0 and the bit in this field corresponding to the Current Link Speed is Set, SKP Ordered
Sets are scheduled at the[br]
  rate defined for SRNS, overriding the rate required based on the clock tolerance architecture.[br]
Bit definitions within this field are:[br]
2.5 GT/s[br]
5.0 GT/s[br]
8.0 GT/s[br]
16.0 GT/s[br]
32.0 GT/s[br]
RsvdP[br]
Each unreserved bit in this field must be RW if the corresponding bit in the Lower SKP OS Generation
Supported Speeds Vector is Set, otherwise the bit must be RW or hardwired to 0.[br]
Behavior is undefined if a bit is Set in this field and the corresponding bit in the Lower SKP OS
Generation Supported Speeds Vector is not Set. */
		uint32_t ENLOWSOS : 7;
		uint32_t RESV16 : 16;
	};
} FORMAT_123;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L0ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L1ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L2ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L3ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L4ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L5ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L6ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L7RR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L8ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L9ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L10ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L11ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L12ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L13ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L14ERR : 1;
		/*  A value of 1b indicates that a lane based error was detected on the corresponding Lane Number. */
		uint32_t L15ERR : 1;
		uint32_t RESV16 : 16;
	};
} FORMAT_124;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t DPTP : 4;
		uint16_t DPRPH : 3;
		uint16_t RESV7 : 1;
		uint16_t UPTP : 4;
		uint16_t UPRPH : 3;
		uint16_t RESV15 : 1;
	};
} FORMAT_125;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When Set this bit indicates that PCI-PM L1.2 is supported */
		uint32_t PML12S : 1;
		/* When Set this bit indicates that PCI-PM L1.1 is supported */
		uint32_t PML11S : 1;
		/* When Set this bit indicates that ASPM L1.2 is supported */
		uint32_t ASPML12S : 1;
		/* When Set this bit indicates that ASPM L1.1 is supported */
		uint32_t ASPML11S : 1;
		/*  When Set this bit indicates that this Port supports L1 PM Substates */
		uint32_t L1PMSS : 1;
		/* Reserved for Upstream */
		uint32_t LFASL1SS : 1;
		uint32_t RESV6 : 2;
		/* Advertised value comes from the corresponding L1SUBCFG2 register field. Time (in us) required for this Port
		 * to re-establish common mode */
		uint32_t PCMRT : 8;
		/* Advertised value comes from the corresponding L1SUBCFG register field. Specifies the scale used for
T_POWER_ON_Value field[br]00b = 2us[br]
01b = 10 us[br]
10b = 100 us[br]
11b = Reserved */
		uint32_t PTPOWERONS : 2;
		uint32_t RESV18 : 1;
		/*  Advertised value comes from the corresponding L1SUBCFG register field. Along with the Port T_POWER_ON_Scale
		 * field sets the time (in us) that this Port requires the port on the opposite side of Link to wait in
		 * L1.2.Exit after sampling CLKREQ# asserted before actively driving the interface. */
		uint32_t PTPOWERONV : 5;
		uint32_t RESV24 : 8;
	};
} FORMAT_142;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When Set this bit indicates that PCI-PM L1.2 is enabled */
		uint32_t PML12E : 1;
		/* When Set this bit indicates that PCI-PM L1.1 is enabled */
		uint32_t PML11E : 1;
		/* When Set this bit indicates that ASPM L1.2 is enabled */
		uint32_t ASPML12E : 1;
		/* When Set this bit indicates that L1 Substates are enabled for ASPM */
		uint32_t ASPML11E : 1;
		/* Reserved for Upstream Port */
		uint32_t LAIE : 1;
		/* Reserved for Upstream Port */
		uint32_t LAC : 1;
		uint32_t RESV6 : 2;
		/* Reserved for Upstream Ports */
		uint32_t CMRT : 8;
		/*  Along with the LTR_L1.2_THRESHOLD_Scale, this field indicated threshold used to determine if entry into L1
		 * results in L1.1 (if enabled) or L1.2 (if enabled) */
		uint32_t LTRL12THRESHOLDV : 10;
		uint32_t RESV26 : 3;
		/*  This register provides a scale for the value contained within LTR_L1.2_THRESHOLD_Value. Encoding is the same
		 * as the LatencyScale fields in the LTR Message */
		uint32_t LTRL12THRESHOLDS : 3;
	};
} FORMAT_143;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Specifies the scale used for T_POWER_ON_Value[br]00b = 2 us[br]
01b = 10 us[br]
10b = 100 us[br]
11b = Reserved */
		uint32_t TPOWERONS : 2;
		uint32_t RESV2 : 1;
		/*  Along with T_POWER_ON_Scale sets the minimum amount of time (in us) that the Port must wait in L1.2.Exit
		 * after sampling CLKREQ# asserted before actively driving the interface */
		uint32_t TPOWERONV : 5;
		uint32_t RESV8 : 24;
	};
} FORMAT_144;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Reserved for Upstream */
		uint32_t LAS : 1;
		uint32_t RESV1 : 31;
	};
} FORMAT_145;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t LSFCS : 1;
		/* RsvdP */
		uint32_t LFDLFS : 22;
		uint32_t RESV23 : 8;
		/* indicates that this Port will enter the DL_Feature negotiation state */
		uint32_t DLFEEN : 1;
	};
} FORMAT_147;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* indicate that the Remote Port supports the corresponding Data Link Feature [br]
  bit 0: indicates that the Remote Port supports the Scaled Flow Control Feature. [br]
  bit [22:1]: undefined [br] */
		uint32_t RDLFS : 23;
		uint32_t RESV23 : 8;
		/* indicates that the Port has received a Data Link Feature DLLP in state DL_Feature and that the Remote Data
		 * Link Feature Supported field is meaningful. */
		uint32_t RDLFSV : 1;
	};
} FORMAT_148;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When set to 1b, this indicates that the Transmitter Equalization procedure has completed.[br]_eqcmplt */
		uint32_t EQCMPLT : 1;
		/*  When set to 1b, this indicates that Phase 1 of the Transmitter Equalization procedure has successfully
		 * completed.[br]_eqph1succ */
		uint32_t EQPH1SUCC : 1;
		/*  When set to 1b, this indicates that Phase 2 of the Transmitter Equalization procedure has successfully
		 * completed.[br]_eqph2succ */
		uint32_t EQPH2SUCC : 1;
		/*  When set to 1b, this indicates that Phase 3 of the Transmitter Equalization procedure has successfully
		 * completed.[br]_eqph3succ */
		uint32_t EQPH3SUCC : 1;
		/*  This bit is set by hardware to request Link equalization process to be performed on the link. See PCIe
		 * section 4.2.3 for details.[br]_lnkeqreq */
		uint32_t LER : 1;
		uint32_t RESV5 : 27;
	};
} FORMAT_152;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Each bit indicates if the corresponding Lane detected a Data Parity mismatch */
		uint32_t LDPMS : 16;
		uint32_t RESV15 : 16;
	};
} FORMAT_153;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Each bit indicates if the corresponding  Lane detected a Data Parity mismatch */
		uint32_t FRDPMS : 16;
		uint32_t RESV15 : 16;
	};
} FORMAT_154;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Each bit indicates if the corresponding Lane detected a Data Parity mismatch */
		uint32_t SRDPMS : 16;
		uint32_t RESV15 : 16;
	};
} FORMAT_155;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Transmitter Preset used for 16.0 GT/s equalization by this Port when the Port is operating as a Downstream
Port[br]
This field is ignored when the Port is operating as an Upstream Port. */
		uint8_t DP16TP : 4;
		/* The Transmit Preset value sent or received during 16.0 GT/s Link Equalization */
		uint8_t UP16TP : 4;
	};
} FORMAT_157;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When Set, this Port supports controlling whether the Port negotiates to skip equalization for speeds other
than the highest common supported speed. See Section Section 4.2.3 for details.[br]
Must be 1b for Ports that support 32.0 GT/s or higher data rates */
		uint32_t RESV0 : 1;
		/*  When Set, this Port supports controlling whether or not Equalization is needed. */
		uint32_t RESV1 : 1;
		uint32_t RESV7 : 6;
		/*  This bit indicates that this Port supports PCI Express (Modified TS Usage 000b). This bit must be 1b. */
		uint32_t RESV8 : 1;
		/*  This bit indicates that this Port supports sending and recieving vendor specific Training Set Messages
		 * (Modified TS Usage 001b). See Section 4.2.4.2 for details. */
		uint32_t RESV9 : 1;
		/*  This bit indicates that this Port supports negotiating to use alternate protocols (Modified TS Usage 010b).
		 * See Section 4.2.4.2 for details */
		uint32_t RESV10 : 1;
		/*  Reserved bits for future Usage Modes defined by the PCISIG. Must be 0 0000b. */
		uint32_t RESV15 : 5;
		uint32_t RESV31 : 16;
	};
} FORMAT_174;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When Clear, this Port indicates during Link Training that is wishes to train to the highest common link data
rate and skip equalization of intermediate data rates. See Section 4.2.3 for details.[br]
If Equalization bypass to highest rate Supported is Set, this bit is RWS with a default value of 0b.[br]
If Equalization bypass to highest rate Supported is Clear, this bit is permitted to be hardwired to 0b */
		uint32_t RESV0 : 1;
		/*  When Clear, this Port is permitted to indicate that it does not require equalization. When Set, this Port
must always indicate that it requires equalization. See Section 4.2.3 for details.[br]
If No Equalization Needed Supported is Set, this bit is RWS with a default value of 0b.[br]
If No Equalization Needed Supported is Clear, this bit is permitted to be hardwired to 0b. */
		uint32_t RESV1 : 1;
		uint32_t RESV31 : 30;
	};
} FORMAT_175;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When set to 1b, this indicates that the Transmitter Equalization procedure has completed.[br] For a
		 * Multi-Function Upstream Port, this bit must be implemented in Function 0 and RsvdZ in other
		 * Functions.[br]_eqcmplt_32g */
		uint32_t EQCMPLT : 1;
		/*  When set to 1b, this indicates that Phase 1 of the Transmitter Equalization procedure has successfully
		 * completed.[br] For a Multi-Function Upstream Port, this bit must be implemented in Function 0 and RsvdZ in
		 * other Functions.[br]_eqph1succ_32g */
		uint32_t EQPH1SUCC : 1;
		/*  When set to 1b, this indicates that Phase 2 of the Transmitter Equalization procedure has successfully
		 * completed.[br] For a Multi-Function Upstream Port, this bit must be implemented in Function 0 and RsvdZ in
		 * other Functions.[br]_eqph2succ_32g */
		uint32_t EQPH2SUCC : 1;
		/*  When set to 1b, this indicates that Phase 3 of the Transmitter Equalization procedure has successfully
		 * completed.[br] For a Multi-Function Upstream Port, this bit must be implemented in Function 0 and RsvdZ in
		 * other Functions.[br] _eqph3succ_32g */
		uint32_t EQPH3SUCC : 1;
		/*  This bit is set by hardware to request the 32.0 GT/s Link equalization process to be performed on the link.
  See PCIe section 4.2.3 for details.[br]
  For a Multi-Function Upstream Port, this bit must be implemented in Function 0 and RsvdZ in other Functions.[br]
  _lnkeqreq_32g */
		uint32_t LER : 1;
		/*  If Set, Received Modified TS Data 1 Register and Received Modified TS Data 2 Register contain meaningful
		 * data. This bit is Cleared when the Link is Down. This bit is Set when the Modified TS1/TS2 Ordered Set is
		 * received (See Section 4.2.6.3.3 ).[br] */
		uint32_t MTR : 1;
		/*  This field contains the Enhanced Link Behavior Control bits from the most recent TS1 or TS2 received in the
		 * Polling or Configuration states. See Section 4.2.4.1 , Table 4-6 and Table 4-7. This field is Cleared on
		 * DL_Down.[br] */
		uint32_t RELBC : 2;
		/*  This field indicates whether the Receiver asked this transmitter to enable Precoding. See Section 4.2.2.5 .
		 * This bit is cleared on DL_Down.[br] */
		uint32_t TPO : 1;
		/*  When Set, this Port will request the transmitter to use Precoding by setting the Transmitter Precode Request
		 * bit in the TS1s/TS2s it transmits prior to entry to Recovery.Speed (see Section 4.2.2.5 ).[br] */
		uint32_t TPR : 1;
		/*  When Set, this Port either received a Modified TS1/TS2 with the No Equalization Needed bit Set or received a
		 * non-modified TS1/TS2 was recieved with the No Equalization Needed encoding (also reported in the Received
		 * Enhanced Link Behavior Control field).[br] */
		uint32_t NENR : 1;
		uint32_t RESV11 : 21;
	};
} FORMAT_176;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* If Modified TS Received is Set, this field contains the Modified TS Usage field from the Modified TS1/TS2
		 * Ordered Set (see Section 4.2.6.3.6 ). If Modified TS Received is Clear, this field contains 000b. */
		uint32_t RMTSUM : 3;
		/* If Modified TS Received is Set, this field contains the Modified TS Information 1 field from the Modified
TS1/TS2 Ordered Set (see Section 4.2.6.3.6 ). If Modified TS Received is Clear, this field contains 0 0000 0000
0000b.[br]
Bit 15:8 contain the value of Symbol 9.[br]
Bit 7:3  contain bits 7:3 of Symbol 8.[br]  */
		uint32_t RMTSI1 : 13;
		/* If Modified TS Received is Set, this field contains the Training Set Message Vendor ID or Alternate Protocol
Vendor ID field from the Modified TS1/TS2 Ordered Set received (see Section 4.2.6.3.6 ). If Modified TS Received is
Clear, this field contains 0000h.[br]
Bit 31:24 contain the value of Symbol 11.[br]
Bit 23:16 contain the value of Symbol 10.[br]  */
		uint32_t RMTSID : 16;
	};
} FORMAT_177;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* If Modified TS Received is Set, this field contains the Modified TS Information 2 field from the received
Modified TS1/TS2 Ordered Set (Section 4.2.6.3.6 ). If Modified TS Received is Clear, this field contains 00 0000h.[br]
Bits 23:16 contain the value of Symbol 14.[br]
Bits 16:8 contain the value of Symbol 13.[br]
Bits 7:0 contain the value of Symbol 12.[br]
If PCI Express (Usage Mode 0) is the only one supported, this field is permitted to be hardwired to 00 0000h. */
		uint32_t TMTS2 : 24;
		/* Indicates the status of the Alternate Protocol Negotiation. Encodings are:[br]
00b   Alternate Protocol Negotiation not supported - Modified TS Usage Mode 2 Supported - Alternate Protocol is
Clear.[br]
01b   Alternate Protocol Negotiation disabled - Modified TS Usage Mode 2 Supported - Alternate Protocol is Set but
Modified TS Usage Mode Selected was not 2 during the appropriate LTSSM State.[br]
10b   Alternate Protocol Negotiation failed - Alternate Protocol Negotiation was attempted and did not locate a protocol
that was supported on both ends of the Link.[br]
11b   Alternate Protocol Negotiation succeeded - Alternate Protocol Negotiation located one or more protocols that were
supported on both ends of the Link and the Downstream Port selected one of those protocols for use. */
		uint32_t APNS : 2;
		uint32_t RESV26 : 6;
	};
} FORMAT_178;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* If Modified TS Received is Set, this field contains the Modified TS Usage field from the Modified TS2 Ordered
		 * Set transmitted during the Configuration.Complete LTSSM State (see Section 4.2.6.3.6 ).[br] Unused bits in
		 * this field are permitted to he hardwired to 0b. If PCI Express (Usage Mode 0) is the only one supported, this
		 * field is permitted to be hardwired to 000b. */
		uint32_t TMTSUM : 3;
		/* If Modified TS Received is Set, this field contains the Modified TS Information 1 field from Modified TS2
Ordered Set transmitted during the Configuration.Complete LTSSM State (see Section 4.2.6.3.6 ).[br]
Bit 15:8 contain the value of Symbol 9.[br]
Bit 7:3  contain bits 7:3 of Symbol 8.[br]  */
		uint32_t TMTSI1 : 13;
		/* If Modified TS Received is Set, this field contains the Training Set Message Vendor ID or Alternate Protocol
Vendor IDfield from the Modified TS2 Ordered Set transmitted during the Configuration.Complete LTSSM State (see Section
4.2.6.3.6 ).[br]
Bit 31:24 contain the value of Symbol 11.[br]
Bit 23:16 contain the value of Symbol 10.[br]  */
		uint32_t TMTSID : 16;
	};
} FORMAT_179;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Transmitter Preset used for 32.0 GT/s equalization by this Port when the Port is operating as a Downstream
Port[br]
This field is ignored when the Port is operating as an Upstream Port. */
		uint8_t DP32TP : 4;
		/* The Transmit Preset value sent or received during 32.0 GT/s Link Equalization */
		uint8_t UP32TP : 4;
	};
} FORMAT_181;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* If Set, indicates that Margining is partially implemented using Device Driver software. Margining Software
Ready indicates when this software is initialized. If Clear, Margining does not require
device driver software. In this case the value read from Margining Software Ready is undefined. */
		uint16_t MUDS : 1;
		uint16_t RESV1 : 15;
	};
} FORMAT_198;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates when the Margining feature is ready to accept margining commands. */
		uint16_t MR : 1;
		/* When Margining uses Driver Software is Set, then this bit, when Set, indicates that the required software has
		 * performed the required initialization. The value of this bit is undefined if Margining uses Driver Software
		 * is Clear */
		uint16_t MSR : 1;
		uint16_t RESV2 : 14;
	};
} FORMAT_199;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t RNUM : 3;
		uint16_t MTYPE : 3;
		uint16_t USEM : 1;
		uint16_t RESV7 : 1;
		uint16_t MPAY : 8;
	};
} FORMAT_200;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t RNUMSTS : 3;
		uint16_t MTYPESTS : 3;
		uint16_t USEMSTS : 1;
		uint16_t RESV7 : 1;
		uint16_t MPAYSTS : 8;
	};
} FORMAT_201;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates that the Page Request Interface is allowed to make page requests */
		uint16_t PREN : 1;
		/* When the Enable field is clear, or is being cleared in the same register update that sets this field, writing
		 * a 1b to this field, clears the associated implementation dependent page request credit counter and pending
		 * request state for the associated Page Request Interface */
		uint16_t PRRST : 1;
		uint16_t RESV2 : 14;
	};
} FORMAT_233;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates that the Function has received a PRG Response Message indicating a Response Failure. The Function
expects no further responses from the host (any
received are ignored). */
		uint16_t PRRF : 1;
		/* Indicates that the Function has received a PRG Response Message containing a PRG index that has no matching
		 * request. */
		uint16_t PRUPRGI : 1;
		uint16_t RESV2 : 6;
		/* The associated page request interface has stopped issuing additional page requests and that all previously
		 * issued Page Requests have completed. */
		uint16_t STOPPED : 1;
		uint16_t RESV9 : 6;
		/* The Function expects a PASID TLP Prefix on PRG Response Messages when the corresponding Page Requests had a
		 * PASID TLP Prefix. */
		uint16_t PRGRPS : 1;
	};
} FORMAT_234;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Contains the number of outstanding page request messages the associated Page Request Interface physically
supports.[br]
This is the upper limit on the number of pages that can be usefully allocated to the Page Request Interface. */
		uint32_t OPRCAP : 32;
	};
} FORMAT_235;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Contains the number of page request messages the associated Page Request Interface is allowed to issue. */
		uint32_t OPRALLOC : 32;
	};
} FORMAT_236;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t RESV0 : 1;
		/* Endpoint supports sending TLPs that have the Execute Requested bit Set. */
		uint16_t EPS : 1;
		/* Endpoint supports operating in Privileged and Non-Privileged modes, and supports sending requests that have
		 * the Privileged Mode Requested bit Set. */
		uint16_t PMS : 1;
		uint16_t RESV3 : 5;
		/* Indicates the width of the PASID field supported by the Endpoint. The value n indicates support for PASID
		 * values 0 through 2n-1 (inclusive). The value 0 indicates support for a single PASID (0). The value 20
		 * indicates support for all PASID values (20 bits). This field must be between 0 and 20 (inclusive). */
		uint16_t MAXPASIDW : 5;
		uint16_t RESV13 : 3;
	};
} FORMAT_238;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Endpoint is permitted to send and receive TLPs that contain a PASID TLP Prefix */
		uint16_t PASIDEN : 1;
		/* Endpoint is permitted to send Requests that have the Execute Requested bit Set */
		uint16_t PASIDEPEN : 1;
		/* Endpoint is permitted to send Requests that have the Privileged Mode Requested bit Set */
		uint16_t PASIDPMEN : 1;
		uint16_t RESV3 : 13;
	};
} FORMAT_239;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* indicates they implement the PTM Requester role */
		uint32_t PTMREQCAP : 1;
		/* indicate they implement the PTM Responder role */
		uint32_t PTMRESPCAP : 1;
		/* implement a PTM Time Source Role and are capable of serving as the PTM Root */
		uint32_t PTMROOTCAP : 1;
		/* If Set, indicates that this device supports Enhanced Precision Time Management */
		uint32_t PTMECAP : 1;
		uint32_t RESV4 : 4;
		/* If the PTM Root Select bit is Set, this local clock is used to provide PTM Master Time. Otherwise, the Time
		 * Source uses this local clock to locally track PTM Master Time received from further Upstream within a PTM
		 * Hierarchy */
		uint32_t CLKGRAN : 8;
		uint32_t RESV16 : 16;
	};
} FORMAT_241;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When Set, this Function is permitted to participate in the PTM mechanism according to its selected role(s) */
		uint32_t PTMEN : 1;
		/* When Set, if the PTM Enable bit is also Set, this Time Source is the PTM Root. */
		uint32_t ROOTSEL : 1;
		uint32_t RESV2 : 6;
		/* For Functions implementing the PTM Requester Role, this field provides information relating to the expected
		 * accuracy of the PTM clock, but does not otherwise affect the PTM mechanism */
		uint32_t EFFGRAN : 8;
		uint32_t RESV16 : 16;
	};
} FORMAT_242;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* PF is Migration Capable and operating under a Migration Capable MR-PCIM. */
		uint32_t VFMC : 1;
		/* ARI Capable Hierarchy bit is preserved across certain power state transitions. */
		uint32_t ARICHP : 1;
		/* all VFs must support 10-Bit Tag Requester capability */
		uint32_t VF10TAGRS : 1;
		uint32_t RESV3 : 18;
		/* Indicates the MSI/MSI-X vector used for migration interrupts. */
		uint32_t VFMIMN : 11;
	};
} FORMAT_244;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Enables/Disables VFs */
		uint16_t VFEN : 1;
		/* VF Migration Support */
		uint16_t VFMEN : 1;
		/* Enables/Disables VF Migration State Change Interrupt. */
		uint16_t VFMIEN : 1;
		/* Memory Space Enable for Virtual Functions */
		uint16_t VFMSE : 1;
		/* If the value of this bit is 1b, the Device is permitted to locate VFs in Function Numbers 8 to 255 of the
		 * captured Bus Number. Otherwise, the Device must locate VFs as if it were a non-ARI Device */
		uint16_t ARICAPH : 1;
		/* If Set, all VFs must use 10-Bit Tags for all Non-Posted Requests they generate. If Clear, VFs must not use
		 * 10-Bit Tags for Non-Posted Requests they generate */
		uint16_t VF10TAGREN : 1;
		uint16_t RESV6 : 10;
	};
} FORMAT_245;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates a VF Migration In or Migration Out Request has been issued by MR-PCIM. */
		uint16_t VFMS : 1;
		uint16_t RESV1 : 15;
	};
} FORMAT_246;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* # of Vector Machines */
		uint16_t INITVFS : 16;
	};
} FORMAT_247;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Maximum number of VFs that could be associated with the PF */
		uint16_t TOTVFS : 16;
	};
} FORMAT_248;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Number of VFs that are visible */
		uint16_t NUMVFS : 16;
	};
} FORMAT_249;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* This field describes dependencies between PFs. VF dependencies are the same as the dependencies of their
		 * associated PFs. */
		uint16_t FDL : 16;
	};
} FORMAT_250;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t FSTVFOFF : 16;
	};
} FORMAT_251;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint16_t VFSTRIDE : 16;
	};
} FORMAT_252;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates the page sizes supported by the PF. PFs are required to support 4-KB, 8-KB, 64-KB, 256-KB, 1-MB,
		 * and 4-MB page sizes */
		uint32_t PFPS : 32;
	};
} FORMAT_254;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Page size the system will use to map the VFs memory addresses */
		uint32_t SYSPS : 32;
	};
} FORMAT_255;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MSI : 1;
		uint32_t RESV1 : 1;
		uint32_t BITDECODE : 1;
		uint32_t PREFETCH : 1;
		/* Hardwired 8KB */
		uint32_t RS : 9;
		uint32_t BA : 19;
	};
} FORMAT_256;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t VFBAR1 : 32;
	};
} FORMAT_257;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t VFBAR2 : 32;
	};
} FORMAT_258;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t VFBAR3 : 32;
	};
} FORMAT_259;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MSI : 1;
		uint32_t RESV1 : 1;
		uint32_t BITDECODE : 1;
		/* set by PREFETCHCTRL.BAR0PREFETCH  */
		uint32_t PREFETCH : 1;
		/* Hardwired 128KB */
		uint32_t RS : 13;
		uint32_t BA : 15;
	};
} FORMAT_260;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t VFMSBIR : 3;
		uint32_t VFMSO : 29;
	};
} FORMAT_262;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Lower 32-bits of DSN */
		uint32_t DSNLOW : 32;
	};
} FORMAT_264;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Upper 32-bits of DSN */
		uint32_t DSNHIGH : 32;
	};
} FORMAT_265;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Vendor-defined ID number that indicates the nature and format of the VSEC structure. Validation Bus Exerciser
		 */
		uint32_t VSECID : 16;
		/* Vendor-defined version number that indicates the version of the VSEC structure */
		uint32_t VSECREV : 4;
		/* Field indicates the number of bytes in the entire VSEC structure, including the Vendor-Specific Extended
		 * Capability Header, the Vendor-Specific Header, and the vendor-specific registers */
		uint32_t VSECLEN : 12;
	};
} FORMAT_267;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0: Hot Reset to the Core will not be masked if PE_RESETB Mask Core is set.[br]
1: Hot Reset to the Core will also be masked if PE_RESETB Mask Core is set. */
		uint32_t HRMC : 1;
		uint32_t RESV1 : 22;
		/* STRAP_REMAP1_PREF[br]Sets prefetch value for used in FN0BAR0 & VFBAR4FN0 */
		uint32_t BAR0PREFETCH : 1;
		/* STRAP_LEGACY_ENDPT[br]When configured as an Endpoint, sets Device/Port Type to Legacy */
		uint32_t LEGACYENDPT : 1;
		uint32_t RESV25 : 7;
	};
} FORMAT_268;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* in this core */
		uint32_t NUMNVM : 3;
		uint32_t RESV3 : 5;
		/* in this core */
		uint32_t NUMFPVM : 3;
		uint32_t RESV11 : 5;
		/* in this core */
		uint32_t NUMTGT : 3;
		uint32_t RESV19 : 5;
		/* port this core belongs to */
		uint32_t PORTINST : 2;
		uint32_t RESV26 : 6;
	};
} FORMAT_269;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 31:16 - Day of the Year, Hour[br]
  15:0 - Repository Revision */
		uint32_t IMGREV : 32;
	};
} FORMAT_270;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Year, Day of Year, Hour, Minute */
		uint32_t BLDREV : 31;
		/* 0 - Release Build[br]1 - Debug Build */
		uint32_t DEBUG : 1;
	};
} FORMAT_271;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*
  1 - Moonstone Beach[br]
  2 - Race Point Beach[br]
  3 - Lookout Ridge mUDV[br]
  4 - Altera S10 DevKit[br]
  5 - Altera FM85 DevKit[br]
  other values are reserved */
		uint32_t BOARDTYPE : 3;
		uint32_t RESV3 : 5;
		/* If Board Type is Moonstone Beach:[br]
  0 - FM67 (using RNR A0 tile 15C, PySv = U20)[br]
  1 - FM85 (using RNR A0 tile 15C, PySv = U22) */
		uint32_t BOARDREV : 2;
		uint32_t RESV10 : 6;
		/* 0 - A0[br]
  1 - B0 */
		uint32_t DIEREV : 1;
		uint32_t RESV17 : 15;
	};
} FORMAT_272;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  The Completion status of a cfg access to this register can be programmed in the Config Retry Cycle
		 * Completion Status register */
		uint32_t FSU : 32;
	};
} FORMAT_273;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t EIDVM0 : 2;
		uint32_t VBVM0 : 1;
		uint32_t EIDVM1 : 2;
		uint32_t VBVM1 : 1;
		uint32_t EIDVM2 : 2;
		uint32_t VBVM2 : 1;
		uint32_t EIDVM3 : 2;
		uint32_t VBVM3 : 1;
		uint32_t RESV12 : 3;
		uint32_t RESV15 : 3;
		uint32_t RESV18 : 12;
		/* Indicates the end of the producer writes. If the T0 expected and actual byte counter values are not equal, a
		 * T0 byte counter error is flagged. */
		uint32_t FTR1 : 1;
		/* Indicates the end of the producer writes. A value of 0xFFFFFFF0 is written to the Target 0 Write Ordering
		 * Address Register */
		uint32_t FTR : 1;
	};
} FORMAT_277;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Used for Producer Consumer testing as a Flag/Semaphore or general-purpose usage. This shared register is
		 * accessible through memory/IO/configuration accesses. */
		uint32_t UR : 32;
	};
} FORMAT_281;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* TBD */
		uint32_t PTMEN : 32;
	};
} FORMAT_285;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Indicates Threshold has been crossed */
		uint32_t THRESHERR : 1;
		uint32_t RESV1 : 31;
	};
} FORMAT_286;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 8;
		/* PTM Requester Long Timer. Determines the period between each auto update PTM Dialogue in miliseconds. Update
		 * period is the register value +1 milisecond. For the Switch product this value must not be set larger than 0x9
		 * for spec compliance.  */
		uint32_t LONGTIMER : 8;
		uint32_t RESV16 : 16;
	};
} FORMAT_287;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Lower 32 bits of amount by which PTM Requester Local Clock has been corrected */
		uint32_t CLKCORRLSB : 32;
	};
} FORMAT_288;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0 - disables checking */
		uint32_t THRESH : 32;
	};
} FORMAT_289;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* External trigger time */
		uint32_t TRIGTIME : 32;
	};
} FORMAT_290;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* External trigger mask */
		uint32_t TRIGMSK : 32;
	};
} FORMAT_291;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* External capture time */
		uint32_t TRIGCAPT : 32;
	};
} FORMAT_292;
} // namespace cambria_rnr_func0_cfgFmt


namespace cambria_rnr_func0_cfg
{
struct VID {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_0 format;
	static constexpr uint64_t cfg_offset() { return 0x0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x0; }
	static constexpr uint64_t size() { return 16; }
};
struct DID {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_1 format;
	static constexpr uint64_t cfg_offset() { return 0x2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x2; }
	static constexpr uint64_t size() { return 16; }
};
struct PCICMD {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_2 format;
	static constexpr uint64_t cfg_offset() { return 0x4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x4; }
	static constexpr uint64_t size() { return 16; }
};
struct PCISTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_3 format;
	static constexpr uint64_t cfg_offset() { return 0x6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x6; }
	static constexpr uint64_t size() { return 16; }
};
struct CCRID {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_4 format;
	static constexpr uint64_t cfg_offset() { return 0x8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x8; }
	static constexpr uint64_t size() { return 32; }
};
struct PCIMISC {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_5 format;
	static constexpr uint64_t cfg_offset() { return 0xc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xc; }
	static constexpr uint64_t size() { return 32; }
};
/* Physical memory - ARAM/EV/Core Registers/RNR Registers */
struct BAR0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_6 format;
	static constexpr uint64_t cfg_offset() { return 0x10; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x10; }
	static constexpr uint64_t size() { return 32; }
};
struct BAR1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_7 format;
	static constexpr uint64_t cfg_offset() { return 0x14; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x14; }
	static constexpr uint64_t size() { return 32; }
};
/* Virtual IO Targets */
struct BAR2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_8 format;
	static constexpr uint64_t cfg_offset() { return 0x18; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x18; }
	static constexpr uint64_t size() { return 32; }
};
struct BAR3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_9 format;
	static constexpr uint64_t cfg_offset() { return 0x1c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x1c; }
	static constexpr uint64_t size() { return 32; }
};
/* Virtual Memory Targets */
struct BAR4 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_10 format;
	static constexpr uint64_t cfg_offset() { return 0x20; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x20; }
	static constexpr uint64_t size() { return 32; }
};
struct BAR5 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_7 format;
	static constexpr uint64_t cfg_offset() { return 0x24; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x24; }
	static constexpr uint64_t size() { return 32; }
};
struct CAPPTR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_12 format;
	static constexpr uint64_t cfg_offset() { return 0x34; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x34; }
	static constexpr uint64_t size() { return 8; }
};
struct INTRLINE {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_13 format;
	static constexpr uint64_t cfg_offset() { return 0x3c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x3c; }
	static constexpr uint64_t size() { return 8; }
};
struct INTRPIN {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_14 format;
	static constexpr uint64_t cfg_offset() { return 0x3d; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x3d; }
	static constexpr uint64_t size() { return 8; }
};
struct MINGNT {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_15 format;
	static constexpr uint64_t cfg_offset() { return 0x3e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x3e; }
	static constexpr uint64_t size() { return 8; }
};
struct MAXLAT {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_15 format;
	static constexpr uint64_t cfg_offset() { return 0x3f; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x3f; }
	static constexpr uint64_t size() { return 8; }
};
struct EXPCAPLST {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_17 format;
	static constexpr uint64_t cfg_offset() { return 0x40; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x40; }
	static constexpr uint64_t size() { return 16; }
};
struct EXPCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_18 format;
	static constexpr uint64_t cfg_offset() { return 0x42; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x42; }
	static constexpr uint64_t size() { return 16; }
};
struct DEVCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_19 format;
	static constexpr uint64_t cfg_offset() { return 0x44; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x44; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_20 format;
	static constexpr uint64_t cfg_offset() { return 0x48; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x48; }
	static constexpr uint64_t size() { return 16; }
};
struct DEVSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_21 format;
	static constexpr uint64_t cfg_offset() { return 0x4a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x4a; }
	static constexpr uint64_t size() { return 16; }
};
struct LINKCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_22 format;
	static constexpr uint64_t cfg_offset() { return 0x4c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x4c; }
	static constexpr uint64_t size() { return 32; }
};
struct LINKCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_23 format;
	static constexpr uint64_t cfg_offset() { return 0x50; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x50; }
	static constexpr uint64_t size() { return 16; }
};
struct LINKSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_24 format;
	static constexpr uint64_t cfg_offset() { return 0x52; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x52; }
	static constexpr uint64_t size() { return 16; }
};
struct SLOTCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_25 format;
	static constexpr uint64_t cfg_offset() { return 0x54; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x54; }
	static constexpr uint64_t size() { return 32; }
};
struct SLOTCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_26 format;
	static constexpr uint64_t cfg_offset() { return 0x58; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x58; }
	static constexpr uint64_t size() { return 16; }
};
struct SLOTSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_27 format;
	static constexpr uint64_t cfg_offset() { return 0x5a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5a; }
	static constexpr uint64_t size() { return 16; }
};
struct DEVCAP2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_28 format;
	static constexpr uint64_t cfg_offset() { return 0x64; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x64; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVCTL2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_29 format;
	static constexpr uint64_t cfg_offset() { return 0x68; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x68; }
	static constexpr uint64_t size() { return 16; }
};
struct DEVSTS2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_30 format;
	static constexpr uint64_t cfg_offset() { return 0x6a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x6a; }
	static constexpr uint64_t size() { return 16; }
};
struct LINKCAP2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_31 format;
	static constexpr uint64_t cfg_offset() { return 0x6c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x6c; }
	static constexpr uint64_t size() { return 32; }
};
struct LINKCTL2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_32 format;
	static constexpr uint64_t cfg_offset() { return 0x70; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x70; }
	static constexpr uint64_t size() { return 16; }
};
struct LINKSTS2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_33 format;
	static constexpr uint64_t cfg_offset() { return 0x72; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x72; }
	static constexpr uint64_t size() { return 16; }
};
struct SLOTCAP2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_9 format;
	static constexpr uint64_t cfg_offset() { return 0x74; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x74; }
	static constexpr uint64_t size() { return 32; }
};
struct SLOTCTL2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_30 format;
	static constexpr uint64_t cfg_offset() { return 0x78; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x78; }
	static constexpr uint64_t size() { return 16; }
};
struct SLOTSTS2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_30 format;
	static constexpr uint64_t cfg_offset() { return 0x7a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x7a; }
	static constexpr uint64_t size() { return 16; }
};
struct MSICAPLST {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_17 format;
	static constexpr uint64_t cfg_offset() { return 0x80; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x80; }
	static constexpr uint64_t size() { return 16; }
};
struct MSICTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_38 format;
	static constexpr uint64_t cfg_offset() { return 0x82; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x82; }
	static constexpr uint64_t size() { return 16; }
};
struct MSIADDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_39 format;
	static constexpr uint64_t cfg_offset() { return 0x84; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x84; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIUADDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_40 format;
	static constexpr uint64_t cfg_offset() { return 0x88; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x88; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIDATA {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_41 format;
	static constexpr uint64_t cfg_offset() { return 0x8c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x8c; }
	static constexpr uint64_t size() { return 16; }
};
struct PMCAPLST {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_17 format;
	static constexpr uint64_t cfg_offset() { return 0xa0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa0; }
	static constexpr uint64_t size() { return 16; }
};
struct PMCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_43 format;
	static constexpr uint64_t cfg_offset() { return 0xa2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa2; }
	static constexpr uint64_t size() { return 16; }
};
struct PMCSR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_44 format;
	static constexpr uint64_t cfg_offset() { return 0xa4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa4; }
	static constexpr uint64_t size() { return 32; }
};
struct AERCAPHDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x100; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x100; }
	static constexpr uint64_t size() { return 32; }
};
struct UNCERRSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_46 format;
	static constexpr uint64_t cfg_offset() { return 0x104; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x104; }
	static constexpr uint64_t size() { return 32; }
};
struct UNCERRMSK {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_47 format;
	static constexpr uint64_t cfg_offset() { return 0x108; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x108; }
	static constexpr uint64_t size() { return 32; }
};
struct UNCERRSEV {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_46 format;
	static constexpr uint64_t cfg_offset() { return 0x10c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x10c; }
	static constexpr uint64_t size() { return 32; }
};
struct CORERRSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_49 format;
	static constexpr uint64_t cfg_offset() { return 0x110; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x110; }
	static constexpr uint64_t size() { return 32; }
};
struct CORERRMSK {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_50 format;
	static constexpr uint64_t cfg_offset() { return 0x114; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x114; }
	static constexpr uint64_t size() { return 32; }
};
struct AECAPCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_51 format;
	static constexpr uint64_t cfg_offset() { return 0x118; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x118; }
	static constexpr uint64_t size() { return 32; }
};
struct AERHDRLOG0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_52 format;
	static constexpr uint64_t cfg_offset() { return 0x11c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x11c; }
	static constexpr uint64_t size() { return 32; }
};
struct AERHDRLOG1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_52 format;
	static constexpr uint64_t cfg_offset() { return 0x120; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x120; }
	static constexpr uint64_t size() { return 32; }
};
struct AERHDRLOG2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_52 format;
	static constexpr uint64_t cfg_offset() { return 0x124; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x124; }
	static constexpr uint64_t size() { return 32; }
};
struct AERHDRLOG3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_52 format;
	static constexpr uint64_t cfg_offset() { return 0x128; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x128; }
	static constexpr uint64_t size() { return 32; }
};
struct AERPREFIXLOG0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_56 format;
	static constexpr uint64_t cfg_offset() { return 0x138; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x138; }
	static constexpr uint64_t size() { return 32; }
};
struct AERPREFIXLOG1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_57 format;
	static constexpr uint64_t cfg_offset() { return 0x13c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x13c; }
	static constexpr uint64_t size() { return 32; }
};
struct AERPREFIXLOG2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_58 format;
	static constexpr uint64_t cfg_offset() { return 0x140; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x140; }
	static constexpr uint64_t size() { return 32; }
};
struct AERPREFIXLOG3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_59 format;
	static constexpr uint64_t cfg_offset() { return 0x144; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x144; }
	static constexpr uint64_t size() { return 32; }
};
struct DEV3EXTCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x180; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x180; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVCAP3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_61 format;
	static constexpr uint64_t cfg_offset() { return 0x184; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x184; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVCTL3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_62 format;
	static constexpr uint64_t cfg_offset() { return 0x188; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x188; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVSTS3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_9 format;
	static constexpr uint64_t cfg_offset() { return 0x18c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x18c; }
	static constexpr uint64_t size() { return 32; }
};
struct MFVCCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x200; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x200; }
	static constexpr uint64_t size() { return 32; }
};
struct MFVCPVCCAP1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_65 format;
	static constexpr uint64_t cfg_offset() { return 0x204; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x204; }
	static constexpr uint64_t size() { return 32; }
};
struct MFVCPVCCAP2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_66 format;
	static constexpr uint64_t cfg_offset() { return 0x208; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x208; }
	static constexpr uint64_t size() { return 32; }
};
struct MFVCPVCCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_67 format;
	static constexpr uint64_t cfg_offset() { return 0x20c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x20c; }
	static constexpr uint64_t size() { return 16; }
};
struct MFVCPVCSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_68 format;
	static constexpr uint64_t cfg_offset() { return 0x20e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x20e; }
	static constexpr uint64_t size() { return 16; }
};
struct MFVCVC0RCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_69 format;
	static constexpr uint64_t cfg_offset() { return 0x210; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x210; }
	static constexpr uint64_t size() { return 32; }
};
struct MFVCVC0RCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_70 format;
	static constexpr uint64_t cfg_offset() { return 0x214; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x214; }
	static constexpr uint64_t size() { return 32; }
};
struct MFVCVC0RSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_71 format;
	static constexpr uint64_t cfg_offset() { return 0x21a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x21a; }
	static constexpr uint64_t size() { return 16; }
};
struct VCCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x300; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x300; }
	static constexpr uint64_t size() { return 32; }
};
struct PVCCAP1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_65 format;
	static constexpr uint64_t cfg_offset() { return 0x304; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x304; }
	static constexpr uint64_t size() { return 32; }
};
struct PVCCAP2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_66 format;
	static constexpr uint64_t cfg_offset() { return 0x308; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x308; }
	static constexpr uint64_t size() { return 32; }
};
struct PVCCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_67 format;
	static constexpr uint64_t cfg_offset() { return 0x30c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x30c; }
	static constexpr uint64_t size() { return 16; }
};
struct PVCSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_68 format;
	static constexpr uint64_t cfg_offset() { return 0x30e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x30e; }
	static constexpr uint64_t size() { return 16; }
};
struct VC0RCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_77 format;
	static constexpr uint64_t cfg_offset() { return 0x310; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x310; }
	static constexpr uint64_t size() { return 32; }
};
struct VC0RCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_70 format;
	static constexpr uint64_t cfg_offset() { return 0x314; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x314; }
	static constexpr uint64_t size() { return 32; }
};
struct VC0RSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_71 format;
	static constexpr uint64_t cfg_offset() { return 0x31a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x31a; }
	static constexpr uint64_t size() { return 16; }
};
struct MCCAPHDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x550; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x550; }
	static constexpr uint64_t size() { return 32; }
};
struct MCCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_81 format;
	static constexpr uint64_t cfg_offset() { return 0x554; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x554; }
	static constexpr uint64_t size() { return 16; }
};
struct MCCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_82 format;
	static constexpr uint64_t cfg_offset() { return 0x556; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x556; }
	static constexpr uint64_t size() { return 16; }
};
struct MCBARL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_83 format;
	static constexpr uint64_t cfg_offset() { return 0x558; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x558; }
	static constexpr uint64_t size() { return 32; }
};
struct MCBARU {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_84 format;
	static constexpr uint64_t cfg_offset() { return 0x55c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x55c; }
	static constexpr uint64_t size() { return 32; }
};
struct MCRCVL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_85 format;
	static constexpr uint64_t cfg_offset() { return 0x560; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x560; }
	static constexpr uint64_t size() { return 32; }
};
struct MCRCVU {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_84 format;
	static constexpr uint64_t cfg_offset() { return 0x564; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x564; }
	static constexpr uint64_t size() { return 32; }
};
struct MCBLKALLL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_87 format;
	static constexpr uint64_t cfg_offset() { return 0x568; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x568; }
	static constexpr uint64_t size() { return 32; }
};
struct MCBLKALLU {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_88 format;
	static constexpr uint64_t cfg_offset() { return 0x56c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x56c; }
	static constexpr uint64_t size() { return 32; }
};
struct MCBLKUTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_89 format;
	static constexpr uint64_t cfg_offset() { return 0x570; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x570; }
	static constexpr uint64_t size() { return 32; }
};
struct MCBLKUTU {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_90 format;
	static constexpr uint64_t cfg_offset() { return 0x574; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x574; }
	static constexpr uint64_t size() { return 32; }
};
struct LTRECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x588; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x588; }
	static constexpr uint64_t size() { return 32; }
};
struct LTRMAXS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_92 format;
	static constexpr uint64_t cfg_offset() { return 0x58c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x58c; }
	static constexpr uint64_t size() { return 16; }
};
struct LTRMAXNS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_93 format;
	static constexpr uint64_t cfg_offset() { return 0x58e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x58e; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x5b0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5b0; }
	static constexpr uint64_t size() { return 32; }
};
struct TPHCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_95 format;
	static constexpr uint64_t cfg_offset() { return 0x5b4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5b4; }
	static constexpr uint64_t size() { return 32; }
};
struct TPHCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_96 format;
	static constexpr uint64_t cfg_offset() { return 0x5b8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5b8; }
	static constexpr uint64_t size() { return 32; }
};
struct TPHSTTABLE0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5bc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5bc; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5be; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5be; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5c0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5c0; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5c2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5c2; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE4 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5c4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5c4; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE5 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5c6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5c6; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE6 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5c8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5c8; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE7 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5ca; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5ca; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE8 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5cc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5cc; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE9 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5ce; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5ce; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE10 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5d0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5d0; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE11 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5d2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5d2; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE12 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5d4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5d4; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE13 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5d6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5d6; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE14 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5d8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5d8; }
	static constexpr uint64_t size() { return 16; }
};
struct TPHSTTABLE15 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t cfg_offset() { return 0x5da; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x5da; }
	static constexpr uint64_t size() { return 16; }
};
struct ATSECAPH {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x6e0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x6e0; }
	static constexpr uint64_t size() { return 32; }
};
struct ATSCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_114 format;
	static constexpr uint64_t cfg_offset() { return 0x6e4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x6e4; }
	static constexpr uint64_t size() { return 16; }
};
struct ATSCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_115 format;
	static constexpr uint64_t cfg_offset() { return 0x6e6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x6e6; }
	static constexpr uint64_t size() { return 16; }
};
struct RSBCAPHDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x700; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x700; }
	static constexpr uint64_t size() { return 32; }
};
struct RSBCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_117 format;
	static constexpr uint64_t cfg_offset() { return 0x704; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x704; }
	static constexpr uint64_t size() { return 32; }
};
struct RSBCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_118 format;
	static constexpr uint64_t cfg_offset() { return 0x708; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x708; }
	static constexpr uint64_t size() { return 32; }
};
struct ARIECAPHDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x70c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x70c; }
	static constexpr uint64_t size() { return 32; }
};
struct ARICAPREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_120 format;
	static constexpr uint64_t cfg_offset() { return 0x710; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x710; }
	static constexpr uint64_t size() { return 16; }
};
struct ARICTRLREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_121 format;
	static constexpr uint64_t cfg_offset() { return 0x712; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x712; }
	static constexpr uint64_t size() { return 16; }
};
struct SECEXPCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x714; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x714; }
	static constexpr uint64_t size() { return 32; }
};
struct LINKCTRL3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_123 format;
	static constexpr uint64_t cfg_offset() { return 0x718; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x718; }
	static constexpr uint64_t size() { return 32; }
};
struct LANEERRSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_124 format;
	static constexpr uint64_t cfg_offset() { return 0x71c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x71c; }
	static constexpr uint64_t size() { return 32; }
};
struct LANEEQCTL0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x720; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x720; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x722; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x722; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x724; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x724; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x726; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x726; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL4 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x728; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x728; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL5 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x72a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x72a; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL6 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x72c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x72c; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL7 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x72e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x72e; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL8 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x730; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x730; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL9 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x732; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x732; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL10 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x734; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x734; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL11 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x736; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x736; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL12 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x738; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x738; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL13 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x73a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x73a; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL14 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x73c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x73c; }
	static constexpr uint64_t size() { return 16; }
};
struct LANEEQCTL15 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t cfg_offset() { return 0x73e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x73e; }
	static constexpr uint64_t size() { return 16; }
};
struct L1SUBEXTCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0x9d0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x9d0; }
	static constexpr uint64_t size() { return 32; }
};
struct L1SUBCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_142 format;
	static constexpr uint64_t cfg_offset() { return 0x9d4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x9d4; }
	static constexpr uint64_t size() { return 32; }
};
struct L1SUBCTL1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_143 format;
	static constexpr uint64_t cfg_offset() { return 0x9d8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x9d8; }
	static constexpr uint64_t size() { return 32; }
};
struct L1SUBCTL2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_144 format;
	static constexpr uint64_t cfg_offset() { return 0x9dc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x9dc; }
	static constexpr uint64_t size() { return 32; }
};
struct L1SUBSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_145 format;
	static constexpr uint64_t cfg_offset() { return 0x9e0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0x9e0; }
	static constexpr uint64_t size() { return 32; }
};
struct DLFECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xa00; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa00; }
	static constexpr uint64_t size() { return 32; }
};
struct DLFECAPREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_147 format;
	static constexpr uint64_t cfg_offset() { return 0xa04; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa04; }
	static constexpr uint64_t size() { return 32; }
};
struct DLFSTSREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_148 format;
	static constexpr uint64_t cfg_offset() { return 0xa08; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa08; }
	static constexpr uint64_t size() { return 32; }
};
struct PL16ECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xa20; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa20; }
	static constexpr uint64_t size() { return 32; }
};
struct PL16CAPREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_9 format;
	static constexpr uint64_t cfg_offset() { return 0xa24; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa24; }
	static constexpr uint64_t size() { return 32; }
};
struct PL16CTLREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_9 format;
	static constexpr uint64_t cfg_offset() { return 0xa28; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa28; }
	static constexpr uint64_t size() { return 32; }
};
struct PL16STSREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_152 format;
	static constexpr uint64_t cfg_offset() { return 0xa2c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa2c; }
	static constexpr uint64_t size() { return 32; }
};
struct PL16LDPMSREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_153 format;
	static constexpr uint64_t cfg_offset() { return 0xa30; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa30; }
	static constexpr uint64_t size() { return 32; }
};
struct FRDPMSREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_154 format;
	static constexpr uint64_t cfg_offset() { return 0xa34; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa34; }
	static constexpr uint64_t size() { return 32; }
};
struct SRDPMSREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_155 format;
	static constexpr uint64_t cfg_offset() { return 0xa38; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa38; }
	static constexpr uint64_t size() { return 32; }
};
struct PL16RSVD {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_9 format;
	static constexpr uint64_t cfg_offset() { return 0xa3c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa3c; }
	static constexpr uint64_t size() { return 32; }
};
struct PL16LANEEQCTL0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa40; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa40; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa41; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa41; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa42; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa42; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa43; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa43; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL4 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa44; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa44; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL5 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa45; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa45; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL6 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa46; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa46; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL7 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa47; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa47; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL8 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa48; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa48; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL9 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa49; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa49; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL10 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa4a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa4a; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL11 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa4b; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa4b; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL12 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa4c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa4c; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL13 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa4d; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa4d; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL14 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa4e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa4e; }
	static constexpr uint64_t size() { return 8; }
};
struct PL16LANEEQCTL15 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t cfg_offset() { return 0xa4f; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa4f; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32ECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xa80; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa80; }
	static constexpr uint64_t size() { return 32; }
};
struct PL32CAPREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_174 format;
	static constexpr uint64_t cfg_offset() { return 0xa84; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa84; }
	static constexpr uint64_t size() { return 32; }
};
struct PL32CTLREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_175 format;
	static constexpr uint64_t cfg_offset() { return 0xa88; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa88; }
	static constexpr uint64_t size() { return 32; }
};
struct PL32STSREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_176 format;
	static constexpr uint64_t cfg_offset() { return 0xa8c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa8c; }
	static constexpr uint64_t size() { return 32; }
};
/* This register contains the values received in the Modified TS1/TS2 Ordered Set (see Table 4-8 ).  */
struct PL32RXMTS1REG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_177 format;
	static constexpr uint64_t cfg_offset() { return 0xa90; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa90; }
	static constexpr uint64_t size() { return 32; }
};
/* This register contains the values received in Symbols 12 through 14 of the Modified TS1/TS2 Ordered Set (see Table
 * 4-8 ).  */
struct PL32RXMTS2REG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_178 format;
	static constexpr uint64_t cfg_offset() { return 0xa94; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa94; }
	static constexpr uint64_t size() { return 32; }
};
/* This register contains the values Transmitted in the Modified TS1/TS2 Ordered Set (see Table 4-8 ).  */
struct PL32TXMTS1REG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_179 format;
	static constexpr uint64_t cfg_offset() { return 0xa98; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa98; }
	static constexpr uint64_t size() { return 32; }
};
/* This register contains the values received in Symbols 12 through 14 of the Modified TS1/TS2 Ordered Set (see Table
 * 4-8 ).  */
struct PL32TXMTS2REG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_178 format;
	static constexpr uint64_t cfg_offset() { return 0xa9c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xa9c; }
	static constexpr uint64_t size() { return 32; }
};
struct PL32LANEEQCTL0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa0; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa1; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa1; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa2; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa3; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa3; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL4 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa4; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL5 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa5; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa5; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL6 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa6; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL7 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa7; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa7; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL8 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa8; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL9 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaa9; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaa9; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL10 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaaa; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaaa; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL11 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaab; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaab; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL12 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaac; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaac; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL13 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaad; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaad; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL14 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaae; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaae; }
	static constexpr uint64_t size() { return 8; }
};
struct PL32LANEEQCTL15 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t cfg_offset() { return 0xaaf; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaaf; }
	static constexpr uint64_t size() { return 8; }
};
struct LMRECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xac0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xac0; }
	static constexpr uint64_t size() { return 32; }
};
struct MPCAPREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t cfg_offset() { return 0xac4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xac4; }
	static constexpr uint64_t size() { return 16; }
};
struct MPSTSREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_199 format;
	static constexpr uint64_t cfg_offset() { return 0xac6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xac6; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xac8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xac8; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xaca; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaca; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xacc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xacc; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xace; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xace; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xad0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xad0; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xad2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xad2; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xad4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xad4; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xad6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xad6; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG4 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xad8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xad8; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG4 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xada; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xada; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG5 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xadc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xadc; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG5 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xade; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xade; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG6 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xae0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xae0; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG6 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xae2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xae2; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG7 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xae4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xae4; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG7 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xae6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xae6; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG8 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xae8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xae8; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG8 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xaea; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaea; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG9 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xaec; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaec; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG9 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xaee; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaee; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG10 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xaf0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaf0; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG10 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xaf2; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaf2; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG11 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xaf4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaf4; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG11 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xaf6; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaf6; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG12 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xaf8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xaf8; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG12 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xafa; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xafa; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG13 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xafc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xafc; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG13 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xafe; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xafe; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG14 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xb00; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb00; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG14 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xb02; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb02; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNCTLREG15 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_200 format;
	static constexpr uint64_t cfg_offset() { return 0xb04; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb04; }
	static constexpr uint64_t size() { return 16; }
};
struct MLNSTSREG15 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_201 format;
	static constexpr uint64_t cfg_offset() { return 0xb06; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb06; }
	static constexpr uint64_t size() { return 16; }
};
struct PRECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xb20; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb20; }
	static constexpr uint64_t size() { return 32; }
};
struct PRCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_233 format;
	static constexpr uint64_t cfg_offset() { return 0xb24; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb24; }
	static constexpr uint64_t size() { return 16; }
};
struct PRSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_234 format;
	static constexpr uint64_t cfg_offset() { return 0xb26; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb26; }
	static constexpr uint64_t size() { return 16; }
};
struct OPRCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_235 format;
	static constexpr uint64_t cfg_offset() { return 0xb28; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb28; }
	static constexpr uint64_t size() { return 32; }
};
struct OPRALLOC {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_236 format;
	static constexpr uint64_t cfg_offset() { return 0xb2c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb2c; }
	static constexpr uint64_t size() { return 32; }
};
struct PASIDECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xb40; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb40; }
	static constexpr uint64_t size() { return 32; }
};
struct PASIDCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_238 format;
	static constexpr uint64_t cfg_offset() { return 0xb44; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb44; }
	static constexpr uint64_t size() { return 16; }
};
struct PASIDCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_239 format;
	static constexpr uint64_t cfg_offset() { return 0xb46; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb46; }
	static constexpr uint64_t size() { return 16; }
};
struct PTMECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xb50; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb50; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMCAPREG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_241 format;
	static constexpr uint64_t cfg_offset() { return 0xb54; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb54; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMECTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_242 format;
	static constexpr uint64_t cfg_offset() { return 0xb58; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb58; }
	static constexpr uint64_t size() { return 32; }
};
struct SRIOVECAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xb80; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb80; }
	static constexpr uint64_t size() { return 32; }
};
struct SRIOVCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_244 format;
	static constexpr uint64_t cfg_offset() { return 0xb84; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb84; }
	static constexpr uint64_t size() { return 32; }
};
struct SRIOVCTL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_245 format;
	static constexpr uint64_t cfg_offset() { return 0xb88; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb88; }
	static constexpr uint64_t size() { return 16; }
};
struct SRIOVSTS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_246 format;
	static constexpr uint64_t cfg_offset() { return 0xb8a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb8a; }
	static constexpr uint64_t size() { return 16; }
};
/* Number of VFs that are initially associated with the PF */
struct INITVFSFN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_247 format;
	static constexpr uint64_t cfg_offset() { return 0xb8c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb8c; }
	static constexpr uint64_t size() { return 16; }
};
struct TOTVFSFN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_248 format;
	static constexpr uint64_t cfg_offset() { return 0xb8e; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb8e; }
	static constexpr uint64_t size() { return 16; }
};
struct NUMVFSFN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_249 format;
	static constexpr uint64_t cfg_offset() { return 0xb90; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb90; }
	static constexpr uint64_t size() { return 16; }
};
struct SRIOVFDL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_250 format;
	static constexpr uint64_t cfg_offset() { return 0xb92; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb92; }
	static constexpr uint64_t size() { return 16; }
};
struct FSTVFOFF {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_251 format;
	static constexpr uint64_t cfg_offset() { return 0xb94; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb94; }
	static constexpr uint64_t size() { return 16; }
};
struct VFSTRIDE {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_252 format;
	static constexpr uint64_t cfg_offset() { return 0xb96; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb96; }
	static constexpr uint64_t size() { return 16; }
};
struct VFDID {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_1 format;
	static constexpr uint64_t cfg_offset() { return 0xb9a; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb9a; }
	static constexpr uint64_t size() { return 16; }
};
struct SUPPFPS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_254 format;
	static constexpr uint64_t cfg_offset() { return 0xb9c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xb9c; }
	static constexpr uint64_t size() { return 32; }
};
struct SYSPS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_255 format;
	static constexpr uint64_t cfg_offset() { return 0xba0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xba0; }
	static constexpr uint64_t size() { return 32; }
};
struct VFBAR0FN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_256 format;
	static constexpr uint64_t cfg_offset() { return 0xba4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xba4; }
	static constexpr uint64_t size() { return 32; }
};
struct VFBAR1FN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_257 format;
	static constexpr uint64_t cfg_offset() { return 0xba8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xba8; }
	static constexpr uint64_t size() { return 32; }
};
struct VFBAR2FN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_258 format;
	static constexpr uint64_t cfg_offset() { return 0xbac; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xbac; }
	static constexpr uint64_t size() { return 32; }
};
struct VFBAR3FN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_259 format;
	static constexpr uint64_t cfg_offset() { return 0xbb0; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xbb0; }
	static constexpr uint64_t size() { return 32; }
};
struct VFBAR4FN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_260 format;
	static constexpr uint64_t cfg_offset() { return 0xbb4; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xbb4; }
	static constexpr uint64_t size() { return 32; }
};
struct VFBAR5FN0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_7 format;
	static constexpr uint64_t cfg_offset() { return 0xbb8; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xbb8; }
	static constexpr uint64_t size() { return 32; }
};
struct VFMSA {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_262 format;
	static constexpr uint64_t cfg_offset() { return 0xbbc; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xbbc; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVSNCAPHDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xc00; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xc00; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVSNLOW {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_264 format;
	static constexpr uint64_t cfg_offset() { return 0xc04; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xc04; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVSNHIGH {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_265 format;
	static constexpr uint64_t cfg_offset() { return 0xc08; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xc08; }
	static constexpr uint64_t size() { return 32; }
};
struct VSEHDRCAP {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t cfg_offset() { return 0xd00; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd00; }
	static constexpr uint64_t size() { return 32; }
};
struct VSHDR {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_267 format;
	static constexpr uint64_t cfg_offset() { return 0xd04; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd04; }
	static constexpr uint64_t size() { return 32; }
};
struct PREFETCHCTRL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_268 format;
	static constexpr uint64_t cfg_offset() { return 0xd08; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd08; }
	static constexpr uint64_t size() { return 32; }
};
struct COREINFO {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_269 format;
	static constexpr uint64_t cfg_offset() { return 0xd0c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd0c; }
	static constexpr uint64_t size() { return 32; }
};
struct IMAGEREV {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_270 format;
	static constexpr uint64_t cfg_offset() { return 0xd10; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd10; }
	static constexpr uint64_t size() { return 32; }
};
struct BUILDREV {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_271 format;
	static constexpr uint64_t cfg_offset() { return 0xd14; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd14; }
	static constexpr uint64_t size() { return 32; }
};
struct BOARDINFO {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_272 format;
	static constexpr uint64_t cfg_offset() { return 0xd18; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd18; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTSCRATCH0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_273 format;
	static constexpr uint64_t cfg_offset() { return 0xd20; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd20; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTSCRATCH1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_273 format;
	static constexpr uint64_t cfg_offset() { return 0xd24; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd24; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTSCRATCH2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_273 format;
	static constexpr uint64_t cfg_offset() { return 0xd28; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd28; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTSCRATCH3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_273 format;
	static constexpr uint64_t cfg_offset() { return 0xd2c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd2c; }
	static constexpr uint64_t size() { return 32; }
};
/* Event commands are writes to this register with a valid bit set.[br]
Event commands are recognized only when a VM is configured in EVENT MODE. In other modes, the writes are dropped.[br]
If the EVENT MODE VM is idle, then the event commands are queued into the command queue. Up to 16 event commands may be
queued. If queue is full, event commands are dropped.[br]
If the EVENT mode VM is active, the event command will generate a vector fetch.[br]
Physical register is visible in Memory Mapped, Configuration and IO Space. */
struct ETRIG {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_277 format;
	static constexpr uint64_t cfg_offset() { return 0xd30; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd30; }
	static constexpr uint64_t size() { return 32; }
};
/* This register is updated by an external agent to release streams paused on the external flag.[br]
This write will increment the associated internal Continue Counter.[br]
Physical register is visible in Memory Mapped, Configuration and IO Space.[br]
In normal mode, use Stream-ID=00 to release the paused vector. */
struct EXTPSE {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_277 format;
	static constexpr uint64_t cfg_offset() { return 0xd34; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd34; }
	static constexpr uint64_t size() { return 32; }
};
/* The update [lb]either external agent or another VM[rb] will increment an associated counter.[br]
This is used for the single poll loop only. The poll read is considered a 'match' if the associated continue counter is
non-zero. There is no associated Data Pattern and Mask like the external poll.[br]
Physical register is visible in Memory Mapped, Configuration and IO Space.[br]
In normal mode, use STR-ID=00 to release the paused vector. */
struct INTPOLL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_277 format;
	static constexpr uint64_t cfg_offset() { return 0xd38; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd38; }
	static constexpr uint64_t size() { return 32; }
};
/* This register can be updated by VM via internal access vector to release streams paused on the internal flag.[br]
The write will increment the associated internal Continue Counter.[br]
Use this register as an 'Emergency Release' to release a paused vector.[br]
Physical register is visible in Memory Mapped, Configuration and IO Space.[br]
In normal mode, use STR-ID=00 to release the paused vector. */
struct INTPSE {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_277 format;
	static constexpr uint64_t cfg_offset() { return 0xd3c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd3c; }
	static constexpr uint64_t size() { return 32; }
};
struct UPDREG0 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_281 format;
	static constexpr uint64_t cfg_offset() { return 0xd40; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd40; }
	static constexpr uint64_t size() { return 32; }
};
struct UPDREG1 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_281 format;
	static constexpr uint64_t cfg_offset() { return 0xd44; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd44; }
	static constexpr uint64_t size() { return 32; }
};
struct UPDREG2 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_281 format;
	static constexpr uint64_t cfg_offset() { return 0xd48; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd48; }
	static constexpr uint64_t size() { return 32; }
};
struct UPDREG3 {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_281 format;
	static constexpr uint64_t cfg_offset() { return 0xd4c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd4c; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMCTRL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_285 format;
	static constexpr uint64_t cfg_offset() { return 0xd50; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd50; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMSTATUS {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_286 format;
	static constexpr uint64_t cfg_offset() { return 0xd54; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd54; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMREQCTRL {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_287 format;
	static constexpr uint64_t cfg_offset() { return 0xd58; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd58; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMREQCLKCORLSB {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_288 format;
	static constexpr uint64_t cfg_offset() { return 0xd5c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd5c; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMTHRESH {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_289 format;
	static constexpr uint64_t cfg_offset() { return 0xd60; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd60; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMTRIGTM {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_290 format;
	static constexpr uint64_t cfg_offset() { return 0xd64; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd64; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMTRIGMSK {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_291 format;
	static constexpr uint64_t cfg_offset() { return 0xd68; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd68; }
	static constexpr uint64_t size() { return 32; }
};
struct PTMCAPTTM {
	typedef cambria_rnr_func0_cfgFmt::FORMAT_292 format;
	static constexpr uint64_t cfg_offset() { return 0xd6c; }
	static constexpr uint64_t mmio_offset() { return 0xE'0000 + 0xd6c; }
	static constexpr uint64_t size() { return 32; }
};
struct Container {
	typedef cambria_rnr_func0_cfg::VID VID;
	typedef cambria_rnr_func0_cfg::DID DID;
	typedef cambria_rnr_func0_cfg::PCICMD PCICMD;
	typedef cambria_rnr_func0_cfg::PCISTS PCISTS;
	typedef cambria_rnr_func0_cfg::CCRID CCRID;
	typedef cambria_rnr_func0_cfg::PCIMISC PCIMISC;
	typedef cambria_rnr_func0_cfg::BAR0 BAR0;
	typedef cambria_rnr_func0_cfg::BAR1 BAR1;
	typedef cambria_rnr_func0_cfg::BAR2 BAR2;
	typedef cambria_rnr_func0_cfg::BAR3 BAR3;
	typedef cambria_rnr_func0_cfg::BAR4 BAR4;
	typedef cambria_rnr_func0_cfg::BAR5 BAR5;
	typedef cambria_rnr_func0_cfg::CAPPTR CAPPTR;
	typedef cambria_rnr_func0_cfg::INTRLINE INTRLINE;
	typedef cambria_rnr_func0_cfg::INTRPIN INTRPIN;
	typedef cambria_rnr_func0_cfg::MINGNT MINGNT;
	typedef cambria_rnr_func0_cfg::MAXLAT MAXLAT;
	typedef cambria_rnr_func0_cfg::EXPCAPLST EXPCAPLST;
	typedef cambria_rnr_func0_cfg::EXPCAP EXPCAP;
	typedef cambria_rnr_func0_cfg::DEVCAP DEVCAP;
	typedef cambria_rnr_func0_cfg::DEVCTL DEVCTL;
	typedef cambria_rnr_func0_cfg::DEVSTS DEVSTS;
	typedef cambria_rnr_func0_cfg::LINKCAP LINKCAP;
	typedef cambria_rnr_func0_cfg::LINKCTL LINKCTL;
	typedef cambria_rnr_func0_cfg::LINKSTS LINKSTS;
	typedef cambria_rnr_func0_cfg::SLOTCAP SLOTCAP;
	typedef cambria_rnr_func0_cfg::SLOTCTL SLOTCTL;
	typedef cambria_rnr_func0_cfg::SLOTSTS SLOTSTS;
	typedef cambria_rnr_func0_cfg::DEVCAP2 DEVCAP2;
	typedef cambria_rnr_func0_cfg::DEVCTL2 DEVCTL2;
	typedef cambria_rnr_func0_cfg::DEVSTS2 DEVSTS2;
	typedef cambria_rnr_func0_cfg::LINKCAP2 LINKCAP2;
	typedef cambria_rnr_func0_cfg::LINKCTL2 LINKCTL2;
	typedef cambria_rnr_func0_cfg::LINKSTS2 LINKSTS2;
	typedef cambria_rnr_func0_cfg::SLOTCAP2 SLOTCAP2;
	typedef cambria_rnr_func0_cfg::SLOTCTL2 SLOTCTL2;
	typedef cambria_rnr_func0_cfg::SLOTSTS2 SLOTSTS2;
	typedef cambria_rnr_func0_cfg::MSICAPLST MSICAPLST;
	typedef cambria_rnr_func0_cfg::MSICTL MSICTL;
	typedef cambria_rnr_func0_cfg::MSIADDR MSIADDR;
	typedef cambria_rnr_func0_cfg::MSIUADDR MSIUADDR;
	typedef cambria_rnr_func0_cfg::MSIDATA MSIDATA;
	typedef cambria_rnr_func0_cfg::PMCAPLST PMCAPLST;
	typedef cambria_rnr_func0_cfg::PMCAP PMCAP;
	typedef cambria_rnr_func0_cfg::PMCSR PMCSR;
	typedef cambria_rnr_func0_cfg::AERCAPHDR AERCAPHDR;
	typedef cambria_rnr_func0_cfg::UNCERRSTS UNCERRSTS;
	typedef cambria_rnr_func0_cfg::UNCERRMSK UNCERRMSK;
	typedef cambria_rnr_func0_cfg::UNCERRSEV UNCERRSEV;
	typedef cambria_rnr_func0_cfg::CORERRSTS CORERRSTS;
	typedef cambria_rnr_func0_cfg::CORERRMSK CORERRMSK;
	typedef cambria_rnr_func0_cfg::AECAPCTL AECAPCTL;
	typedef cambria_rnr_func0_cfg::AERHDRLOG0 AERHDRLOG0;
	typedef cambria_rnr_func0_cfg::AERHDRLOG1 AERHDRLOG1;
	typedef cambria_rnr_func0_cfg::AERHDRLOG2 AERHDRLOG2;
	typedef cambria_rnr_func0_cfg::AERHDRLOG3 AERHDRLOG3;
	typedef cambria_rnr_func0_cfg::AERPREFIXLOG0 AERPREFIXLOG0;
	typedef cambria_rnr_func0_cfg::AERPREFIXLOG1 AERPREFIXLOG1;
	typedef cambria_rnr_func0_cfg::AERPREFIXLOG2 AERPREFIXLOG2;
	typedef cambria_rnr_func0_cfg::AERPREFIXLOG3 AERPREFIXLOG3;
	typedef cambria_rnr_func0_cfg::DEV3EXTCAP DEV3EXTCAP;
	typedef cambria_rnr_func0_cfg::DEVCAP3 DEVCAP3;
	typedef cambria_rnr_func0_cfg::DEVCTL3 DEVCTL3;
	typedef cambria_rnr_func0_cfg::DEVSTS3 DEVSTS3;
	typedef cambria_rnr_func0_cfg::MFVCCAP MFVCCAP;
	typedef cambria_rnr_func0_cfg::MFVCPVCCAP1 MFVCPVCCAP1;
	typedef cambria_rnr_func0_cfg::MFVCPVCCAP2 MFVCPVCCAP2;
	typedef cambria_rnr_func0_cfg::MFVCPVCCTL MFVCPVCCTL;
	typedef cambria_rnr_func0_cfg::MFVCPVCSTS MFVCPVCSTS;
	typedef cambria_rnr_func0_cfg::MFVCVC0RCAP MFVCVC0RCAP;
	typedef cambria_rnr_func0_cfg::MFVCVC0RCTL MFVCVC0RCTL;
	typedef cambria_rnr_func0_cfg::MFVCVC0RSTS MFVCVC0RSTS;
	typedef cambria_rnr_func0_cfg::VCCAP VCCAP;
	typedef cambria_rnr_func0_cfg::PVCCAP1 PVCCAP1;
	typedef cambria_rnr_func0_cfg::PVCCAP2 PVCCAP2;
	typedef cambria_rnr_func0_cfg::PVCCTL PVCCTL;
	typedef cambria_rnr_func0_cfg::PVCSTS PVCSTS;
	typedef cambria_rnr_func0_cfg::VC0RCAP VC0RCAP;
	typedef cambria_rnr_func0_cfg::VC0RCTL VC0RCTL;
	typedef cambria_rnr_func0_cfg::VC0RSTS VC0RSTS;
	typedef cambria_rnr_func0_cfg::MCCAPHDR MCCAPHDR;
	typedef cambria_rnr_func0_cfg::MCCAP MCCAP;
	typedef cambria_rnr_func0_cfg::MCCTL MCCTL;
	typedef cambria_rnr_func0_cfg::MCBARL MCBARL;
	typedef cambria_rnr_func0_cfg::MCBARU MCBARU;
	typedef cambria_rnr_func0_cfg::MCRCVL MCRCVL;
	typedef cambria_rnr_func0_cfg::MCRCVU MCRCVU;
	typedef cambria_rnr_func0_cfg::MCBLKALLL MCBLKALLL;
	typedef cambria_rnr_func0_cfg::MCBLKALLU MCBLKALLU;
	typedef cambria_rnr_func0_cfg::MCBLKUTL MCBLKUTL;
	typedef cambria_rnr_func0_cfg::MCBLKUTU MCBLKUTU;
	typedef cambria_rnr_func0_cfg::LTRECAP LTRECAP;
	typedef cambria_rnr_func0_cfg::LTRMAXS LTRMAXS;
	typedef cambria_rnr_func0_cfg::LTRMAXNS LTRMAXNS;
	typedef cambria_rnr_func0_cfg::TPHECAP TPHECAP;
	typedef cambria_rnr_func0_cfg::TPHCAP TPHCAP;
	typedef cambria_rnr_func0_cfg::TPHCTL TPHCTL;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE0 TPHSTTABLE0;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE1 TPHSTTABLE1;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE2 TPHSTTABLE2;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE3 TPHSTTABLE3;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE4 TPHSTTABLE4;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE5 TPHSTTABLE5;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE6 TPHSTTABLE6;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE7 TPHSTTABLE7;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE8 TPHSTTABLE8;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE9 TPHSTTABLE9;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE10 TPHSTTABLE10;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE11 TPHSTTABLE11;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE12 TPHSTTABLE12;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE13 TPHSTTABLE13;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE14 TPHSTTABLE14;
	typedef cambria_rnr_func0_cfg::TPHSTTABLE15 TPHSTTABLE15;
	typedef cambria_rnr_func0_cfg::ATSECAPH ATSECAPH;
	typedef cambria_rnr_func0_cfg::ATSCAP ATSCAP;
	typedef cambria_rnr_func0_cfg::ATSCTL ATSCTL;
	typedef cambria_rnr_func0_cfg::RSBCAPHDR RSBCAPHDR;
	typedef cambria_rnr_func0_cfg::RSBCAP RSBCAP;
	typedef cambria_rnr_func0_cfg::RSBCTL RSBCTL;
	typedef cambria_rnr_func0_cfg::ARIECAPHDR ARIECAPHDR;
	typedef cambria_rnr_func0_cfg::ARICAPREG ARICAPREG;
	typedef cambria_rnr_func0_cfg::ARICTRLREG ARICTRLREG;
	typedef cambria_rnr_func0_cfg::SECEXPCAP SECEXPCAP;
	typedef cambria_rnr_func0_cfg::LINKCTRL3 LINKCTRL3;
	typedef cambria_rnr_func0_cfg::LANEERRSTS LANEERRSTS;
	typedef cambria_rnr_func0_cfg::LANEEQCTL0 LANEEQCTL0;
	typedef cambria_rnr_func0_cfg::LANEEQCTL1 LANEEQCTL1;
	typedef cambria_rnr_func0_cfg::LANEEQCTL2 LANEEQCTL2;
	typedef cambria_rnr_func0_cfg::LANEEQCTL3 LANEEQCTL3;
	typedef cambria_rnr_func0_cfg::LANEEQCTL4 LANEEQCTL4;
	typedef cambria_rnr_func0_cfg::LANEEQCTL5 LANEEQCTL5;
	typedef cambria_rnr_func0_cfg::LANEEQCTL6 LANEEQCTL6;
	typedef cambria_rnr_func0_cfg::LANEEQCTL7 LANEEQCTL7;
	typedef cambria_rnr_func0_cfg::LANEEQCTL8 LANEEQCTL8;
	typedef cambria_rnr_func0_cfg::LANEEQCTL9 LANEEQCTL9;
	typedef cambria_rnr_func0_cfg::LANEEQCTL10 LANEEQCTL10;
	typedef cambria_rnr_func0_cfg::LANEEQCTL11 LANEEQCTL11;
	typedef cambria_rnr_func0_cfg::LANEEQCTL12 LANEEQCTL12;
	typedef cambria_rnr_func0_cfg::LANEEQCTL13 LANEEQCTL13;
	typedef cambria_rnr_func0_cfg::LANEEQCTL14 LANEEQCTL14;
	typedef cambria_rnr_func0_cfg::LANEEQCTL15 LANEEQCTL15;
	typedef cambria_rnr_func0_cfg::L1SUBEXTCAP L1SUBEXTCAP;
	typedef cambria_rnr_func0_cfg::L1SUBCAP L1SUBCAP;
	typedef cambria_rnr_func0_cfg::L1SUBCTL1 L1SUBCTL1;
	typedef cambria_rnr_func0_cfg::L1SUBCTL2 L1SUBCTL2;
	typedef cambria_rnr_func0_cfg::L1SUBSTS L1SUBSTS;
	typedef cambria_rnr_func0_cfg::DLFECAP DLFECAP;
	typedef cambria_rnr_func0_cfg::DLFECAPREG DLFECAPREG;
	typedef cambria_rnr_func0_cfg::DLFSTSREG DLFSTSREG;
	typedef cambria_rnr_func0_cfg::PL16ECAP PL16ECAP;
	typedef cambria_rnr_func0_cfg::PL16CAPREG PL16CAPREG;
	typedef cambria_rnr_func0_cfg::PL16CTLREG PL16CTLREG;
	typedef cambria_rnr_func0_cfg::PL16STSREG PL16STSREG;
	typedef cambria_rnr_func0_cfg::PL16LDPMSREG PL16LDPMSREG;
	typedef cambria_rnr_func0_cfg::FRDPMSREG FRDPMSREG;
	typedef cambria_rnr_func0_cfg::SRDPMSREG SRDPMSREG;
	typedef cambria_rnr_func0_cfg::PL16RSVD PL16RSVD;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL0 PL16LANEEQCTL0;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL1 PL16LANEEQCTL1;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL2 PL16LANEEQCTL2;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL3 PL16LANEEQCTL3;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL4 PL16LANEEQCTL4;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL5 PL16LANEEQCTL5;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL6 PL16LANEEQCTL6;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL7 PL16LANEEQCTL7;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL8 PL16LANEEQCTL8;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL9 PL16LANEEQCTL9;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL10 PL16LANEEQCTL10;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL11 PL16LANEEQCTL11;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL12 PL16LANEEQCTL12;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL13 PL16LANEEQCTL13;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL14 PL16LANEEQCTL14;
	typedef cambria_rnr_func0_cfg::PL16LANEEQCTL15 PL16LANEEQCTL15;
	typedef cambria_rnr_func0_cfg::PL32ECAP PL32ECAP;
	typedef cambria_rnr_func0_cfg::PL32CAPREG PL32CAPREG;
	typedef cambria_rnr_func0_cfg::PL32CTLREG PL32CTLREG;
	typedef cambria_rnr_func0_cfg::PL32STSREG PL32STSREG;
	typedef cambria_rnr_func0_cfg::PL32RXMTS1REG PL32RXMTS1REG;
	typedef cambria_rnr_func0_cfg::PL32RXMTS2REG PL32RXMTS2REG;
	typedef cambria_rnr_func0_cfg::PL32TXMTS1REG PL32TXMTS1REG;
	typedef cambria_rnr_func0_cfg::PL32TXMTS2REG PL32TXMTS2REG;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL0 PL32LANEEQCTL0;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL1 PL32LANEEQCTL1;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL2 PL32LANEEQCTL2;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL3 PL32LANEEQCTL3;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL4 PL32LANEEQCTL4;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL5 PL32LANEEQCTL5;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL6 PL32LANEEQCTL6;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL7 PL32LANEEQCTL7;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL8 PL32LANEEQCTL8;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL9 PL32LANEEQCTL9;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL10 PL32LANEEQCTL10;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL11 PL32LANEEQCTL11;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL12 PL32LANEEQCTL12;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL13 PL32LANEEQCTL13;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL14 PL32LANEEQCTL14;
	typedef cambria_rnr_func0_cfg::PL32LANEEQCTL15 PL32LANEEQCTL15;
	typedef cambria_rnr_func0_cfg::LMRECAP LMRECAP;
	typedef cambria_rnr_func0_cfg::MPCAPREG MPCAPREG;
	typedef cambria_rnr_func0_cfg::MPSTSREG MPSTSREG;
	typedef cambria_rnr_func0_cfg::MLNCTLREG0 MLNCTLREG0;
	typedef cambria_rnr_func0_cfg::MLNSTSREG0 MLNSTSREG0;
	typedef cambria_rnr_func0_cfg::MLNCTLREG1 MLNCTLREG1;
	typedef cambria_rnr_func0_cfg::MLNSTSREG1 MLNSTSREG1;
	typedef cambria_rnr_func0_cfg::MLNCTLREG2 MLNCTLREG2;
	typedef cambria_rnr_func0_cfg::MLNSTSREG2 MLNSTSREG2;
	typedef cambria_rnr_func0_cfg::MLNCTLREG3 MLNCTLREG3;
	typedef cambria_rnr_func0_cfg::MLNSTSREG3 MLNSTSREG3;
	typedef cambria_rnr_func0_cfg::MLNCTLREG4 MLNCTLREG4;
	typedef cambria_rnr_func0_cfg::MLNSTSREG4 MLNSTSREG4;
	typedef cambria_rnr_func0_cfg::MLNCTLREG5 MLNCTLREG5;
	typedef cambria_rnr_func0_cfg::MLNSTSREG5 MLNSTSREG5;
	typedef cambria_rnr_func0_cfg::MLNCTLREG6 MLNCTLREG6;
	typedef cambria_rnr_func0_cfg::MLNSTSREG6 MLNSTSREG6;
	typedef cambria_rnr_func0_cfg::MLNCTLREG7 MLNCTLREG7;
	typedef cambria_rnr_func0_cfg::MLNSTSREG7 MLNSTSREG7;
	typedef cambria_rnr_func0_cfg::MLNCTLREG8 MLNCTLREG8;
	typedef cambria_rnr_func0_cfg::MLNSTSREG8 MLNSTSREG8;
	typedef cambria_rnr_func0_cfg::MLNCTLREG9 MLNCTLREG9;
	typedef cambria_rnr_func0_cfg::MLNSTSREG9 MLNSTSREG9;
	typedef cambria_rnr_func0_cfg::MLNCTLREG10 MLNCTLREG10;
	typedef cambria_rnr_func0_cfg::MLNSTSREG10 MLNSTSREG10;
	typedef cambria_rnr_func0_cfg::MLNCTLREG11 MLNCTLREG11;
	typedef cambria_rnr_func0_cfg::MLNSTSREG11 MLNSTSREG11;
	typedef cambria_rnr_func0_cfg::MLNCTLREG12 MLNCTLREG12;
	typedef cambria_rnr_func0_cfg::MLNSTSREG12 MLNSTSREG12;
	typedef cambria_rnr_func0_cfg::MLNCTLREG13 MLNCTLREG13;
	typedef cambria_rnr_func0_cfg::MLNSTSREG13 MLNSTSREG13;
	typedef cambria_rnr_func0_cfg::MLNCTLREG14 MLNCTLREG14;
	typedef cambria_rnr_func0_cfg::MLNSTSREG14 MLNSTSREG14;
	typedef cambria_rnr_func0_cfg::MLNCTLREG15 MLNCTLREG15;
	typedef cambria_rnr_func0_cfg::MLNSTSREG15 MLNSTSREG15;
	typedef cambria_rnr_func0_cfg::PRECAP PRECAP;
	typedef cambria_rnr_func0_cfg::PRCTL PRCTL;
	typedef cambria_rnr_func0_cfg::PRSTS PRSTS;
	typedef cambria_rnr_func0_cfg::OPRCAP OPRCAP;
	typedef cambria_rnr_func0_cfg::OPRALLOC OPRALLOC;
	typedef cambria_rnr_func0_cfg::PASIDECAP PASIDECAP;
	typedef cambria_rnr_func0_cfg::PASIDCAP PASIDCAP;
	typedef cambria_rnr_func0_cfg::PASIDCTL PASIDCTL;
	typedef cambria_rnr_func0_cfg::PTMECAP PTMECAP;
	typedef cambria_rnr_func0_cfg::PTMCAPREG PTMCAPREG;
	typedef cambria_rnr_func0_cfg::PTMECTL PTMECTL;
	typedef cambria_rnr_func0_cfg::SRIOVECAP SRIOVECAP;
	typedef cambria_rnr_func0_cfg::SRIOVCAP SRIOVCAP;
	typedef cambria_rnr_func0_cfg::SRIOVCTL SRIOVCTL;
	typedef cambria_rnr_func0_cfg::SRIOVSTS SRIOVSTS;
	typedef cambria_rnr_func0_cfg::INITVFSFN0 INITVFSFN0;
	typedef cambria_rnr_func0_cfg::TOTVFSFN0 TOTVFSFN0;
	typedef cambria_rnr_func0_cfg::NUMVFSFN0 NUMVFSFN0;
	typedef cambria_rnr_func0_cfg::SRIOVFDL SRIOVFDL;
	typedef cambria_rnr_func0_cfg::FSTVFOFF FSTVFOFF;
	typedef cambria_rnr_func0_cfg::VFSTRIDE VFSTRIDE;
	typedef cambria_rnr_func0_cfg::VFDID VFDID;
	typedef cambria_rnr_func0_cfg::SUPPFPS SUPPFPS;
	typedef cambria_rnr_func0_cfg::SYSPS SYSPS;
	typedef cambria_rnr_func0_cfg::VFBAR0FN0 VFBAR0FN0;
	typedef cambria_rnr_func0_cfg::VFBAR1FN0 VFBAR1FN0;
	typedef cambria_rnr_func0_cfg::VFBAR2FN0 VFBAR2FN0;
	typedef cambria_rnr_func0_cfg::VFBAR3FN0 VFBAR3FN0;
	typedef cambria_rnr_func0_cfg::VFBAR4FN0 VFBAR4FN0;
	typedef cambria_rnr_func0_cfg::VFBAR5FN0 VFBAR5FN0;
	typedef cambria_rnr_func0_cfg::VFMSA VFMSA;
	typedef cambria_rnr_func0_cfg::DEVSNCAPHDR DEVSNCAPHDR;
	typedef cambria_rnr_func0_cfg::DEVSNLOW DEVSNLOW;
	typedef cambria_rnr_func0_cfg::DEVSNHIGH DEVSNHIGH;
	typedef cambria_rnr_func0_cfg::VSEHDRCAP VSEHDRCAP;
	typedef cambria_rnr_func0_cfg::VSHDR VSHDR;
	typedef cambria_rnr_func0_cfg::PREFETCHCTRL PREFETCHCTRL;
	typedef cambria_rnr_func0_cfg::COREINFO COREINFO;
	typedef cambria_rnr_func0_cfg::IMAGEREV IMAGEREV;
	typedef cambria_rnr_func0_cfg::BUILDREV BUILDREV;
	typedef cambria_rnr_func0_cfg::BOARDINFO BOARDINFO;
	typedef cambria_rnr_func0_cfg::EXTSCRATCH0 EXTSCRATCH0;
	typedef cambria_rnr_func0_cfg::EXTSCRATCH1 EXTSCRATCH1;
	typedef cambria_rnr_func0_cfg::EXTSCRATCH2 EXTSCRATCH2;
	typedef cambria_rnr_func0_cfg::EXTSCRATCH3 EXTSCRATCH3;
	typedef cambria_rnr_func0_cfg::ETRIG ETRIG;
	typedef cambria_rnr_func0_cfg::EXTPSE EXTPSE;
	typedef cambria_rnr_func0_cfg::INTPOLL INTPOLL;
	typedef cambria_rnr_func0_cfg::INTPSE INTPSE;
	typedef cambria_rnr_func0_cfg::UPDREG0 UPDREG0;
	typedef cambria_rnr_func0_cfg::UPDREG1 UPDREG1;
	typedef cambria_rnr_func0_cfg::UPDREG2 UPDREG2;
	typedef cambria_rnr_func0_cfg::UPDREG3 UPDREG3;
	typedef cambria_rnr_func0_cfg::PTMCTRL PTMCTRL;
	typedef cambria_rnr_func0_cfg::PTMSTATUS PTMSTATUS;
	typedef cambria_rnr_func0_cfg::PTMREQCTRL PTMREQCTRL;
	typedef cambria_rnr_func0_cfg::PTMREQCLKCORLSB PTMREQCLKCORLSB;
	typedef cambria_rnr_func0_cfg::PTMTHRESH PTMTHRESH;
	typedef cambria_rnr_func0_cfg::PTMTRIGTM PTMTRIGTM;
	typedef cambria_rnr_func0_cfg::PTMTRIGMSK PTMTRIGMSK;
	typedef cambria_rnr_func0_cfg::PTMCAPTTM PTMCAPTTM;
};
} // namespace cambria_rnr_func0_cfgFmt

#endif // __CAMBRIA_RNR_FUNC0_CFG_REGS_H__
