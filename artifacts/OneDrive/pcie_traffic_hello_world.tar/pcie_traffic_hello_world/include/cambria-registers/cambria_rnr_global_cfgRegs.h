/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2021 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/

/// \details     Contains register definitions for cambria_rnr_global_cfg
/* RegFile Description: The Config and Status Registers for a Cambria Core
Global Control and Status
Cambria Core Memory Mapped Global Register Space */

#ifndef __CAMBRIA_RNR_GLOBAL_CFG_REGS_H__
#define __CAMBRIA_RNR_GLOBAL_CFG_REGS_H__

// #include "registeraccess/MaestroRegisterAccess.h" - STANDALONE
namespace cambria_rnr_global_cfgFmt
{

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0 - PCIe Clock[br]
1 - Core Clock Pin */
		uint32_t CCSS : 1;
		uint32_t RESV1 : 1;
		uint32_t LAIOE : 1;
		uint32_t RESV3 : 1;
		/* IO Spaces Requested:[br]
00 - All 4 IO Spaces[br]
01 - Target 0 & 1 IO Spaces[br]
10 - Target 0 IO Space[br]
11 - No IO Space */
		uint32_t NUMIO : 2;
		uint32_t RESV6 : 1;
		uint32_t RESV7 : 1;
		/* PLRM resetable registers will NOT be reset on LINK RESET. */
		uint32_t LRM : 1;
		/* The link width selected must be equal or less than the Connector width selector irrespective of lane
injection bit state. This information is used for lane reversal.[br]ENCODING	LINK WIDTH[br]
000	x1[br]
1xx	x2[br]
001	x4[br]
010	x8[br]
011	x16 */
		uint32_t LWS : 3;
		/*  The link width selected must be equal or less than the Connector width selector irrespective of lane
injection bit state. This information is used for lane reversal.[br]ENCODING	CONNECTOR WIDTH[br]
000	x1[br]
1xx	x2[br]
001	x4[br]
010	x8[br]
011	x16 */
		uint32_t CWS : 3;
		uint32_t RESV15 : 2;
		/* Used to speed up simulation by adjusting the timer granualrity. */
		uint32_t SIMTIMEDLY : 1;
		uint32_t RESV18 : 6;
		uint32_t DPS : 8;
	};
} FORMAT_0;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0: Global EV Buffer Mode for master and slave requests. Full 8k space[br]
1: Split EV Buffer Mode. Lower 4KB is used for slave requests [lb]writes and read cpl data[rb] and upper 4KB is used for
master requests [lb]reads and write data[rb][br]
EV_BUFFER_MODE|SLAVE_REQUESTS|MASTER_REQUESTS|COMMENTS[br]
0|ADDR[lb]12:2[rb]|ADDR[lb]12:2[rb]|Global 8KB buffer for both slave and master requests.[br]
1|ADDR[lb]12[rb] forced to 0 and ADDR[lb]11:2[rb]|ADDR[lb]12[rb] forced to 1 and ADDR[lb]11:2[rb]|Lower 4KB for slave
requests [lb]Targets[rb][br]
Upper 4KB for master requests[br]
Note this split mode does not apply when accessing this space through Remap1 */
		uint32_t EVBM : 1;
		uint32_t RESV1 : 4;
		/* OPEN: How to use this if no indication from controller?[br]0: Beacon/Wake deassertion in based on wake delay
counter[br]
1: Beacon/Wake is deasserted on detecting exit from EIDLE overriding the wake counter settings. */
		uint32_t DWAKED : 1;
		uint32_t FF : 1;
		uint32_t RESV7 : 3;
		/* 0: The Global Seed Registers are used for all VMs, Targets, and Multicast Groups.[br]
1: Each individual VM, individual Target, and all the Multicast Groups have there own unique seed registers. */
		uint32_t ROLROIS : 1;
		uint32_t RESV11 : 1;
		/*  The TRIGTCLATERRB and TRIGTCLATMAXB signals will be used to select between Traffic Class (TC) Errors or
Timestamp (TS) errors.[br]0: TC Latency Error[br]
1: Time Stamp Latency Error */
		uint32_t LETM : 1;
		uint32_t RESV13 : 3;
		/*  Associated inactive byte enable data is compared to its compliment during the verify phase to validate
		 * inactive bytes were not written during the execute phase. */
		uint32_t CIBE : 1;
		/* 0: Incrementing Tag field value will be used[br]
1: The Posted Tag field of the Upper Address Vector or Posted Tag for Generated Messages field is used */
		uint32_t TCP : 1;
		uint32_t RESV18 : 6;
		/* 0: PE_RESETB from the PCI-EXPRESS connector will reset the device.[br]
1: PE_RESETB signal from the PCI-EXPRESS connector will be masked. It will NOT reset the device. This will also mask Hot
Reset to the Core unless Hot Reset Mask Core field is clear. */
		uint32_t PERESETBMC : 1;
		uint32_t RESV25 : 7;
	};
} FORMAT_1;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0 - 1 NP Request[br]
...[br]
1Fh: 32 NP Requests[br]
[br]
7F: 128 NP Requests[br]
The Extended Tag must be enabled if more than 32 non posted requests are to be used. */
		uint32_t MNO : 7;
		uint32_t RESV7 : 3;
		uint32_t EDPS : 2;
		uint32_t RESV12 : 1;
		/*  Allows non-vector based MSI and PCI-style interrupts to transmit even when BME is clear. */
		uint32_t BMEO : 1;
		uint32_t RESV14 : 2;
		uint32_t RESV16 : 16;
	};
} FORMAT_2;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Data in VM's global sticky register */
		uint32_t GSRD : 32;
	};
} FORMAT_3;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SS : 32;
	};
} FORMAT_4;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t BSSR : 32;
	};
} FORMAT_8;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 16;
		uint32_t RESV16 : 8;
		/*  This is the TLP Tag field value used with generated error or interrupt messages when the User Specified
		 * Posted Tag Field feature is enabled. */
		uint32_t PTG : 5;
		uint32_t RESV29 : 3;
	};
} FORMAT_9;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0: Hot Reset to the Core will not be masked if PE_RESETB Mask Core is set.[br]
1: Hot Reset to the Core will also be masked if PE_RESETB Mask Core is set. */
		uint32_t HRMC : 1;
		uint32_t RESV1 : 22;
		/* STRAP_REMAP1_PREF[br]Sets prefetch value for used in FN0BAR0 & VFBAR4FN0 */
		uint32_t BAR0PREFETCH : 1;
		/* STRAP_LEGACY_ENDPT[br]When configured as an Endpoint, sets Device/Port Type to Legacy */
		uint32_t LEGACYENDPT : 1;
		uint32_t RESV25 : 7;
	};
} FORMAT_10;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* The SAI Value that is inserted into the TLP Prefix in TBF mode or sent along with packet in RNR mode */
		uint32_t SAIVAL : 8;
		uint32_t RS : 4;
		uint32_t RESV12 : 12;
		/* Include programmed SAI Value with completions. Intended for CXL mode */
		uint32_t SAICMPL : 1;
		uint32_t RESV25 : 7;
	};
} FORMAT_11;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0 - Sends one Deassert_INTA TLP[br]
...[br]
3 - Sends four Deassert_INTA TLP */
		uint32_t PCISINTADA12 : 2;
		/* 0 - Sends one Deassert_INTA TLP[br]
...[br]
3 - Sends four Deassert_INTA TLP */
		uint32_t PCISINTADA11 : 2;
		/* 0 - Sends one Deassert_INTA TLP[br]
...[br]
3 - Sends four Deassert_INTA TLP */
		uint32_t PCISINTADA1 : 2;
		/* 0 - Sends one Deassert_INTA TLP[br]
...[br]
3 - Sends four Deassert_INTA TLP */
		uint32_t PCISINTADA : 2;
		/* 0 - Sends one Deassert_INTB TLP[br]
...[br]
3 - Sends four Deassert_INTB TLP */
		uint32_t PCISINTBDA10 : 2;
		/* 0 - Sends one Deassert_INTB TLP[br]
...[br]
3 - Sends four Deassert_INTB TLP */
		uint32_t PCISINTBDA9 : 2;
		/* 0 - Sends one Deassert_INTB TLP[br]
...[br]
3 - Sends four Deassert_INTB TLP */
		uint32_t PCISINTBDA1 : 2;
		/* 0 - Sends one Deassert_INTB TLP[br]
...[br]
3 - Sends four Deassert_INTB TLP */
		uint32_t PCISINTBDA : 2;
		/* 0 - Sends one Deassert_INTC TLP[br]
...[br]
3 - Sends four Deassert_INTC TLP */
		uint32_t PCISINTCDA8 : 2;
		/* 0 - Sends one Deassert_INTC TLP[br]
...[br]
3 - Sends four Deassert_INTC TLP */
		uint32_t PCISINTCDA7 : 2;
		/* 0 - Sends one Deassert_INTC TLP[br]
...[br]
3 - Sends four Deassert_INTC TLP */
		uint32_t PCISINTCDA1 : 2;
		/* 0 - Sends one Deassert_INTC TLP[br]
...[br]
3 - Sends four Deassert_INTC TLP */
		uint32_t PCISINTCDA : 2;
		/* 0 - Sends one Deassert_INTD TLP[br]
...[br]
3 - Sends four Deassert_INTD TLP */
		uint32_t PCISINTDDA6 : 2;
		/* 0 - Sends one Deassert_INTD TLP[br]
...[br]
3 - Sends four Deassert_INTD TLP */
		uint32_t PCISINTDDA5 : 2;
		/* 0 - Sends one Deassert_INTD TLP[br]
...[br]
3 - Sends four Deassert_INTD TLP */
		uint32_t PCISINTDDA1 : 2;
		/* 0 - Sends one Deassert_INTD TLP[br]
...[br]
3 - Sends four Deassert_INTD TLP */
		uint32_t PCISINTDDA : 2;
	};
} FORMAT_12;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCR0 : 4;
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCR1 : 4;
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCR2 : 4;
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCR3 : 4;
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCW0 : 4;
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCW1 : 4;
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCW2 : 4;
		/* 1xxx: Drop Completion[br]
0yyy: Completion Status value yyy sent in packet */
		uint32_t CSCW3 : 4;
	};
} FORMAT_13;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M0TLPM : 8;
		uint32_t M0SID : 2;
		uint32_t M0VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M0E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM0V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM0TLP : 1;
		uint32_t M1TLPM : 8;
		uint32_t M1SID : 2;
		uint32_t M1VM : 3;
		/* 0 - Generates an event trigger
1 - Generates a pause release event only */
		uint32_t M1E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM1V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM1TLP : 1;
	};
} FORMAT_14;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M2TLPM : 8;
		uint32_t M2SID : 2;
		uint32_t M2VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M2E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM2V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM2TLP : 1;
		uint32_t M3TLPM : 8;
		uint32_t M3SID : 2;
		uint32_t M3VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M3E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM3V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM3TLP : 1;
	};
} FORMAT_15;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M4TLPM : 8;
		uint32_t M4SID : 2;
		uint32_t M4VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M4E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM4V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM4TLP : 1;
		uint32_t M5TLPM : 8;
		uint32_t M5SID : 2;
		uint32_t M5VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M5E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM5V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM5TLP : 1;
	};
} FORMAT_16;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M6TLPM : 8;
		uint32_t M6SID : 2;
		uint32_t M6VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M6E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM6V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM6TLP : 1;
		uint32_t M7TLPM : 8;
		uint32_t M7SID : 2;
		uint32_t M7VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M7E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM7V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM7TLP : 1;
	};
} FORMAT_17;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M8TLPM : 8;
		uint32_t M8SID : 2;
		uint32_t M8VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M8E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM8V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM8TLP : 1;
		uint32_t M9TLPM : 8;
		uint32_t M9SID : 2;
		uint32_t M9VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M9E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM9V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM9TLP : 1;
	};
} FORMAT_18;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M10TLPM : 8;
		uint32_t M10SID : 2;
		uint32_t M10VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M10E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM10V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM10TLP : 1;
		uint32_t M11TLPM : 8;
		uint32_t M11SID : 2;
		uint32_t M11VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M11E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM11V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM11TLP : 1;
	};
} FORMAT_19;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M12TLPM : 8;
		uint32_t M12SID : 2;
		uint32_t M12VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M12E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM12V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM12TLP : 1;
		uint32_t M13TLPM : 8;
		uint32_t M13SID : 2;
		uint32_t M13VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M13E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM13V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM13TLP : 1;
	};
} FORMAT_20;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M14TLPM : 8;
		uint32_t M14SID : 2;
		uint32_t M14VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M14E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM14V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM14TLP : 1;
		uint32_t M15TLPM : 8;
		uint32_t M15SID : 2;
		uint32_t M15VM : 3;
		/* 0 - Generates an event trigger[br]1 - Generates a pause release event only */
		uint32_t M15E : 1;
		/*  Compare Byte 15 of the TLP */
		uint32_t EM15V : 1;
		/*  Compare Byte 7 of the TLP */
		uint32_t EM15TLP : 1;
	};
} FORMAT_21;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 8;
		/*   Register based interrupts are interrupts caused by:[br]End Status bit(s) gets set and interrupt on end is
enabled - Master Mode Register 0[br]
Master SV errors reported in the VMx Error Control Register[br]
Target SV errors reported in the Target X Error Control Register[br]
All those register bits must be cleared prior to clearing this bit. When this bit is set,  no new register based
interrupts are issued until this bit is clear. If this bit is clear and if any error valid bits/end status bits are set,
another interrupt is issued so that no interrupts are lost. */
		uint32_t ESVE : 1;
		/* This is used only when message merging is enabled in Master Control Register[br]
This bit is set when any correctable error bit is set in PCI-Express Uncorrectable Error Status register.[br]
The correctable error is reported when this bit gets set[br]
If this bit is already set when the correctable error is detected, the error is not reported.[br]
User must clear all Correctable Errors bits before clearing this bit to re-enable reporting of Correctable errors.[br]
If this bit is cleared prior to clearing the correctable errors, then another ERR_COR Msg TLP is sent. */
		uint32_t GMS4 : 1;
		/* This is used only when message merging is enabled in Master Control Register[br]
This bit is set when any NON-FATAL error bit is set in PCI-Express Uncorrectable Error Status register [br]
Non-fatal error is reported when this bit gets set.[br]
If this bit is already set when the non-fatal error is detected, fatal error is not reported.[br]
User must clear all Non-Fatal Error bits before clearing this bit to re-enable reporting of Non-Fatal errors.[br]
If this bit is cleared prior to clearing the correctable errors, then another ERR_NONFATAL Msg TLP is sent. */
		uint32_t GMS1 : 1;
		/* This is used only when message merging is enabled in bit[15] of Master Control Register[br]
This bit is set when any FATAL error bit is 1 in PCI-Express Uncorrectable Error Status register[br]
Fatal error is reported when this bit gets set.[br]
If this bit is already set when the fatal error is detected, the fatal error is not reported.[br]
User must clear all  Fatal Error bits before clearing this bit to re-enable reporting of Fatal errors.[br]
If this bit is cleared prior to clearing the correctable errors, then another ERR_FATAL Msg TLP is sent. */
		uint32_t GMS : 1;
		uint32_t RESV12 : 12;
		uint32_t MSID10R3 : 2;
		uint32_t MSID10R12 : 2;
		uint32_t MSID10R1 : 2;
		uint32_t MSID10R : 2;
	};
} FORMAT_22;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Bit 30 - ID 30 needs servicing[br]
...[br]
Bit 0 - ID 0  needs servicing */
		uint32_t INTIDIO : 31;
		/* Set when there is at least one INTA ID 31 outstanding. */
		uint32_t INTID31 : 1;
	};
} FORMAT_23;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTA INT-ID interrupt
		 * request is scheduled, except INT-ID31, and is decremented when the any INTA INT-ID interrupt is cleared.
		 * Register based interrupts do not increment the counter */
		uint16_t GIAC : 16;
	};
} FORMAT_27;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTB INT-ID interrupt
		 * request is scheduled, except INT-ID31, and is decremented when the any INTB INT-ID interrupt is cleared.
		 * Register based interrupts do not increment the counter */
		uint16_t GIBC : 16;
	};
} FORMAT_28;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTC INT-ID interrupt
		 * request is scheduled, except INT-ID31, and is decremented when the any INTC INT-ID interrupt is cleared.
		 * Register based interrupts do not increment the counter */
		uint16_t GICC : 16;
	};
} FORMAT_29;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTD INT-ID interrupt
		 * request is scheduled, except INT-ID31, and is decremented when the any INTD INT-ID interrupt is cleared.
		 * Register based interrupts do not increment the counter */
		uint16_t GIDC : 16;
	};
} FORMAT_30;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTA INT-ID31 interrupt
		 * request is scheduled and is decremented when the any INTA INT-ID31 interrupt is cleared. Register based
		 * interrupts do not increment the counter */
		uint32_t INTID31INTAC : 8;
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTB INT-ID31 interrupt
		 * request is scheduled and is decremented when the any INTB INT-ID31 interrupt is cleared. Register based
		 * interrupts do not increment the counter */
		uint32_t INTID31INTBC : 8;
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTC INT-ID31 interrupt
		 * request is scheduled and is decremented when the any INTC INT-ID31 interrupt is cleared. Register based
		 * interrupts do not increment the counter */
		uint32_t INTID31INTCC : 8;
		/*  Indicates the number of outstanding interrupts. This counter is incremented when any INTD INT-ID31 interrupt
		 * request is scheduled and is decremented when the any INTD INT-ID31 interrupt is cleared. Register based
		 * interrupts do not increment the counter */
		uint32_t INTID31INTDC : 8;
	};
} FORMAT_31;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When Clear INT-ID for INTA Valid field is set, this encoded field indicates which INT-ID value is cleared[br]
0 - Clears bit 0 of the associated Acknowledge Register[br]
...[br]
1E - Clears bit 30 of the associated Acknowledge Register[br]
1F - Decrements the INTA INT-ID 31 Counter */
		uint32_t CINTIDINTA14 : 5;
		/* When set, clearing any of the status bits 0-31 causes all the status bits 0-31 to clear.  */
		uint32_t EWCA13 : 1;
		/* When set, reading the INT-ID Acknowledge Register will cause the associated status bits to clear. */
		uint32_t ESR12 : 1;
		uint32_t CINTIDINTA : 1;
		/* When Clear INT-ID for INTB Valid field is set, this encoded field indicates which INT-ID value is cleared[br]
0 - Clears bit 0 of the associated Acknowledge Register[br]
...[br]
1E - Clears bit 30 of the associated Acknowledge Register[br]
1F - Decrements the INTB INT-ID 31 Counter */
		uint32_t CINTIDINTB11 : 5;
		/* When set, clearing any of the status bits 0-31 causes all the status bits 0-31 to clear. */
		uint32_t EWCA10 : 1;
		/* When set, reading the INT-ID Acknowledge Register will cause the associated status bits to clear. */
		uint32_t ESR9 : 1;
		uint32_t CINTIDINTB : 1;
		/* When Clear INT-ID for INTC Valid field is set, this encoded field indicates which INT-ID value is cleared[br]
0 - Clears bit 0 of the associated Acknowledge Register[br]
...[br]
1E - Clears bit 30 of the associated Acknowledge Register[br]
1F - Decrements the INTC INT-ID 31 Counter */
		uint32_t CINTIDINTC8 : 5;
		/* When set, clearing any of the status bits 0-31 causes all the status bits 0-31 to clear. */
		uint32_t EWCA7 : 1;
		/* When set, reading the INT-ID Acknowledge Register will cause the associated status bits to clear. */
		uint32_t ESR6 : 1;
		uint32_t CINTIDINTC : 1;
		/* When Clear INT-ID for INTD Valid field is set, this encoded field indicates which INT-ID value is cleared[br]
0 - Clears bit 0 of the associated Acknowledge Register[br]
...[br]
1E - Clears bit 30 of the associated Acknowledge Register[br]
1F - Decrements the INTD INT-ID 31 Counter */
		uint32_t CINTIDINTD5 : 5;
		/* When set, clearing any of the INT-ID bits 0-31 causes all the INT-ID bits 0-31 to clear. */
		uint32_t EWCA : 1;
		/* When set, reading the INT-ID Acknowledge Register will cause the associated status bits to clear. */
		uint32_t ESR : 1;
		uint32_t CINTIDINTD : 1;
	};
} FORMAT_32;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TLPMCSP0 : 8;
		uint32_t TLPMCSP1 : 8;
		uint32_t TLPMCSP2 : 8;
		uint32_t TLPMCSP3 : 8;
	};
} FORMAT_33;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Message Code is in byte 15 of header */
		uint32_t TLPVSMSP0 : 8;
		/* Message Code is in byte 15 of header */
		uint32_t TLPVSMSP1 : 8;
		/* Message Code is in byte 15 of header */
		uint32_t TLPVSMSP2 : 8;
		/* Message Code is in byte 15 of header */
		uint32_t TLPVSMSP3 : 8;
	};
} FORMAT_34;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TLPVSM0 : 8;
		uint32_t TLPVSM1 : 8;
		uint32_t TLPVSM2 : 8;
		uint32_t TLPVSM3 : 8;
	};
} FORMAT_35;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TLPVSM4 : 8;
		uint32_t TLPVSM5 : 8;
		uint32_t TLPVSM6 : 8;
		uint32_t TLPVSM7 : 8;
	};
} FORMAT_36;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TLPVSM8 : 8;
		uint32_t TLPVSM9 : 8;
		uint32_t TLPVSM10 : 8;
		uint32_t TLPVSM11 : 8;
	};
} FORMAT_37;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TLPVSM12 : 8;
		uint32_t TLPVSM13 : 8;
		uint32_t TLPVSM14 : 8;
		uint32_t TLPVSM15 : 8;
	};
} FORMAT_38;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 1 tick is 8ns */
		uint32_t RDV1 : 16;
		/* 1 tick is 8ns */
		uint32_t RDV : 16;
	};
} FORMAT_39;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 12;
		/*   See Transaction Layer Error Injection section for completion encodings */
		uint32_t CTLPET : 4;
		/*  See Transaction Layer Error Injection section for completion encodings */
		uint32_t CTLPES : 16;
	};
} FORMAT_41;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t GCCSP0 : 1;
		uint32_t GCCSP1 : 1;
		uint32_t GCCSP2 : 1;
		uint32_t GCCSP3 : 1;
		uint32_t GCCCSP0 : 1;
		uint32_t GCCCSP1 : 1;
		uint32_t GCCCSP2 : 1;
		uint32_t GCCCSP3 : 1;
		uint32_t RESV8 : 8;
		uint32_t EVSMSP0 : 1;
		uint32_t EMDSP0 : 1;
		uint32_t EVSMSP1 : 1;
		uint32_t EMDSP1 : 1;
		uint32_t EVSMSP2 : 1;
		uint32_t EMDSP2 : 1;
		uint32_t EVSMSP3 : 1;
		uint32_t EMDSP3 : 1;
		/* 0 - Selects Command A[br]1 - Selects Command B */
		uint32_t SPMC0 : 1;
		/* 0 - Selects Command A[br]1 - Selects Command B */
		uint32_t SPMC1 : 1;
		/* 0 - Selects Command A[br]1 - Selects Command B */
		uint32_t SPMC2 : 1;
		/* 0 - Selects Command A[br]1 - Selects Command B */
		uint32_t SPMC3 : 1;
		uint32_t RESV28 : 4;
	};
} FORMAT_42;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t CCEXTINPUT0L : 1;
		uint32_t CCEXTINPUT0H : 1;
		uint32_t CCEXTINPUT1L : 1;
		uint32_t CCEXTINPUT1H : 1;
		uint32_t CCEXTINPUT2L : 1;
		uint32_t CCEXTINPUT2H : 1;
		uint32_t CCEXTINPUT3L : 1;
		uint32_t CCEXTINPUT3H : 1;
		uint32_t CCEXTINPUT4L : 1;
		uint32_t CCEXTINPUT4H : 1;
		uint32_t CCEXTINPUT5L : 1;
		uint32_t CCEXTINPUT5H : 1;
		uint32_t CCEXTINPUT6L : 1;
		uint32_t CCEXTINPUT6H : 1;
		uint32_t CCEXTINPUT7L : 1;
		uint32_t CCEXTINPUT7H : 1;
		uint32_t VP0L : 1;
		uint32_t VP0H : 1;
		uint32_t VP1L : 1;
		uint32_t VP1H : 1;
		uint32_t VP2L : 1;
		uint32_t VP2H : 1;
		uint32_t VP3L : 1;
		uint32_t VP3H : 1;
		uint32_t VP4L : 1;
		uint32_t VP4H : 1;
		uint32_t VP5L : 1;
		uint32_t VP5H : 1;
		uint32_t VP6L : 1;
		uint32_t VP6H : 1;
		uint32_t VP7L : 1;
		uint32_t VP7H : 1;
	};
} FORMAT_43;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MSIDCET0 : 16;
		uint32_t MSIDCET1 : 16;
	};
} FORMAT_44;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MSIDCET2 : 16;
		uint32_t MSIDCET3 : 16;
	};
} FORMAT_45;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SID0 : 2;
		/* 00 - VM0[br]
01 - VM1[br]
10 - VM2[br]
11 - VM3 */
		uint32_t VMID0 : 2;
		uint32_t RESV4 : 1;
		uint32_t RESV5 : 2;
		/*  Generates an event trigger if it is a 'HIT' to the MSI Event Trigger Low Address Register 0, MSI Event
		 * Trigger High Address Register 0, and MSI Data Corresponding to MSI Event Trigger Address Register 0 and the
		 * target VM must be in EVENT MODE */
		uint32_t EMSIWC0 : 1;
		uint32_t SID1 : 2;
		/* 00 - VM0[br]
01 - VM1[br]
10 - VM2[br]
11 - VM3 */
		uint32_t VMID1 : 2;
		uint32_t RESV12 : 1;
		uint32_t RESV13 : 2;
		/*  Generates an event trigger if it is a 'HIT' to the MSI Event Trigger Low Address Register 1, MSI Event
		 * Trigger High Address Register 1, and MSI Data Corresponding to MSI Event Trigger Address Register 1 and the
		 * target VM must be in EVENT MODE */
		uint32_t EMSIWC1 : 1;
		uint32_t SID2 : 2;
		/* 00 - VM0[br]
01 - VM1[br]
10 - VM2[br]
11 - VM3 */
		uint32_t VMID2 : 2;
		uint32_t RESV20 : 1;
		uint32_t RESV21 : 2;
		/*  Generates an event trigger if it is a 'HIT' to the MSI Event Trigger Low Address Register 2, MSI Event
		 * Trigger High Address Register 2, and MSI Data Corresponding to MSI Event Trigger Address Register 2 and the
		 * target VM must be in EVENT MODE */
		uint32_t EMSIWC2 : 1;
		uint32_t SID3 : 2;
		/* 00 - VM0[br]
01 - VM1[br]
10 - VM2[br]
11 - VM3 */
		uint32_t VMID3 : 2;
		uint32_t RESV28 : 1;
		uint32_t RESV29 : 2;
		/*  Generates an event trigger if it is a 'HIT' to the MSI Event Trigger Low Address Register 3, MSI Event
		 * Trigger High Address Register 3, and MSI Data Corresponding to MSI Event Trigger Address Register 3 and the
		 * target VM must be in EVENT MODE */
		uint32_t EMSIWC3 : 1;
	};
} FORMAT_46;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0: Enables compare of the 32 bit DWORD address for 32b memory write TLP only.[br]
1: Enables compare of  the lower 32 bit DWORD address of a 64b memory write TLP only. */
		uint32_t E64CD : 1;
		uint32_t EF64A : 1;
		/*  This will be compared to the following TLP bytes:[br]3DW header: TLP bytes 8,9,10,11 with the corresponding
address bits.[br]
4DW header: TLP bytes 12,13,14,15 with the corresponding address bits. */
		uint32_t TLPA : 30;
	};
} FORMAT_47;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This will be compared to the following TLP bytes:4DW header: TLP bytes 8,9,10,11 with the corresponding
		 * address bits. */
		uint32_t TLPA : 32;
	};
} FORMAT_48;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This will be compared to the following TLP bytes:4DW header: TLP bytes 8,9,10,11 with the corresponding
		 * address bits. */
		uint32_t TLPA1 : 32;
	};
} FORMAT_50;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 8;
		/* 0: Mode 0 - Continue servicing selected VM/Target for quota number of packets as along as they are pending
even if packet credits are not available.[br]
1: Mode 1 - If packet credits are not available for the currently choosen VM, it will be skipped to service other
pending VMs provided the skip count limit has not been reached. Targets do not perform skip tracking. */
		uint32_t AM : 1;
		/*  Resets Live Timer Register */
		uint32_t LTRC : 1;
		/*  0 - Register Write Mode[br]
1 - TRIGINB Mode (Falling edge) */
		uint32_t SM : 1;
		uint32_t RESV11 : 1;
		/*  Writing to this bit will reset the master arbiter to VM0 and the target arbiter to TGP queue. */
		uint32_t AR : 1;
		/*  Strong order means the completions are sent in the same order as the received non-posted requests */
		uint32_t GSO : 1;
		/*  Completion status is generated based on target range characteristics. An internal counter is incremented
each time an UR completion status is sent. RESERVED ENCODINGS must be treated as UR by the receiver.[br]0: UR Status
encoding is '001'b[br]
1: Generate 'Reserved Encoding' Instead of '001b' as shown below[br]
When the completion status is UR AND this bit is '1', the completion status is modified as follows -[br]
'UR' COUNT	CPL STATUS [lb]RESERVED ENCODINGS[rb]
1	111b[br]
2	110b[br]
3	101b[br]
4	011b[br]
5	001b[br]
6	111b ** Pattern repeats...[br]
7	110b */
		uint32_t UNSUPSTS : 1;
		/* Merging of error message means sending a msg only if there are no outstanding msgs [ outstanding msg implies
		 * msg already sent  and error status register bit is '1' - not yet acknowledged ].  Specific error types
		 * [individual bits in the Uncorrectable or Correctable Error Status registers] are always merged. i.e. An
		 * ERR_FATAL message will only be sent the first time a malfomed error is detected. However if now a Receiver
		 * Overflow is detected, the setting of this bit determines if another ERR_FATAL will be sent or not. */
		uint32_t MEM : 1;
		uint32_t RESV16 : 13;
		/* 0: Invert lower nibble of the data for invalid byte enable[br]
1: Normal operation. Does NOT invert lower nibble of the data for invalid byte enable[br]
This applies to data returned on slave memory reads only. The lower nibble of the data byte whose byte enable is invalid
will be inverted when this bit is 0. */
		uint32_t IDLN : 1;
		/* 0: Change device's Requester ID as soon as a configuration write is accepted in the core.[br]
1: Change device's Requester ID for all requests sent after the completion for the configuration write. */
		uint32_t RID : 1;
		/* 0: Change device's Completer ID for all completions sent after the completion for the configuration
write.[br]
1: Change the device's Completer ID as soon as a configuration write is accepted in the core. */
		uint32_t CID : 1;
	};
} FORMAT_55;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0 - 1 TLP per arbiter slot[br]
[br]
Fh - 16 TLPs per arbiter slot */
		uint32_t RQ : 4;
		uint32_t RESV4 : 4;
		/* 0 - 1 TLP per arbiter slot[br]
[br]
Fh - 16 TLPs per arbiter slot */
		uint32_t CQ : 4;
		uint32_t RESV12 : 4;
		uint32_t RESV16 : 8;
		uint32_t TLES : 1;
		/*  Non locked non posted VC0 request is completed after target locked is already established. */
		uint32_t LPES : 1;
		uint32_t SUMTLP : 1;
		uint32_t RESV27 : 1;
		uint32_t RESV28 : 1;
		uint32_t RESV29 : 1;
		/*  Flushes all completions ahead of the completion for the MRdLk request. */
		uint32_t FSO : 1;
		uint32_t RESV31 : 1;
	};
} FORMAT_56;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Bit 0  >> Physical Lane 0[br]
...[br]
Bit 15 >> Physical Lane 15[br] */
		uint32_t LTI : 16;
		/* See LTSSM State Encodings table */
		uint32_t CLS : 8;
		/* Counter is incremented when a replay timeout occurs. It does not roll over. */
		uint32_t RTTC : 8;
	};
} FORMAT_57;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Either this bit or the bit in Device Control 2 Register can disable the timeout. */
		uint32_t CTD : 1;
		/* 000 - 64ns/tick[br]
001 - 128ns/tick[br]
010 - 256ns/tick[br]
011 - Not Supported[br]
1xx - Not Supported */
		uint32_t CTTG : 3;
		/* Determines how long the Transaction Layer will wait for completion before retiring the outstanding non-posted
request.[br]
Default value is equal to 10 ms */
		uint32_t CTT : 20;
		uint32_t RESV24 : 8;
	};
} FORMAT_58;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TF : 10;
		uint32_t FN : 3;
		uint32_t RESV13 : 3;
		/* Indicates the timeout information logged is valid. Once this bit is set, further updates to these error
		 * registers are blocked until this is explicitly cleared by the user. User should write a -1- to re-enable the
		 * error logging and it will also clear those bits in the Side Queue register that were set due to completion
		 * timeout. */
		uint32_t EV : 1;
		uint32_t CNCT : 1;
		/*  Chooses Tag range to display.[br]00 - Entries [lb]31:0[rb][br]
01 - Entries [lb]64:32[rb][br]
10 - Entries [lb]95:64[rb][br]
11 - Entries [lb]127:96[rb] */
		uint32_t SQES : 2;
		uint32_t RESV20 : 4;
		uint32_t NCT : 8;
	};
} FORMAT_59;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TLPTI : 1;
		uint32_t RESV1 : 1;
		/*  Stored address of the first timeout. */
		uint32_t FTA312 : 30;
	};
} FORMAT_60;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Stored address of the first timeout. */
		uint32_t FTA6332 : 32;
	};
} FORMAT_61;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Displays which entries are currently outstanding or have retired due to timeout.There are 128 entries in the
side Q. The tag range displayed is selected with bits 19:18 of Completion Timeout Info Register
If any of these entries are retired due to completion timeout, the completion error register will hold the data of the
first completion error.  */
		uint32_t SQES : 32;
	};
} FORMAT_62;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* TBD can we even track this? Counter does not rollover. */
		uint32_t REC : 16;
		/* Increments whenever: MEM/IO cycle is received and the IO/MEM space is disabled OR[br]
the received transaction is out of address range OR received Message is unsupported.[br]
Counter does not rollover. */
		uint32_t NTLPR : 8;
		/* Does not include decode miss. Counter does not rollover. */
		uint32_t NUR : 8;
	};
} FORMAT_63;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 8;
		/* Counter does not rollover. */
		uint32_t NCE : 8;
		/* Counter does not rollover. */
		uint32_t NNFE : 4;
		/* Counter does not rollover. */
		uint32_t NFE : 4;
		/* Counter does not rollover. */
		uint32_t MCWC : 4;
		/* Counter does not rollover. */
		uint32_t MCRC : 4;
	};
} FORMAT_64;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Counter does not rollover. */
		uint32_t NMP : 8;
		/* Counts the number of successful link retrain [lb]L0 to Recovery and back to L0[rb] since the link reset
		 * including any transitions for a link speed change.Counter does not rollover. */
		uint32_t LRC : 8;
		uint32_t RESV16 : 1;
		uint32_t RESV17 : 3;
		uint32_t RESV20 : 1;
		uint32_t RESV21 : 1;
		uint32_t RESV22 : 2;
		uint32_t RESV24 : 8;
	};
} FORMAT_65;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Counter does not rollover. */
		uint32_t NL0 : 8;
		/*  Counts the number of successful link retrain [lb]L0 to Recovery and back to L0[rb] since the link reset
		 * excluding any transitions for a link speed change. Counter does not rollover. */
		uint32_t LRC2 : 8;
		uint32_t RESV16 : 16;
	};
} FORMAT_66;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  TLP receive queue overflowed and packets were lost. */
		uint32_t RQPO : 1;
		uint32_t RESV1 : 5;
		/* Received lock completion type when not expected. */
		uint32_t RCT : 1;
		/* The completion received has larger length or contains data that is was unexpected. */
		uint32_t RCLM : 1;
		/* The request matching this completion has different ReqID than received. */
		uint32_t RCRID : 1;
		/* The request matching this completion has different Attr fields than received. */
		uint32_t RCAM : 1;
		/* The request matching this completion has different TC than received. */
		uint32_t RCTCM : 1;
		/* Cannot find a pending request for the received completion with the upper 5-bits of the tag field that
		 * matches. */
		uint32_t IU3 : 1;
		/* Cannot find a pending request for the received completion. */
		uint32_t TDNM : 1;
		/* Received packet does not map to any enabled VC. */
		uint32_t RTLPTCVCE : 1;
		/* Received non-Vendor Defined Message packet with non-zero attributes. */
		uint32_t MRHNZ : 1;
		/* Excludes Vendor Defined that can be on any TC. */
		uint32_t MTLPTC0 : 1;
		uint32_t MRLRTC0 : 1;
		/* Received packet is not the length expected. */
		uint32_t LNE : 1;
		/* Received Packet that is longer than allowed or MCTP Length rules violation.  */
		uint32_t DGTMP : 1;
		/* Improper AT Field usage for the packet received. */
		uint32_t ATFUE : 1;
		/* Received packet with address alignment problem. */
		uint32_t MRRS : 1;
		/* Received a Type 1 Config cycle. */
		uint32_t T1CC : 1;
		/* Received an ilegal upstream Config cycle. */
		uint32_t SRCC : 1;
		/* Received a Lock request for a non-legacy endpoint. */
		uint32_t PCIELE : 1;
		/* Received a non-successful completion with data. */
		uint32_t CSE : 1;
		/* Received a reserved completion status. */
		uint32_t RESV25 : 1;
		/* Received an illegal CRS response for a non-Config cycle. */
		uint32_t RCS : 1;
		/* Endpoint received an Interrupt Message. */
		uint32_t ERIM : 1;
		/* Endpoint received a message routed for a root. */
		uint32_t MRIDI : 1;
		/* Packet has a Message Code not in the spec. */
		uint32_t UMTLPE : 1;
		/* Packet has a valid Message Code but has illegal Route ID. */
		uint32_t IMTLPF : 1;
		/* Length is not a legal defined value. */
		uint32_t IOCAR : 1;
	};
} FORMAT_67;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t NZATC : 1;
		uint32_t FBEI : 1;
		/* Mulitple DW packet violated this rule. */
		uint32_t LBEI : 1;
		/* Single DW packet violated this rule. */
		uint32_t LBEA : 1;
		uint32_t RESV4 : 3;
		/* While lock is established, the following rules are checked:[br]As stub: Any VC0 request that is not a
completion.[br]
As legacy end point: Any VC0 request that is not a MRdLk, MWr, Msg, MsgD, or does not have the same ReqID as the cycle
that initiated the Lock. */
		uint32_t LSE : 1;
		/* Received request does not conform to the contiguous Byte Enable rule. */
		uint32_t CBEE : 1;
		/* Received completion does not have the expected value. */
		uint32_t CBCE : 1;
		/* Received completion does not have the expected value. */
		uint32_t CLAE : 1;
		uint32_t BCMUE : 1;
		/* Detected a completion with illegal legnth based on RCB rules.Note: As an endpoint, the RCB value in the Link
		 * Control register is used as a hint as to the other link agents value which is being validated and must be
		 * programmed properly. */
		uint32_t CRCBLE : 1;
		/* Received a TLP that is not defined in the spec. */
		uint32_t UTLPFTE : 1;
		uint32_t RESV14 : 2;
		/* Packet did not follow SOM/EOM/Seq# rules or Source Endpoint ID did not match */
		uint32_t MCTPO : 1;
		/* TLP Prefix did not match known encodings */
		uint32_t UNSUPPREFIX : 1;
		/* TLP violates the programming model and treated as Completer Abort */
		uint32_t PROGMODLCA : 1;
		/* Received a PASID Prefix which violates a usage rule */
		uint32_t PASIDERR : 1;
		uint32_t RESV20 : 12;
	};
} FORMAT_68;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 6;
		uint32_t DRCT : 1;
		uint32_t DRCL : 1;
		uint32_t DRCR : 1;
		uint32_t DRCA : 1;
		uint32_t DRCTC : 1;
		uint32_t DIU3 : 1;
		uint32_t DTDN : 1;
		uint32_t DRTLPTCVC : 1;
		uint32_t DMRH : 1;
		uint32_t DMTLP : 1;
		uint32_t DMRLR : 1;
		uint32_t DLNE : 1;
		uint32_t DDGT : 1;
		uint32_t DATFU : 1;
		uint32_t DMRR : 1;
		uint32_t DT1C : 1;
		uint32_t DSRC : 1;
		uint32_t DPCIEL : 1;
		uint32_t DCSE : 1;
		uint32_t DISRESCPL : 1;
		uint32_t DRCS : 1;
		uint32_t DERI : 1;
		uint32_t DMRID : 1;
		uint32_t DUMTLP : 1;
		uint32_t DIMTLP : 1;
		uint32_t DIOCRL : 1;
	};
} FORMAT_69;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DNZA : 1;
		uint32_t DFBE : 1;
		uint32_t DLBE1 : 1;
		uint32_t DLBE : 1;
		uint32_t RESV4 : 3;
		uint32_t DLSE : 1;
		uint32_t DCBE : 1;
		uint32_t DCBC : 1;
		uint32_t DCLA : 1;
		uint32_t DBCMUE : 1;
		uint32_t DCRCBL : 1;
		uint32_t DUTLPFT : 1;
		uint32_t RESV14 : 2;
		uint32_t DMCTPOC : 1;
		uint32_t DUNSUPPREFIX : 1;
		uint32_t PROGMODLCA : 1;
		uint32_t PASIDERR : 1;
		uint32_t RESV20 : 12;
	};
} FORMAT_70;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*   Along with the Latency Scale field, this register conveys the Latency Value that the device will send. User
		 * should provide a value which does not exceed the Maximum Snoop Latency Tolerance Register. */
		uint32_t SLV : 10;
		/*  It is advisable not to change this scale value while cycles are running. If the scale is changed, the
latency violations error count and max observed value should be cleared before starting new cycles.[br]
000: 1ns[br]
001: 32 ns[br]
010: 1,024 ns[br]
011: 32,768 ns[br]
100: 1,048,576 ns[br]
101: 33,554,432 ns[br]
others: Not permitted */
		uint32_t SLS : 3;
		/*  These are reserved bits in the Snoop Latency format */
		uint32_t RESV13 : 2;
		uint32_t SRB : 1;
		/*   Along with the Latency Scale field, this register conveys the Latency Value that the device will send. User
		 * should provide a value which does not exceed the Maximum Non-Snooped Latency Tolerance Register. */
		uint32_t NSLV : 10;
		/* It is advisable not to change this scale value while cycles are running. If the scale is changed, the latency
violations error count and max observed value should be cleared before starting new cycles.[br]
000: 1ns[br]
001: 32 ns[br]
010: 1,024 ns[br]
011: 32,768 ns[br]
100: 1,048,576 ns[br]
101: 33,554,432 ns[br]
others: Not permitted */
		uint32_t NSLS : 3;
		/*  These are reserved bits in the Non-Snoop Latency format */
		uint32_t RESV29 : 2;
		uint32_t NSRB : 1;
	};
} FORMAT_71;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Sets the minimum delay between consecutive user initiated LTR messages. Each value is a 1us timeslice.
		 * Default represents the specs suggested 500us value. */
		uint32_t LTRMTT : 10;
		uint32_t RESV10 : 14;
		uint32_t PNSEC : 1;
		uint32_t PSEC : 1;
		uint32_t NPNSEC : 1;
		uint32_t NPSEC : 1;
		uint32_t RESV28 : 1;
		/*  Indicates an LTR message was internally dropped due to no space to enqeue it. */
		uint32_t LTRO : 1;
		/*  Prevents a LTR message with the Requirement bits cleared upon entering non-D0 or LTR Enable bit being
		 * cleared. */
		uint32_t BCRLTR : 1;
		/*  When enabled, any write to the Latency Tolerance Reporting Values Register will cause a new Message to be
		 * scheduled. When disabled, only a write to the Latency Tolerance Reporting Values Register with a different
		 * value will cause a new Message to be broadcast. */
		uint32_t LTVUO : 1;
	};
} FORMAT_72;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t NPS : 8;
		uint32_t NPNS : 8;
		uint32_t NNPS : 8;
		uint32_t NNPNS : 8;
	};
} FORMAT_73;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MNPNSL1 : 10;
		uint32_t MNPNSL : 3;
		uint32_t RESV13 : 3;
		uint32_t MNPSL1 : 10;
		uint32_t MNPSL : 3;
		uint32_t RESV29 : 3;
	};
} FORMAT_74;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MPNSL1 : 10;
		uint32_t MPNSL : 3;
		uint32_t RESV13 : 3;
		uint32_t MPSL1 : 10;
		uint32_t MPSL : 3;
		uint32_t RESV29 : 3;
	};
} FORMAT_75;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Starts when first config is received. When enabled, decrements each timer tick based on Granularity of CRS
Timer field.[br]
0 = disabled */
		uint32_t CRST : 16;
		/* When Enabled, decrements on each Config request received[br]
0 = disabled */
		uint32_t CCCTCRS : 8;
		/* 00 - 16 ns per tick[br]
01 - 1 us[br]
10 - 1 ms[br]
11 - Reserved */
		uint32_t GCRST : 2;
		uint32_t RESV26 : 2;
		uint32_t CRSTD : 1;
		uint32_t CRSCD : 1;
		uint32_t CRSTE : 1;
		uint32_t CRSCE : 1;
	};
} FORMAT_76;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When enabled, starts decrementing with the first packet received. */
		uint32_t FLRT : 8;
		/* When enabled, decrements with each packet received. */
		uint32_t NC : 8;
		/* 00 - 16 ns per tick[br]
01 - 1 s[br]
10 - 1 ms[br]
11 - Reserved */
		uint32_t GFLRT : 2;
		uint32_t RESV18 : 8;
		/*  Clears the CRS done and overrides the enable setting in CRS Control Register  */
		uint32_t ES1 : 1;
		/*  Clears the CRS done and overrides the enable setting in CRS Control Register */
		uint32_t ES : 1;
		/* Indicates the timer reaching zero caused the FLR to complete. This bit must be clear before the timer can be
		 * rearmed. */
		uint32_t FLRTD : 1;
		/* Indicates the counter reaching zero caused the FLR to complete. This bit must be clear before the counter can
		 * be rearmed.  */
		uint32_t FLRCD : 1;
		/* Arm is bit 15 of PCI-Express Device */
		uint32_t FLRTE : 1;
		/* Arm is bit 15 of PCI-Express Device Control  */
		uint32_t FLRCE : 1;
	};
} FORMAT_77;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 8;
		uint32_t LWCT64 : 1;
		/*  Includes all related states entry, idle, fts, etc. */
		uint32_t LWCT63 : 1;
		uint32_t LWCT62 : 1;
		uint32_t RESV11 : 1;
		uint32_t RESV12 : 1;
		uint32_t EDLAFW : 1;
		/* 00: 4ns/tick (-2ns/+0)[br]
01: 2^10 ns (~1s)/tick (-1022ns/+0)[br]
10: 2^20 ns (~1ms)/tick (-1ms/+0)[br]
11: reserved */
		uint32_t LWCT : 2;
		/*  Time before entering recovery advertising a change of width as determined by Link Width Change Target
Registers. After event, the target width index advances and the timer begins again.When the timer expires, if the
current operating width matches the desired width in the target index, a transition to recovery will not occur, the
target width index will advance and the timer begins again.
This timer is enabled using the associated individual link state enables below and globally disabled with Hardware
Autonomous Width Disable. If the initial width trains as x1 or the other agent does not support upconfig, this logic is
disabled. */
		uint32_t LWCE : 16;
	};
} FORMAT_78;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This is the maximum number of lanes the link can upconfigure to._maxlanes_4_upcfg[15:0] */
		uint32_t ITLW : 16;
		uint32_t RESV16 : 16;
	};
} FORMAT_79;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI0 : 3;
		uint32_t AACB71 : 1;
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI1 : 3;
		uint32_t AACB70 : 1;
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI2 : 3;
		uint32_t AACB69 : 1;
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI3 : 3;
		uint32_t AACB68 : 1;
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI4 : 3;
		uint32_t AACB67 : 1;
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI5 : 3;
		uint32_t AACB66 : 1;
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI6 : 3;
		uint32_t AACB65 : 1;
		/* 000 - x1[br]
001 - x2[br]
010 - x4[br]
011 - x8[br]
100 - x16[br]
Note: This value will be capped by hardware to the highest possible width based on the initial trained link width. */
		uint32_t TWI7 : 3;
		uint32_t AACB : 1;
	};
} FORMAT_80;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR77 : 4;
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width.. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR76 : 4;
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR75 : 4;
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR74 : 4;
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR73 : 4;
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR72 : 4;
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR1 : 4;
		/* Encoded value describes which lane of the 16 possible to treat as lane 0 of the new width within the range of
		 * valid lanes from the first training. This value will be adjusted to a valid lane by hardware based on the
		 * target link width. Note the only valid locations for lane 0 are listed in Table 2 4. Link Configurations */
		uint32_t TWCR : 4;
	};
} FORMAT_81;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When device is configured in global Seed Register Behavior mode, all VMs, Targets, and Multicast Groups use
		 * this as their ROI seed register for Master and Target data generators. Otherwise this is the ROI seed for
		 * just VM0. */
		uint32_t RIROI : 32;
	};
} FORMAT_82;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When device is configured in global Seed Register Behavior mode, all VMs, Targets, and Multicast Groups use
		 * this as their ROL seed register for Master and Target data generators. Otherwise this is the ROL seed for
		 * just VM0. */
		uint32_t RLROLD : 32;
	};
} FORMAT_83;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When ROL and ROI Seed Register Behavior is not set to global mode */
		uint32_t MRI : 32;
	};
} FORMAT_84;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When ROL and ROI Seed Register Behavior is not set to global mode */
		uint32_t MRLROL : 32;
	};
} FORMAT_85;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 3h - Memory Write */
		uint32_t FMT : 4;
		uint32_t RESV4 : 4;
		/* 0 - Selects DW0 in the expected and actual error data registers[br]
...[br]
7 - Selects DW7 in the expected and actual error data registers */
		uint32_t EI : 3;
		uint32_t RESV11 : 5;
		uint32_t MREV : 1;
		uint32_t RESV17 : 3;
		uint32_t MBCC : 1;
		uint32_t RESV21 : 3;
		uint32_t EIOE : 1;
		uint32_t RESV25 : 7;
	};
} FORMAT_86;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t TLPI : 1;
		uint32_t UAVI : 1;
		/*  Error address [lb]63:32[rb] can be located in Multicast Error Upper Address Register */
		uint32_t DCFL : 30;
	};
} FORMAT_87;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DCFU : 32;
	};
} FORMAT_88;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This is one of the 8 DWs stored upon error. The selection index can be chosen in the Error Control Register.
		 */
		uint32_t ADR : 32;
	};
} FORMAT_89;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This is one of the 8 DWs stored upon error. The selection index can be chosen in the Error Control Register.
		 */
		uint32_t EDR : 32;
	};
} FORMAT_90;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Counts valid bytes written in this byte lane. Counter may rollover. */
		uint32_t BL0C : 8;
		/*  Counts valid bytes written in this byte lane. Counter may rollover. */
		uint32_t BL1C : 8;
		/*  Counts valid bytes written in this byte lane. Counter may rollover. */
		uint32_t BL2C : 8;
		/*  Counts valid bytes written in this byte lane. Counter may rollover. */
		uint32_t BL3C : 8;
	};
} FORMAT_91;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Counter does not rollover. */
		uint32_t NL0TXL0S : 8;
		/* In Cambria Core, we have no indication from controller if link is in RxL0s. This count will be 0.[br]Counter
		 * does not rollover. */
		uint32_t NL0RXL0S : 8;
		/* In Cambria Core, we have no indication from controller if link is in RxL0s. This is generic count of TxL0s to
		 * Recovery transitions.[br]Counter does not rollover. */
		uint32_t NRXL0SR : 8;
		/* In Cambria Core, we are unable to infer which side actually initiated the Recovery. This is generic count of
		 * L0 to Recovery transitions.[br]Counter does not rollover. */
		uint32_t NL0RLP : 8;
	};
} FORMAT_92;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Counter does not rollover. */
		uint32_t NL0L1 : 8;
		/*  Counter does not rollover. */
		uint32_t NL1REC : 8;
		/*  Counter does not rollover. */
		uint32_t NL1RED : 8;
		/*  Counter does not rollover. */
		uint32_t NL0L2 : 8;
	};
} FORMAT_93;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* The old Global PM_Request_Ack DLLP Status Pause Continue Counter */
		uint32_t GPMRADLLPCC : 1;
		uint32_t GPMASNCC : 1;
		uint32_t GPMPMECC : 1;
		uint32_t GPMTOMD3CC : 1;
		uint32_t RESV4 : 2;
		uint32_t GRECC : 1;
		uint32_t RESV7 : 1;
		/* The old Global PM_Request_Ack DLLP Status Pause Continue Counter Clear */
		uint32_t GPMRADLLPCCC : 1;
		uint32_t GPMASNCCC : 1;
		uint32_t GPMPMECCC : 1;
		uint32_t GPMTOMD3CCC : 1;
		uint32_t RESV12 : 2;
		uint32_t GRECCC : 1;
		uint32_t RESV15 : 1;
		/* The old Global Emergency Clear for Vector Paused on PM_Request_Ack DLLP */
		uint32_t GECPMREQACK : 1;
		uint32_t GECPMASNAK : 1;
		uint32_t GECPME : 1;
		uint32_t GECPMTO : 1;
		/* The old Global Emergency Clear for Vector Paused on Receiver in Electrical Idle Status */
		uint32_t GECEI : 1;
		uint32_t RESV21 : 1;
		uint32_t GECREC : 1;
		uint32_t GECWAE : 1;
		/* The old Global Emergency Clear Status for Vector Paused on PM_Request_Ack DLLP Status */
		uint32_t GECSPMREQACK : 1;
		uint32_t GECSPMASNAK : 1;
		uint32_t GECSPME : 1;
		uint32_t GECSPMTO : 1;
		/* The old Global Emergency Clear Status for Vector Paused on Receiver in Electrical Idle Status */
		uint32_t GECSEI : 1;
		uint32_t RESV29 : 1;
		uint32_t GECSRE : 1;
		uint32_t GECSWAE : 1;
	};
} FORMAT_94;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  0000 - WAKE# is deasserted when PE_RESETB signal is deasserted on exit from D3COLD exit.[br]
...[br]
FFFF - WAKE# deassertion is delayed by 0xFFFF ticks after PE_RESETB signal is deasserted on exit from D3COLD exit.[br]
1 tick is 512ns (-0/+40ns total) */
		uint32_t WD : 16;
		uint32_t RESV16 : 16;
	};
} FORMAT_95;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SIDVM30 : 2;
		uint32_t VMIDD : 2;
		uint32_t RESV4 : 1;
		uint32_t VMSID29 : 1;
		uint32_t RESV6 : 2;
		/*  Global to all VMs[br]0 - Command A[br]1 - Command B */
		uint32_t GPMRADLLPPS : 1;
		/*  Global to all VMs[br]0 - Command A[br]1 - Command B */
		uint32_t GPMASNMPS : 1;
		/*  Global to all VMs[br]0 - Command A[br]1 - Command B */
		uint32_t GPMPMESCPS : 1;
		/*  Global to all VMs[br]0 - Command A[br]1 - Command B */
		uint32_t GPMETOM : 1;
		/*  Global to all VMs[br]0 - Command A[br]1 - Command B */
		uint32_t GEEI : 1;
		/*  Global to all VMs[br]0 - Command A[br]1 - Command B */
		uint32_t GTRIGINBPC : 1;
		/*  0 - Command A[br]1 - Command B */
		uint32_t VM0WDT : 1;
		/*  0 - Command A[br]1 - Command B */
		uint32_t VM1WDT : 1;
		/*  0 - Command A[br]1 - Command B */
		uint32_t VM2WDT : 1;
		/*  0 - Command A[br]1 - Command B */
		uint32_t VM3WDT : 1;
		uint32_t RESV18 : 1;
		uint32_t RESV19 : 1;
		uint32_t SIDVM28 : 2;
		uint32_t VMIDPM : 2;
		uint32_t RESV24 : 1;
		/*  When set, if user clears the PME_Status the external pause release continue counter in VM/Stream selected by
		 * bits [24:20] is incremented. */
		uint32_t VMSID27 : 1;
		uint32_t SIDVM : 2;
		uint32_t VMIDPMASN : 2;
		uint32_t RESV30 : 1;
		/*  When set, if Device receives a PM_Active_State_Nak TLP Request the external pause release continue counter
		 * in VM/Stream selected by bits [30:26] is incremented. */
		uint32_t VMSID : 1;
	};
} FORMAT_96;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SIDVMPMETO : 2;
		uint32_t VMIDPMETO : 2;
		uint32_t RESV4 : 1;
		/*  When set, if Device receives a PME_Turn_Off TLP Request in D3, the external pause release continue counter
		 * in VM/Stream selected by bits [4:0] is incremented. */
		uint32_t VMSIDPMETO : 1;
		uint32_t RESV6 : 2;
		uint32_t GPMPMECC : 1;
		uint32_t GPMETOCC : 1;
		/* Note: If this continue counter is cleared using the Power Management Vector, it will clear only that VMs
		 * counter. */
		uint32_t GPMRACC : 1;
		/* Note: If this continue counter is cleared using the Power Management Vector, it will clear only that VMs
		 * counter. */
		uint32_t GPMASNCC : 1;
		uint32_t GERSEXT : 1;
		uint32_t GCCCEXT : 1;
		uint32_t GEREXT : 1;
		/*  When set, this indicates that the PME Status bit has been cleared by the user and prevents the PME Status
from being set by hardware.This will be automatically cleared to 0 when the PME Status bit is cleared by the user and
the device completes issuing the last PM_PME Message.
The PM_PME Message TLP is issued within a loop. The PME Status bit is set in the first iteration of the loop. The user
will asynchronously clear the PME Status bit in response to the PM_PME Message TLP. Once the PME Status is cleared, the
VM will exit the PM-PME loop. The hardware will ensure that the PME Status is not set again within this loop.
In the event of some malfunction - The user can write a 1 to clear this bit and allow the PME Status bit to be set when
future PM_PME Messages are issued. */
		uint32_t PMESUL : 1;
		/*  Global to all VMs[br]0 - Command A[br]
1 - Command B */
		uint32_t GRCS : 1;
		/*  Global to all VMs[br]0 - Command A[br]
1 - Command B */
		uint32_t GNOTRC : 1;
		/*  Global to all VMs[br]0 - Command A[br]
1 - Command B */
		uint32_t GL1ICS : 1;
		/*  Global to all VMs[br]0 - Command A[br]
1 - Command B */
		uint32_t GNOTL1IC : 1;
		/*  Global to all VMs[br]0 - Command A[br]
1 - Command B */
		uint32_t GL2ICS : 1;
		/*  Global to all VMs[br]0 - Command A[br]
1 - Command B */
		uint32_t GNOTL2IC : 1;
		/* 0 - Command A[br]
1 - Command B */
		uint32_t GL0CS : 1;
		/* 0 - Command A[br]
1 - Command B */
		uint32_t GREC : 1;
		/* The old PM_Enter_L23 Command Selector[br]0 - Command A[br]
1 - Command B */
		uint32_t PMEL23CS : 1;
		/* The old PM_Active_State_Request_L1 Command Selector[br]0 - Command A[br]
1 - Command B */
		uint32_t PMASRL1CS : 1;
		/* The old Global Continue Counter for PM_Enter_L23 DLLP */
		uint32_t GCCPML23 : 1;
		/* The old Global Continue Counter for PM_Active_State_Request_L1 DLLP */
		uint32_t GCCASPML1 : 1;
		/* Global Emergency Release for Vector Paused on PM_Enter_L23 DLLP */
		uint32_t GERPML23 : 1;
		/* The old Global Emergency Release for Vector Paused on PM_Active_State_Request_L1 DLLP */
		uint32_t GERASPML1 : 1;
		/* The old Global Emergency Release Status for Vector Paused on PM_Enter_L23 DLLP */
		uint32_t GERSPML23 : 1;
		/* The old Global Emergency Release Status for Vector Paused on PM_Active_State_Request_L1 DLLP */
		uint32_t GERSASPML1 : 1;
	};
} FORMAT_97;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 24;
		/*  Counter does not rollover */
		uint32_t NPMASNTLP : 8;
	};
} FORMAT_98;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Completions are normally NOT  blocked when ASPM and PCI-PM super lock is not established and before the
		 * completion corresponding to setting the device to non-D0. */
		uint32_t BCWN : 1;
		uint32_t RESV1 : 7;
		/*  Completions are normally blocked when ASPM and PCI-PM super lock is established and after the completion
		 * corresponding to setting the device to non-D0. */
		uint32_t UCW : 1;
		uint32_t RESV9 : 7;
		/* 0: 8ns[br]
1: 1 us[br]
...[br]
FFFFh:  65,535 us[br]
[br]
The retrigger event timer is armed when an Internal Access Vector is executed with the TA/TB bit set to '1' and counter
is idle. If the counter is already armed/counting  and another arm event is received, that event is ignored.
The timer will actively count in L0 and the current non-D0 state. (setting DFS1.16 will allow this timer to work in the
correctly D0-L2 Ready scenario)
An active timer is aborted when:[br]
PM-TURN-OFF MSG is received[br]
If there is a valid D-state change */
		uint32_t REDT : 16;
	};
} FORMAT_99;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 0 - Command A[br]1 - Command B */
		uint32_t GD0PS : 1;
		/* 0 - Command A[br]1 - Command B */
		uint32_t GND0P : 1;
		/* 0 - Command A[br]1 - Command B */
		uint32_t GCTS : 1;
		/* 0 - Command A[br]1 - Command B */
		uint32_t GEM : 1;
		/* 0 - Command A[br]1 - Command B */
		uint32_t GTL0PC : 1;
		/* 0 - Command A[br]1 - Command B */
		uint32_t GVDSC : 1;
		/* 0 - Command A[br]1 - Command B */
		uint32_t GNVDS : 1;
		/* 0 - Command A[br]1 - Command B */
		uint32_t GCLKREQS : 1;
		uint32_t GSER627 : 1;
		uint32_t GSER626 : 1;
		uint32_t GSER625 : 1;
		uint32_t GSER624 : 1;
		uint32_t GSER623 : 1;
		uint32_t GSERTXL0S : 1;
		uint32_t GCCSE : 1;
		uint32_t GSER : 1;
		uint32_t RESV16 : 1;
		uint32_t RESV17 : 1;
		uint32_t GCAC : 1;
		uint32_t GCCLKREQCC : 1;
		/* Power State of Function 0 reported by the controller[br]
  One-hot signal for the D-state of the function[br]
4b0001  D0[br]
4b0010  D1[br]
4b0100  D2[br]
4b1000  D3 */
		uint32_t DSTATE : 4;
		/* Application Layer has a packet to send or is trying to wake the link */
		uint32_t APPXFERPEND : 1;
		/* Indicates HIP Tx FIFO empty */
		uint32_t HIPTXEMPTY : 1;
		uint32_t RESV26 : 6;
	};
} FORMAT_100;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t EIDVM0 : 2;
		uint32_t VBVM0 : 1;
		uint32_t EIDVM1 : 2;
		uint32_t VBVM1 : 1;
		uint32_t EIDVM2 : 2;
		uint32_t VBVM2 : 1;
		uint32_t EIDVM3 : 2;
		uint32_t VBVM3 : 1;
		uint32_t RESV12 : 3;
		uint32_t RESV15 : 3;
		uint32_t RESV18 : 13;
		uint32_t APRE : 1;
	};
} FORMAT_101;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* For Cambria, the value needs to be programmed in controller register
		 * PF0_PORT_LOGIC/ACK_F_ASPM_CTRL_OFF.L1_ENTRANCE_LATENCY[br]When configured for Automatic ASPM L1 mode, the
		 * amount of consecutive logical idle time before transitioning to ASPM L1. 4ns/tick. A value of zero will
		 * disable L1 transitions. ASPM L1 must be disabled when changing this value. */
		uint32_t AASPML1E : 16;
		/*  Amount of time to remain in the state as long as link partner does not initiate Recovery.0 - Remain in ASPM
L1 as long as there are no packets pending.
1h to FFFFh - Remain in ASPM L1 the programmed amount regardless if there are packets to send. 4ns/tick.
Note this will continue to count time in L1.1 & L1.2 states but will not cause exit from those states */
		uint32_t AASPML1S : 16;
	};
} FORMAT_102;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* LTSSM state value that will be inserted for a single clock */
		uint32_t LTSSMCLR : 8;
		uint32_t RESV8 : 24;
	};
} FORMAT_103;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t M0DC : 1;
		uint32_t M1DC : 1;
		uint32_t M2DC : 1;
		uint32_t M3DC : 1;
		uint32_t M4DC : 1;
		uint32_t M5DC : 1;
		uint32_t M6DC : 1;
		uint32_t M7DC : 1;
		uint32_t M8DC : 1;
		uint32_t M9DC : 1;
		uint32_t M10DC : 1;
		uint32_t M11DC : 1;
		uint32_t M12DC : 1;
		uint32_t M13DC : 1;
		uint32_t M14DC : 1;
		uint32_t M15DC : 1;
		uint32_t M0DHM : 1;
		uint32_t M1DHM : 1;
		uint32_t M2DHM : 1;
		uint32_t M3DHM : 1;
		uint32_t M4DHM : 1;
		uint32_t M5DHM : 1;
		uint32_t M6DHM : 1;
		uint32_t M7DHM : 1;
		uint32_t M8DHM : 1;
		uint32_t M9DHM : 1;
		uint32_t M10DHM : 1;
		uint32_t M11DHM : 1;
		uint32_t M12DHM : 1;
		uint32_t M13DHM : 1;
		uint32_t M14DHM : 1;
		uint32_t M15DHM : 1;
	};
} FORMAT_104;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  May Rollover. */
		uint32_t MDCH : 8;
		/*  May Rollover. */
		uint32_t MDCM : 8;
		uint32_t RESV16 : 8;
		/*  Indicates which message comparator detected the first error. */
		uint32_t MCED : 4;
		uint32_t RESV28 : 3;
		uint32_t MDCE : 1;
	};
} FORMAT_105;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW0E : 32;
	};
} FORMAT_106;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW1E : 32;
	};
} FORMAT_107;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW2E : 32;
	};
} FORMAT_108;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW3E : 32;
	};
} FORMAT_109;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW0M : 32;
	};
} FORMAT_110;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW1M : 32;
	};
} FORMAT_111;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW2M : 32;
	};
} FORMAT_112;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW3M : 32;
	};
} FORMAT_113;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW0A : 32;
	};
} FORMAT_114;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW1A : 32;
	};
} FORMAT_115;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW2A : 32;
	};
} FORMAT_116;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t DW3A : 32;
	};
} FORMAT_117;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t IGC0 : 1;
		uint32_t IGC1 : 1;
		uint32_t IGC2 : 1;
		uint32_t IGC3 : 1;
		uint32_t IGC4 : 1;
		uint32_t IGC5 : 1;
		uint32_t IGC6 : 1;
		uint32_t IGC7 : 1;
		uint32_t DGC0 : 1;
		uint32_t DGC1 : 1;
		uint32_t DGC2 : 1;
		uint32_t DGC3 : 1;
		uint32_t DGC4 : 1;
		uint32_t DGC5 : 1;
		uint32_t DGC6 : 1;
		uint32_t DGC7 : 1;
		uint32_t RESV16 : 16;
	};
} FORMAT_118;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Counter may rollover/rollunder. */
		uint32_t GC0 : 8;
		/*  Counter may rollover/rollunder. */
		uint32_t GC1 : 8;
		/*  Counter may rollover/rollunder. */
		uint32_t GC2 : 8;
		/*  Counter may rollover/rollunder. */
		uint32_t GC3 : 8;
	};
} FORMAT_119;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Counter may rollover/rollunder. */
		uint32_t GC4 : 8;
		/*  Counter may rollover/rollunder. */
		uint32_t GC5 : 8;
		/*  Counter may rollover/rollunder. */
		uint32_t GC6 : 8;
		/*  Counter may rollover/rollunder. */
		uint32_t GC7 : 8;
	};
} FORMAT_120;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG0D : 3;
		uint32_t RESV3 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG1D : 3;
		uint32_t RESV7 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG2D : 3;
		uint32_t RESV11 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG3D : 3;
		uint32_t RESV15 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG4D : 3;
		uint32_t RESV19 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG5D : 3;
		uint32_t RESV23 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG6D : 3;
		uint32_t RESV27 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MG7D : 3;
		uint32_t RESV31 : 1;
	};
} FORMAT_121;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG0S : 8;
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG1S : 8;
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG2S : 8;
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG3S : 8;
	};
} FORMAT_122;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG4S : 8;
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG5S : 8;
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG6S : 8;
		/*  Any Multicast_Hit to a Multicast Group mod 8 which does not have its MC_Receive bit set resulting in a
		 * silent drop will be counted here. Counter does not rollover. */
		uint32_t MG7S : 8;
	};
} FORMAT_123;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 00: 16 ns per tick[br]
01: 1 us per tick[br]
10: 8 us per tick */
		uint32_t TCLMC : 2;
		uint32_t RESV2 : 22;
		/*  Clears the TC0 Error Count and Maximum Observed Latency. */
		uint32_t TC0LMR : 1;
		/*  Clears the TC1 Error Count and Maximum Observed Latency. */
		uint32_t TC1LMR : 1;
		/*  Clears the TC2 Error Count and Maximum Observed Latency. */
		uint32_t TC2LMR : 1;
		/*  Clears the TC3 Error Count and Maximum Observed Latency. */
		uint32_t TC3LMR : 1;
		/*  Clears the TC4 Error Count and Maximum Observed Latency. */
		uint32_t TC4LMR : 1;
		/*  Clears the TC5 Error Count and Maximum Observed Latency. */
		uint32_t TC5LMR : 1;
		/*  Clears the TC6 Error Count and Maximum Observed Latency. */
		uint32_t TC6LMR : 1;
		/*  Clears the TC7 Error Count and Maximum Observed Latency. */
		uint32_t TC7LMR : 1;
	};
} FORMAT_124;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC0 Latency Monitor Register Clear field. */
		uint32_t TC0LEC : 8;
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC1 Latency Monitor Register Clear field. */
		uint32_t TC1LEC : 8;
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC2 Latency Monitor Register Clear field. */
		uint32_t TC2LEC : 8;
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC3 Latency Monitor Register Clear field. */
		uint32_t TC3LEC : 8;
	};
} FORMAT_125;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC4 Latency Monitor Register Clear field. */
		uint32_t TC4LEC : 8;
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC5 Latency Monitor Register Clear field. */
		uint32_t TC5LEC : 8;
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC6 Latency Monitor Register Clear field. */
		uint32_t TC6LEC : 8;
		/*  Incremented whenever the measured latency is greater then the programmed threshold value. Counter will not
		 * rollover. To clear, write to TC7 Latency Monitor Register Clear field. */
		uint32_t TC7LEC : 8;
	};
} FORMAT_126;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will increment the associated
		 * error counter register.16ns per tick */
		uint32_t TNPR : 16;
		/*  Updated with the longest delay observed for any non-posted request completion on this TC. A completion
		 * timeout will set this to the maximum value.16ns per tick */
		uint32_t MOL : 16;
	};
} FORMAT_127;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 1 clock tick is 16ns. To reset this timer, write to the Live Timer Register Clear field */
		uint32_t LT : 32;
	};
} FORMAT_135;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Each bit corresponds to each of the eight available timers. */
		uint32_t TAI : 8;
		/*  Each bit corresponds to each of the eight available timers. This will be set if consecutive stops are
		 * detected without any starts in between or a stop is detected without a valid start . */
		uint32_t MSS : 8;
		/*  Each bit corresponds to each of the eight available timers. This will be set if consecutive starts are
		 * detected without any stops in between. */
		uint32_t MSI : 8;
		/* Each bit corresponds to each of the eight available timers.[br]Clears the Timestamp Latency Error Counter[br]
Clears the Timestamp Latency Max Value Register[br]
Clears the Timestamp Start/Stop Register */
		uint32_t TLC : 8;
	};
} FORMAT_136;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SVSF : 32;
	};
} FORMAT_137;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SVSF1 : 32;
	};
} FORMAT_138;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T0TL : 32;
	};
} FORMAT_153;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T1TL : 32;
	};
} FORMAT_154;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T2TL : 32;
	};
} FORMAT_155;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T3TL : 32;
	};
} FORMAT_156;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T4TL : 32;
	};
} FORMAT_157;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T5TL : 32;
	};
} FORMAT_158;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T6TL : 32;
	};
} FORMAT_159;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Non-posted requests that complete with latencies above this threshold level will be counted as errors. The
		 * associated error counter register is incremented.16ns/tick for a maximum delay of 68s. */
		uint32_t T7TL : 32;
	};
} FORMAT_160;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 0 */
		uint32_t T0LE : 8;
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 1 */
		uint32_t T1LE : 8;
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 2 */
		uint32_t T2LE : 8;
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 3 */
		uint32_t T3LE : 8;
	};
} FORMAT_161;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 4 */
		uint32_t T4LE : 8;
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 5 */
		uint32_t T5LE : 8;
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 6 */
		uint32_t T6LE : 8;
		/*  This counter is incremented whenever the measured latency is greater than the programmed threshold value in
		 * the Timestamp Latency Threshold Register 7 */
		uint32_t T7LE : 8;
	};
} FORMAT_162;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t MOL : 32;
	};
} FORMAT_163;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 8;
		/* 0 - Selects DW0 in the MCTP expected and actual error data registers[br]
... */
		uint32_t EI : 3;
		uint32_t RESV11 : 1;
		/*  Selects Programmed Source Endpoint ID index for readback display of byte counters, SOM counters, and EOM
		 * counters */
		uint32_t MCTPCRI : 2;
		uint32_t RESV14 : 2;
		uint32_t MCTPDEV : 1;
		uint32_t RESV17 : 3;
		/* Clears all four related counters */
		uint32_t MCTPBCC : 1;
		uint32_t RESV21 : 3;
		uint32_t EIE : 1;
		uint32_t RESV25 : 3;
		/* Clears all four Source Endpoint ID internal addresses */
		uint32_t MCTPATC : 1;
		/*  Clears all four related counters */
		uint32_t MCTPSOMEOM : 1;
		uint32_t RESV30 : 2;
	};
} FORMAT_171;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  This is index of the Source Endpoint ID value that this transaction was compared against */
		uint32_t SEIDI : 2;
		uint32_t DCFA312 : 30;
	};
} FORMAT_172;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SMCTPR : 32;
	};
} FORMAT_175;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SMCTPRL : 32;
	};
} FORMAT_176;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t SEID0 : 8;
		uint32_t SEID1 : 8;
		uint32_t SEID2 : 8;
		uint32_t SEID3 : 8;
	};
} FORMAT_177;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t EM0MCTP : 1;
		uint32_t EM1MCTP : 1;
		uint32_t EM2MCTP : 1;
		uint32_t EM3MCTP : 1;
		uint32_t EM4MCTP : 1;
		uint32_t EM5MCTP : 1;
		uint32_t EM6MCTP : 1;
		uint32_t EM7MCTP : 1;
		uint32_t EM8MCTP : 1;
		uint32_t EM9MCTP : 1;
		uint32_t EM10MCTP : 1;
		uint32_t EM11MCTP : 1;
		uint32_t EM12MCTP : 1;
		uint32_t EM13MCTP : 1;
		uint32_t EM14MCTP : 1;
		uint32_t EM15MCTP : 1;
		/*  This is the readback of the Source Endpoint ID selected by MCTP Counters Readback Index. Counter may
		 * rollover. */
		uint32_t SOMC : 8;
		/*  This is the readback of the Source Endpoint ID selected by MCTP Counters Readback Index. Counter may
		 * rollover. */
		uint32_t EOMC : 8;
	};
} FORMAT_178;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MCTPSEID0 : 3;
		uint32_t RESV3 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MCTPSEID1 : 3;
		uint32_t RESV7 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MCTPSEID2 : 3;
		uint32_t RESV11 : 1;
		/* Data pattern expected for this group[br]000: Increment[br]
001: ROL[br]
010: Analog[br]
011: ROI[br]
1xx: EV Buffer */
		uint32_t MCTPSEID3 : 3;
		uint32_t RESV15 : 1;
		/*  When enable, this is the Source Endpoint ID index that will store the MCTP data payloads into EV Buffer upon
		 * a hit.  */
		uint32_t SEID : 2;
		/*  Enables all MCTP data payloads matching the associated Source Endpoint ID index which are a hit to an
		 * enabled Message Type to be stored in the EV Buffer in incrementing address order. The data will not be
		 * compared thus the associated data pattern field is ignored. Byte Counters will not increment. If this is
		 * enabled, no other Source Endpoint IDs should use the EV Buffer data pattern. */
		uint32_t EEVBS : 1;
		uint32_t RESV19 : 13;
	};
} FORMAT_180;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Number of Completions with Unsupported Request (UR) Status to Non-Posted Requests Targeting Trusted
Resources [br]:
Only applies to packets generated from vectors with the LT bit set. Counter may rollover. [br]
Note: Normally this type of completion status would result in Received Master Abort Status getting set. But because the
original request was created with the LT bit set, we do not treat this as an error as this is the expected status for
the addressed target region.  */
		uint32_t NCUR : 8;
		/*  Number of Completions with Completer Abort (CA) Status to Non-Posted Requests Targeting Trusted Resources.
[br]
Only applies to packets generated from vectors with the LT bit set. Counter may rollover.[br]
Note: Normally this type of completion status would result in Completer Abort Status and Received Target Abort Status
getting set. But because the original request was created with the LT bit set, we do not treat this as an error as this
is the expected status for the addressed target region.  */
		uint32_t NCCA : 8;
		uint32_t RESV16 : 6;
		/*  Clear Number of Completions with Unsupported Request (UR) Status to Non-Posted Requests Targeting Trusted
		 * Resources (): bits[7:0] below */
		uint32_t CNC1 : 1;
		/*  Clear Number of Completions with Completer Abort (CA) Status to Non-Posted Requests Targeting Trusted
		 * Resources (): bits[15:8] below */
		uint32_t CNC : 1;
		uint32_t RESV24 : 8;
	};
} FORMAT_181;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* When enabled for L1.1, the amount of time in L1.0 before requesting transition to L1.1.[br]0000h: Do not
		 * request entry to L1.1[br]others: N * 8ns */
		uint32_t L11EL : 16;
		/*  Amount of time to remain in the L1.1 state before initiating exit as long as link partner does not initiate
the exit first.[br]0000h: do not initiate exit[br]
others: N * L1.1 State Latency Scale */
		uint32_t L11SL : 13;
		uint32_t RESV29 : 1;
		/* 00b: 8 ns[br]
01b: 4 us[br]
10b: 4 ms[br]
11b: not supported */
		uint32_t L11SLS : 2;
	};
} FORMAT_182;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When enabled for L1.2, the amount of time in L1.0 before requesting transition to L1.2 while taking into
consideration  the T_L1_2_EXIT2ENTRY Policy setting.[br]0000h: Do not request entry to L1.2[br]
others: N * 8ns */
		uint32_t L12EL : 16;
		/*  Amount of time to remain in the L1.2 state before initiating exit as long as link partner does not initiate
the exit first. Spec defines 4 us minimum[br]
0000h: do not initiate exit[br]
others: N * L1.2 State Latency Scale */
		uint32_t TL1_2 : 13;
		uint32_t RESV29 : 1;
		/* 00b: 8 ns[br]
01b: 4 us[br]
10b: 4 ms[br]
11b: not supported */
		uint32_t L12SLS : 2;
	};
} FORMAT_183;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Spec defines a 2us maximum[br]
8ns/tick */
		uint32_t TPOWEROFFV : 12;
		uint32_t RESV12 : 4;
		/* Time between L1.2.EXIT and the next L1.2.ENTRY when CLKREQ# must remain active. Spec default 4us. Device can
		 * ignore this backoff time if T_L1_2_EXIT2ENTRY Policy field is set[br]8ns/tick */
		uint32_t TL12EXIT2ENTRY : 16;
	};
} FORMAT_184;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Initiate Exit from L1.X Substate */
		uint32_t EL1S : 1;
		uint32_t RESV1 : 7;
		/* 0: Spec, Do not deassert CLKREQ# during time period[br]
1: Ignore backoff time period */
		uint32_t TL12EXIT2ENTRYP : 1;
		uint32_t DCMS : 1;
		uint32_t DEIB : 1;
		uint32_t RESV11 : 1;
		/* Time (32ns/tick) delay between CLKREQB assertion and switching to the slot refclk source. Essentially T_CRLon
		 */
		uint32_t DREFS : 4;
		/* Sets the corresponding value advertised in the L1SUBCAP register[br]00b = 2us[br]
01b = 10us[br]
10b = 100us[br]
11b = Reserved */
		uint32_t PTPOWERONAS : 2;
		uint32_t RESV18 : 1;
		/* Sets the corresponding value advertised in the L1SUBCAP register */
		uint32_t PTPOWERONAV : 5;
		/* Sets corresponding value advertised in the L1SUBCAP register field. Time (in us) required for this Port to
		 * re-establish common mode */
		uint32_t PCMRT : 8;
	};
} FORMAT_185;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* To properly check for this condition, the programmed L1.2 Entry Latency must be less than the
T_L1_2_EXIT2ENTRY time and the T_L1_2_EXIT2ENTRY Policy must be set to ignore following the rule[br]
clkreq_deassert_after_l12exit */
		uint32_t UCLKREQDB : 1;
		/* To properly check for this condition, the programmed L1.2 State Latency value must be set above the spec
minimum 4us[br]
clkreq_assert_l12 */
		uint32_t UCLKREQAD : 1;
		uint32_t RESV2 : 6;
		/* Counter does not rollover[br]_inc_l1_1_cnt */
		uint32_t NL11ST : 8;
		/* Counter does not rollover[br]_inc_l1_2_cnt */
		uint32_t NSL12S : 8;
		/* Counter does not rollover[br]_inc_abort_l1_2_cnt */
		uint32_t NAL12S : 8;
	};
} FORMAT_186;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t EXTIN0IAS : 1;
		uint32_t EXTIN1IAS : 1;
		uint32_t EXTIN2IAS : 1;
		uint32_t EXTIN3IAS : 1;
		uint32_t EXTIN4IAS : 1;
		uint32_t EXTIN5IAS : 1;
		uint32_t EXTIN6IAS : 1;
		uint32_t EXTIN7IAS : 1;
		uint32_t EXTOUT0OAS : 1;
		uint32_t EXTOUT1OAS : 1;
		uint32_t EXTOUT2OAS : 1;
		uint32_t EXTOUT3OAS : 1;
		uint32_t EXTOUT4OAS : 1;
		uint32_t EXTOUT5OAS : 1;
		uint32_t EXTOUT6OAS : 1;
		uint32_t EXTOUT7OAS : 1;
		uint32_t EXTOUT0DC : 1;
		uint32_t EXTOUT1DC : 1;
		uint32_t EXTOUT2DC : 1;
		uint32_t EXTOUT3DC : 1;
		uint32_t EXTOUT4DC : 1;
		uint32_t EXTOUT5DC : 1;
		uint32_t EXTOUT6DC : 1;
		uint32_t EXTOUT7DC : 1;
		uint32_t EXTOUT0AC : 1;
		uint32_t EXTOUT1AC : 1;
		uint32_t EXTOUT2AC : 1;
		uint32_t EXTOUT3AC : 1;
		uint32_t EXTOUT4AC : 1;
		uint32_t EXTOUT5AC : 1;
		uint32_t EXTOUT6AC : 1;
		uint32_t EXTOUT7AC : 1;
	};
} FORMAT_187;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* cr_chik_bits[30:0] */
		uint32_t TBD : 31;
		/* 0: Only a change in D-state value will cause the associated completion to be tagged for service before
establishing superlock[br]
1: Allows any D-state register write to cause the associated completion to be tagged for service before establishing
superlock
cr_chik_bits[31] */
		uint32_t DCCG : 1;
	};
} FORMAT_188;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* cr_chik1_bits[0] */
		uint32_t TBD0 : 1;
		/* cr_chik1_bits[1] */
		uint32_t TBD1 : 1;
		/* cr_chik1_bits[2] */
		uint32_t TBD2 : 1;
		/* cr_chik1_bits[3] */
		uint32_t TBD3 : 1;
		/* cr_chik1_bits[4] */
		uint32_t TBD4 : 1;
		/* cr_chik1_bits[5] */
		uint32_t TBD5 : 1;
		/* cr_chik1_bits[6] */
		uint32_t TBD6 : 1;
		/* cr_chik1_bits[7] */
		uint32_t TBD7 : 1;
		/* cr_chik1_bits[8] */
		uint32_t TBD8 : 1;
		/* cr_chik1_bits[9] */
		uint32_t BEXTINSVM0 : 1;
		/* cr_chik1_bits[10] */
		uint32_t BEXTINSVM1 : 1;
		/* cr_chik1_bits[11] */
		uint32_t BEXTINSVM2 : 1;
		/* cr_chik1_bits[12] */
		uint32_t BEXTINSVM3 : 1;
		uint32_t RESV13 : 1;
		uint32_t RESV14 : 1;
		/* cr_chik1_bits[15] */
		uint32_t DTLPC4GB : 1;
		/* 0: count in non-D0 states[br]1: allows counter to work in D0 L2Ready scenario[br]cr_chik1_bits[16] */
		uint32_t REDT : 1;
		/* When LTR is enabled, if the LTR Message advertises No Requirement, still check requests complete in the Max
		 * Latency Register value time period.[br]cr_chik1_bits[17] */
		uint32_t EMLR : 1;
		/*  cr_chik1_bits[18] */
		uint32_t ILRIDC : 1;
		/* cr_chik1_bits[19] */
		uint32_t TBD19 : 1;
		/*  When operating in Mode 0 and Outstanding Non-Posted queue is full and not enough Non-Posted credits are
available for next packet[br]0: act like Mode 1 - move to other VM[br]
1: act like Mode 0 - stall at this VM[br]cr_chik1_bits[20] */
		uint32_t AMCC : 1;
		/* cr_chik1_bits[21] */
		uint32_t TCLA : 1;
		/* cr_chik1_bits[22] */
		uint32_t TCBC : 1;
		/* cr_chik1_bits[23] */
		uint32_t TBD23 : 1;
		/* Remove contribution of 'p0_tx_ehp_deallocate_empty_o' signal from RNR IP in the delayed mirror PMCSR write
  count[br]
  cr_chik1_bits[24] */
		uint32_t TBD24 : 1;
		/* When Clear, Reads to RNR cxl.io.up (first 4kB) and cxl.io.up private (last 4kB) return zeros[br]
  When Set, Reads are serviced normally[br]
  Writes are always Dropped[br]
  cr_chik1_bits[25] */
		uint32_t TBD25 : 1;
		/* When Set, in addition to causing app_xfer_pending toggle, also send PM_PME sideband message (just like
		 * L23_Exit does)[br]cr_chik1_bits[26] */
		uint32_t TBD26 : 1;
		/* cr_chik1_bits[27] */
		uint32_t TBD27 : 1;
		/* cr_chik1_bits[28] */
		uint32_t TBD28 : 1;
		/* cr_chik1_bits[29] */
		uint32_t TBD29 : 1;
		/* cr_chik1_bits[30] */
		uint32_t TBD30 : 1;
		/* cr_chik1_bits[31] */
		uint32_t TBD31 : 1;
	};
} FORMAT_189;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t VMIDI : 2;
		uint32_t RESV2 : 1;
		/* 00 - Stream 0 in VM[br]
01 - Stream 1 in VM[br]
10 - Stream 2 in VM[br]
11 - Stream 3 in VM */
		uint32_t EIDVM : 2;
		uint32_t VBVM : 1;
		uint32_t RESV6 : 2;
		/*  If enabled, when the number of ITAG entries stored in the accumulator is >= this value, the Event Trigger
programmed in byte 0 will fire.[br]00000 = 32[br]
00001 = 1[br]
...[br]
11111 = 31 */
		uint32_t AITAGT : 5;
		uint32_t RESV13 : 14;
		uint32_t CSITAGA : 1;
		/*  Indicates the Count Threshold caused the Event Trigger */
		uint32_t ATT : 1;
		/*  Indicates the Timer caused the Event Trigger. */
		uint32_t ITT : 1;
		uint32_t EA : 1;
		uint32_t EICT : 1;
	};
} FORMAT_190;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  When the number of ITag entries accumulated is non-zero, this counter will begin and if it reaches zero, the
		 * programmed event trigger in byte 0 will fire. Counter will freeze if the Accumulated Threshold is reached
		 * first and will reset upon next Enable. */
		uint32_t ICT : 16;
		/* 00 - 16 ns per tick[br]
01 - 1 us per tick[br]
10 - 1 ms per tick[br]
11 - Reserved */
		uint32_t GIC : 2;
		uint32_t RESV18 : 6;
		/* Running count of the number of ATS Invalidate Request Messages received. Counter may rollover. */
		uint32_t IRMC : 8;
	};
} FORMAT_191;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Accumulates incoming ITag values and upon Timer or Threshold trigger, will shift this value to the Vector
		 * Machines for use, and this register will reset. */
		uint32_t AITAG : 32;
	};
} FORMAT_192;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* The PASID Value that is inserted into the TLP Prefix. Safe to change this value when PASIDQ is set */
		uint32_t PASIDVAL : 20;
		uint32_t RESV20 : 4;
		/* Begin the process to stop using the programmed PASID Value. Any executed vectors with PASID TLP prefix will
		 * drop the prefix. */
		uint32_t PASIDSTOP : 1;
		uint32_t RESV25 : 6;
		/* All requests using the programmed PASID Value have completed. It is safe to change the PASID value */
		uint32_t PASIDQ : 1;
	};
} FORMAT_193;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t ADO : 32;
	};
} FORMAT_194;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t ADC : 32;
	};
} FORMAT_198;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* For PM Software Use */
		uint32_t FSU : 32;
	};
} FORMAT_258;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Sends the programmed FLIT to the IOSF-SB */
		uint32_t SR : 1;
		uint32_t RESV1 : 15;
		/* Non-Posted request received completion or the posted cycle was accepted */
		uint32_t RC : 1;
		/* Request did not complete in 1 ms */
		uint32_t RT : 1;
		uint32_t RDV : 1;
		uint32_t RESV19 : 1;
		/* 00b Success[br]
01b Unsuccessful / Not Supported */
		uint32_t CR : 2;
		uint32_t RESV22 : 10;
	};
} FORMAT_260;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* valid if the Read Data Valid field of IOSF-SB Master Control register is set */
		uint32_t CPLDATA : 32;
	};
} FORMAT_261;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Address Length:[br]
Always set to 1 for 48-bit addressing[br]
Tag field:[br]
must not change from the default to route completion correctly[br]
Supported Request Opcodes:[br]
00h MRd[br]
01h MWr[br]
5Bh NPWr[br]
Source ID:[br]
must be set to this cores assigned PortID unless performing a Broadcast[br]
Destination ID:[br]
see Cambria-W spec for valid PortIDs */
		uint32_t FLITDW0 : 32;
	};
} FORMAT_262;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Last Byte Enable:[br]Since we are only supporting 1 DW payloads, the last byte enable must be set inactive */
		uint32_t FLITDW1 : 32;
	};
} FORMAT_263;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t FLITDW2 : 32;
	};
} FORMAT_264;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t FLITDW3 : 32;
	};
} FORMAT_265;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		uint32_t RESV0 : 24;
		/* 0: When OBFF is enabled, immediately go to CPU_ACTIVE state[br]
1: When OBFF is enabled, start in IDLE state */
		uint32_t OBFFEA : 1;
		/* 0: While OBFF is enabled, immediately go to CPU_ACTIVE state when a host-initiated request is received.[br]
1: Ignore host-initiated request received contribution to OBFF state machine */
		uint32_t OBFFHRR : 1;
		/* Prevents a VM being unable to complete its vectors due to being in a non-enabled state at the end of a test.
		 */
		uint32_t OBFFWTE : 1;
		/* VMs executing in this mode will be covered by OBFF Watchdog Timer if enabled. */
		uint32_t NMVMW : 1;
		/* VMs executing in this mode will be covered by OBFF Watchdog Timer if enabled. */
		uint32_t EMVMW : 1;
		/* VMs executing in this mode will be covered by OBFF Watchdog Timer if enabled. */
		uint32_t IMVMW : 1;
		uint32_t RESV30 : 2;
	};
} FORMAT_266;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 10 ns per tick */
		uint32_t MWAKEAIT : 8;
		/* 8 ns per tick */
		uint32_t MWAKEIAT : 8;
		/* Minumum + Maximum Offset = Maximum[br]
8 ns per tick */
		uint32_t MOWAKEAI : 8;
		/* Minumum + Maximum Offset = Maximum[br]
8 ns per tick */
		uint32_t MOWAKEIA : 8;
	};
} FORMAT_267;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 8 ns per tick */
		uint32_t MWAKEFFT1 : 8;
		/* 8 ns per tick */
		uint32_t MWAKEFFT : 8;
		/* When OBFF Watchdog Timeout Enable is set, timer counts when anystarted VM has not set its end bit. Timer
resets and restarts on any OBFF state transitions. When the timer expires, OBFF Watchdog Timeout Expired field is set
and all VMs will enable all traffic for all OBFF states.[br]
2^25 ns (~32 ms) per tick */
		uint32_t OBFFWTV : 5;
		uint32_t RESV21 : 11;
	};
} FORMAT_268;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/*  Once in sync with the platforms OBFF state, device needs to remain in a state this amount of time before
transitioning to a different state. Upon detection of an early state change transition attempt, Minimum State Residency
Violation will be set and the state machine will transition to CPU_ACTIVE[br]
8ns per tick */
		uint32_t MSR : 8;
		/*  This is the amount of time from when a signal change is detected to ignore any glitches before  continuing
		 * evaluation of the signal.8ns per tick */
		uint32_t WAKEGF : 8;
		/*  Requests which match this Requester ID will be considered as 'host-initiated' for purposes of directing the
		 * OBFF tracking machine to CPU_ACTIVE state if OBFF Request Received Action is clear. */
		uint32_t OBFFHRID : 16;
	};
} FORMAT_269;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* 00: DISABLED[br]
01: IDLE[br]
10: OBFF[br]
11: CPU_ACTIVE */
		uint32_t COBFFTS : 2;
		uint32_t RESV2 : 5;
		uint32_t DHRW : 1;
		/* When the OBFF Watchdog Timer expires, this status bit is set and all VMs will enable all traffic for all OBFF
		 * states. */
		uint32_t OBFFWTE : 1;
		/* Upon violation, state machine transitions to CPU_ACTIVE */
		uint32_t MWAKEAIV665 : 1;
		/* Upon violation, state machine transitions to CPU_ACTIVE */
		uint32_t MWAKEIAV664 : 1;
		/* Upon violation, state machine transitions to CPU_ACTIVE */
		uint32_t MWAKEAIV : 1;
		/* Upon violation, state machine transitions to CPU_ACTIVE */
		uint32_t MWAKEIAV : 1;
		/* Upon violation, state machine transitions to CPU_ACTIVE */
		uint32_t MWAKEFFV1 : 1;
		/* Upon violation, state machine transitions to CPU_ACTIVE */
		uint32_t MWAKEFFV : 1;
		/* Upon violation, state machine transitions to CPU_ACTIVE */
		uint32_t MSRV : 1;
		/* Counter does not rollover. */
		uint32_t NIDLE1 : 8;
		/* Counter does not rollover. */
		uint32_t NIDLE : 8;
	};
} FORMAT_270;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Counter does not rollover. */
		uint32_t NCPUACTIVE1 : 8;
		/* Counter does not rollover. */
		uint32_t NCPUACTIVE : 8;
		/* Counter does not rollover. */
		uint32_t NOBFF1 : 8;
		/* Counter does not rollover. */
		uint32_t NOBFF : 8;
	};
} FORMAT_271;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Value returned in an IOSF-SB Read Completion triggered by the register mirroring */
		uint32_t MIRRORSTG : 32;
	};
} FORMAT_272;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Reserved  */
		uint32_t Reserved : 32;
	};
} FORMAT_274;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Number of Header Entries to store before bursting packets[br]0 - Disables the bursting[br]
  ...[br]
  3FFh - 1023 entries */
		uint32_t WATERMARK : 11;
		/* Reserved  */
		uint32_t Reserved : 21;
	};
} FORMAT_275;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Amount of Time to wait if Header Buffer Watermark is not reached before bursting enqueued packets[br]
  0 - 20ns[br]
  ...[br]
  F_FFFFh - 20ms */
		uint32_t DRAINDELAY : 20;
		/* Reserved  */
		uint32_t Reserved : 12;
	};
} FORMAT_276;

typedef union __attribute__((packed)) {
	uint64_t val;
	struct {
		/* Value must be greater than 8 */
		uint32_t PHSIZE : 8;
		/* Value must be greater than 8 */
		uint32_t NPHSIZE : 8;
		/* Value must be greater than 8 */
		uint32_t CPLHSIZE : 8;
		uint32_t : 8;
	};
} FORMAT_277;
} // namespace cambria_rnr_global_cfgFmt

namespace cambria_rnr_global_cfg
{
struct STRAPSTSREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_0 format;
	static constexpr uint64_t mmio_offset() { return 0x20; }
	static constexpr uint64_t size() { return 32; }
};
struct DEVCFGCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_1 format;
	static constexpr uint64_t mmio_offset() { return 0x28; }
	static constexpr uint64_t size() { return 32; }
};
struct NUMREQSREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_2 format;
	static constexpr uint64_t mmio_offset() { return 0x2c; }
	static constexpr uint64_t size() { return 32; }
};
struct VMGLBSRD {
	typedef cambria_rnr_global_cfgFmt::FORMAT_3 format;
	static constexpr uint64_t mmio_offset() { return 0x30; }
	static constexpr uint64_t size() { return 32; }
};
struct MEMSCRATCH0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_4 format;
	static constexpr uint64_t mmio_offset() { return 0x40; }
	static constexpr uint64_t size() { return 32; }
};
struct MEMSCRATCH1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_4 format;
	static constexpr uint64_t mmio_offset() { return 0x44; }
	static constexpr uint64_t size() { return 32; }
};
struct MEMSCRATCH2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_4 format;
	static constexpr uint64_t mmio_offset() { return 0x48; }
	static constexpr uint64_t size() { return 32; }
};
struct MEMSCRATCH3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_4 format;
	static constexpr uint64_t mmio_offset() { return 0x4c; }
	static constexpr uint64_t size() { return 32; }
};
struct BRDSTRAPSTS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_8 format;
	static constexpr uint64_t mmio_offset() { return 0x50; }
	static constexpr uint64_t size() { return 32; }
};
struct CBGM {
	typedef cambria_rnr_global_cfgFmt::FORMAT_9 format;
	static constexpr uint64_t mmio_offset() { return 0x54; }
	static constexpr uint64_t size() { return 32; }
};
struct PREFETCHCTRL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_10 format;
	static constexpr uint64_t mmio_offset() { return 0x60; }
	static constexpr uint64_t size() { return 32; }
};
struct SAIREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_11 format;
	static constexpr uint64_t mmio_offset() { return 0x70; }
	static constexpr uint64_t size() { return 32; }
};
/* The 2 bit internal counter is conceptual and is used to explain the functional behavior only.[br]
Every time all INTx status bits are cleared [lb]transition from non-zero to zero[rb] a 2 bit internal counter is
incremented. When the internal 2 bit counter is:[br]
00 :  Deassert_INTx is sent as many times as specified by Bits[lb]1:0[rb] - COUNT0[br]
01 :  Deassert_INTx is sent as many times as specified by Bits[lb]3:2[rb] - COUNT1[br]
10 :  Deassert_INTx is sent as many times as specified by Bits[lb]5:4[rb] - COUNT2[br]
11 :  Deassert_INTx is sent as many times as specified by Bits[lb]7:6[rb] - COUNT3 */
struct INTDMS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_12 format;
	static constexpr uint64_t mmio_offset() { return 0xb4; }
	static constexpr uint64_t size() { return 32; }
};
/* Every time a Type 0 Configuration Write request is received that target the Extended Scratchpad Registers, a 2-bit
internal counter is incremented.[br]
when the internal 2 bit counter is[br]
00 : The completion status for the Config Write will be as specified in bits[lb]19:16[rb] - CSCW0[br]
01 : The completion status for the Config Write will be as specified in bits[lb]23:20[rb] - CSCW1[br]
10 : The completion status for the Config Write will be as specified in bits[lb]27:24[rb] - CSCW2[br]
11 : The completion status for the Config Write will be as specified in bits[lb]31:28[rb] - CSCW3[br][br]
Every time a Type 0 Configuration Read request is received that target the Extended Scratchpad Registers, a 2-bit
internal counter is incremented.[br]
when the internal 2 bit counter is[br]
00 : The completion status for the Config Read will be as specified in bits[lb]3:0[rb] - CSCR0[br]
01 : The completion status for the Config Read will be as specified in bits[lb]7:4[rb] - CSCR1[br]
10 : The completion status for the Config Read will be as specified in bits[lb]11:8[rb] - CSCR2[br]
11 : The completion status for the Config Read will be as specified in bits[lb]15:12[rb] - CSCR3 */
struct CFGRETRYSTS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_13 format;
	static constexpr uint64_t mmio_offset() { return 0xbc; }
	static constexpr uint64_t size() { return 32; }
};
/* For a Message Compare 'HIT':[br]
Message Code Enable is '1' AND the received TLP's message code = programmed message code OR[br]
Vendor Specific Code Enable is '1' AND the received TLP's vendor specific byte matches the programmed value in these
registers.[br]
If multiple message codes are triggering a single VM/stream, device will en-queue one event command per HIT and they
will be serviced in the order they are received.[br]
If Multiple Streams are triggered for a single message code, the response is indeterminate. If the event command queue
is full, the command is dropped. */
struct MSGETRIGREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_14 format;
	static constexpr uint64_t mmio_offset() { return 0x100; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGETRIGREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_15 format;
	static constexpr uint64_t mmio_offset() { return 0x104; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGETRIGREG2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_16 format;
	static constexpr uint64_t mmio_offset() { return 0x108; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGETRIGREG3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_17 format;
	static constexpr uint64_t mmio_offset() { return 0x10c; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGETRIGREG4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_18 format;
	static constexpr uint64_t mmio_offset() { return 0x110; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGETRIGREG5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_19 format;
	static constexpr uint64_t mmio_offset() { return 0x114; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGETRIGREG6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_20 format;
	static constexpr uint64_t mmio_offset() { return 0x118; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGETRIGREG7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_21 format;
	static constexpr uint64_t mmio_offset() { return 0x11c; }
	static constexpr uint64_t size() { return 32; }
};
/* Device will request four MSIs. If fewer that four messages are allocated, SW must program the MSI DATA fields
appropriately.[br]
Register based MSI interrupts will use the interrupt pin programmed in the Interrupt Pin register */
struct INTRCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_22 format;
	static constexpr uint64_t mmio_offset() { return 0x150; }
	static constexpr uint64_t size() { return 32; }
};
/* For vector based interrupts only. */
struct INTAINTID {
	typedef cambria_rnr_global_cfgFmt::FORMAT_23 format;
	static constexpr uint64_t mmio_offset() { return 0x154; }
	static constexpr uint64_t size() { return 32; }
};
/* For vector based interrupts only. */
struct INTBINTID {
	typedef cambria_rnr_global_cfgFmt::FORMAT_23 format;
	static constexpr uint64_t mmio_offset() { return 0x158; }
	static constexpr uint64_t size() { return 32; }
};
/* For vector based interrupts only. */
struct INTCINTID {
	typedef cambria_rnr_global_cfgFmt::FORMAT_23 format;
	static constexpr uint64_t mmio_offset() { return 0x15c; }
	static constexpr uint64_t size() { return 32; }
};
/* For vector based interrupts only. */
struct INTDINTID {
	typedef cambria_rnr_global_cfgFmt::FORMAT_23 format;
	static constexpr uint64_t mmio_offset() { return 0x160; }
	static constexpr uint64_t size() { return 32; }
};
struct INTACNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_27 format;
	static constexpr uint64_t mmio_offset() { return 0x164; }
	static constexpr uint64_t size() { return 16; }
};
struct INTBCNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_28 format;
	static constexpr uint64_t mmio_offset() { return 0x166; }
	static constexpr uint64_t size() { return 16; }
};
struct INTCCNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_29 format;
	static constexpr uint64_t mmio_offset() { return 0x168; }
	static constexpr uint64_t size() { return 16; }
};
struct INTDCNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_30 format;
	static constexpr uint64_t mmio_offset() { return 0x16a; }
	static constexpr uint64_t size() { return 16; }
};
struct INTCNTREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_31 format;
	static constexpr uint64_t mmio_offset() { return 0x170; }
	static constexpr uint64_t size() { return 32; }
};
struct INTIDCLRREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_32 format;
	static constexpr uint64_t mmio_offset() { return 0x174; }
	static constexpr uint64_t size() { return 32; }
};
struct SPOLLMSGCODE {
	typedef cambria_rnr_global_cfgFmt::FORMAT_33 format;
	static constexpr uint64_t mmio_offset() { return 0x178; }
	static constexpr uint64_t size() { return 32; }
};
struct SPOLLVNDCODE {
	typedef cambria_rnr_global_cfgFmt::FORMAT_34 format;
	static constexpr uint64_t mmio_offset() { return 0x17c; }
	static constexpr uint64_t size() { return 32; }
};
struct VNDMSGCODE0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_35 format;
	static constexpr uint64_t mmio_offset() { return 0x180; }
	static constexpr uint64_t size() { return 32; }
};
struct VNDMSGCODE1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_36 format;
	static constexpr uint64_t mmio_offset() { return 0x184; }
	static constexpr uint64_t size() { return 32; }
};
struct VNDMSGCODE2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_37 format;
	static constexpr uint64_t mmio_offset() { return 0x188; }
	static constexpr uint64_t size() { return 32; }
};
struct VNDMSGCODE3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_38 format;
	static constexpr uint64_t mmio_offset() { return 0x18c; }
	static constexpr uint64_t size() { return 32; }
};
/* Every time a non posted request is received that targets CFG/ARAM/EV resources,  a 2-bit internal counter is
incremented. When the internal 2-bit counter is[br]
00 : The completion to the request is delayed by the number of ticks specified by bits[15:0] - Count 0[br]
01 : The completion to the request is delayed by the number of ticks specified by bits[31:16] - Count 1 */
struct TGPDLYREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_39 format;
	static constexpr uint64_t mmio_offset() { return 0x1b0; }
	static constexpr uint64_t size() { return 32; }
};
/* Every time a non posted request is received that targets CFG/ARAM/EV resources,  a 2-bit internal counter is
incremented. When the internal 2-bit counter is[br]
10 : The completion to the request is delayed by the number of ticks specified by bits[15:0] - Count 2[br]
11 : The completion to the request is delayed by the number of ticks specified by bits[31:16] - Count 3 */
struct TGPDLYREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_39 format;
	static constexpr uint64_t mmio_offset() { return 0x1b4; }
	static constexpr uint64_t size() { return 32; }
};
/* This register controls error injection on Completions for requests targeting the Extended Scratchpad Registers. */
struct TGPCFGERRINJ {
	typedef cambria_rnr_global_cfgFmt::FORMAT_41 format;
	static constexpr uint64_t mmio_offset() { return 0x1b8; }
	static constexpr uint64_t size() { return 32; }
};
struct SPCTLSTS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_42 format;
	static constexpr uint64_t mmio_offset() { return 0x1bc; }
	static constexpr uint64_t size() { return 32; }
};
/* The following register is a combination of all VMs statuses. So a vector paused for external input in any VM will set
 * one of the bits 31:16. The external input continue counters are tracked seperately per each VM but are displayed here
 * if any VM has a non-zero value. */
struct EXTINPSE {
	typedef cambria_rnr_global_cfgFmt::FORMAT_43 format;
	static constexpr uint64_t mmio_offset() { return 0x1c0; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIETRIGD0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_44 format;
	static constexpr uint64_t mmio_offset() { return 0x1c4; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIETRIGD1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_45 format;
	static constexpr uint64_t mmio_offset() { return 0x1c8; }
	static constexpr uint64_t size() { return 32; }
};
/* A 'HIT' means[br]
Received cycle is a write request (32/64b) AND[br]
The data received must match the corresponding data specified in the data registers AND[br]
The lower two byte enables must be active[br]
If multiple message codes are triggering a single VM/stream, device will en-queue one EVENT command per 'HIT' and they
will be serviced in the order they are received.[br]
If Multiple Streams are triggered for a single message code, the response is indeterminate. If the event command queue
is full, the command is dropped. */
struct MSIETRIG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_46 format;
	static constexpr uint64_t mmio_offset() { return 0x1cc; }
	static constexpr uint64_t size() { return 32; }
};
/* If this address falls within the range specified in any address remap registers, the request will generate the event
trigger only meaning [br]
If the address falls within the Memory BAR0 range, it will NOT update the ARAM, register or EV buffer locations.[br]
If the address falls within the target range addresses, it will not modify the target byte counters and the data will
NOT be compared.[br] */
struct MSIETLA0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_47 format;
	static constexpr uint64_t mmio_offset() { return 0x1d0; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIETHA0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_48 format;
	static constexpr uint64_t mmio_offset() { return 0x1d4; }
	static constexpr uint64_t size() { return 32; }
};
/* If this address falls within the range specified in any address remap registers, the request will generate the event
trigger only meaning [br]
If the address falls within the Memory BAR0 range, it will NOT update the ARAM, register or EV buffer locations.[br]
If the address falls within the target range addresses, it will not modify the target byte counters and the data will
NOT be compared.[br] */
struct MSIETLA1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_47 format;
	static constexpr uint64_t mmio_offset() { return 0x1d8; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIETHA1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_50 format;
	static constexpr uint64_t mmio_offset() { return 0x1dc; }
	static constexpr uint64_t size() { return 32; }
};
/* If this address falls within the range specified in any address remap registers, the request will generate the event
trigger only meaning [br]
If the address falls within the Memory BAR0 range, it will NOT update the ARAM, register or EV buffer locations.[br]
If the address falls within the target range addresses, it will not modify the target byte counters and the data will
NOT be compared.[br] */
struct MSIETLA2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_47 format;
	static constexpr uint64_t mmio_offset() { return 0x1e0; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIETHA2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_48 format;
	static constexpr uint64_t mmio_offset() { return 0x1e4; }
	static constexpr uint64_t size() { return 32; }
};
/* If this address falls within the range specified in any address remap registers, the request will generate the event
trigger only meaning [br]
If the address falls within the Memory BAR0 range, it will NOT update the ARAM, register or EV buffer locations.[br]
If the address falls within the target range addresses, it will not modify the target byte counters and the data will
NOT be compared.[br] */
struct MSIETLA3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_47 format;
	static constexpr uint64_t mmio_offset() { return 0x1e8; }
	static constexpr uint64_t size() { return 32; }
};
struct MSIETHA3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_50 format;
	static constexpr uint64_t mmio_offset() { return 0x1ec; }
	static constexpr uint64_t size() { return 32; }
};
struct MSTRCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_55 format;
	static constexpr uint64_t mmio_offset() { return 0x200; }
	static constexpr uint64_t size() { return 32; }
};
struct QTACTRL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_56 format;
	static constexpr uint64_t mmio_offset() { return 0x204; }
	static constexpr uint64_t size() { return 32; }
};
struct LNKSTSREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_57 format;
	static constexpr uint64_t mmio_offset() { return 0x208; }
	static constexpr uint64_t size() { return 32; }
};
struct CPLTOREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_58 format;
	static constexpr uint64_t mmio_offset() { return 0x210; }
	static constexpr uint64_t size() { return 32; }
};
struct CMPLTOINFO {
	typedef cambria_rnr_global_cfgFmt::FORMAT_59 format;
	static constexpr uint64_t mmio_offset() { return 0x214; }
	static constexpr uint64_t size() { return 32; }
};
struct CMPLTOADDR0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_60 format;
	static constexpr uint64_t mmio_offset() { return 0x218; }
	static constexpr uint64_t size() { return 32; }
};
struct CMPLTOADDR1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_61 format;
	static constexpr uint64_t mmio_offset() { return 0x21c; }
	static constexpr uint64_t size() { return 32; }
};
struct SQENTRYSTS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_62 format;
	static constexpr uint64_t mmio_offset() { return 0x220; }
	static constexpr uint64_t size() { return 32; }
};
struct ERRCNTREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_63 format;
	static constexpr uint64_t mmio_offset() { return 0x230; }
	static constexpr uint64_t size() { return 32; }
};
struct ERRCNTREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_64 format;
	static constexpr uint64_t mmio_offset() { return 0x234; }
	static constexpr uint64_t size() { return 32; }
};
struct ERRCNTREG2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_65 format;
	static constexpr uint64_t mmio_offset() { return 0x238; }
	static constexpr uint64_t size() { return 32; }
};
struct ERRCNTREG3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_66 format;
	static constexpr uint64_t mmio_offset() { return 0x23c; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTTLSTSREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_67 format;
	static constexpr uint64_t mmio_offset() { return 0x240; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTTLSTSREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_68 format;
	static constexpr uint64_t mmio_offset() { return 0x244; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTTLMSKREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_69 format;
	static constexpr uint64_t mmio_offset() { return 0x248; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTTLMSKREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_70 format;
	static constexpr uint64_t mmio_offset() { return 0x24c; }
	static constexpr uint64_t size() { return 32; }
};
struct LTRVALUEREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_71 format;
	static constexpr uint64_t mmio_offset() { return 0x300; }
	static constexpr uint64_t size() { return 32; }
};
struct LTRCTLREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_72 format;
	static constexpr uint64_t mmio_offset() { return 0x304; }
	static constexpr uint64_t size() { return 32; }
};
struct LTRERRCNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_73 format;
	static constexpr uint64_t mmio_offset() { return 0x308; }
	static constexpr uint64_t size() { return 32; }
};
struct LTRMAXNPO {
	typedef cambria_rnr_global_cfgFmt::FORMAT_74 format;
	static constexpr uint64_t mmio_offset() { return 0x30c; }
	static constexpr uint64_t size() { return 32; }
};
struct LTRMAXPO {
	typedef cambria_rnr_global_cfgFmt::FORMAT_75 format;
	static constexpr uint64_t mmio_offset() { return 0x310; }
	static constexpr uint64_t size() { return 32; }
};
struct CRSCTRLREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_76 format;
	static constexpr uint64_t mmio_offset() { return 0x320; }
	static constexpr uint64_t size() { return 32; }
};
struct FLRCTLREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_77 format;
	static constexpr uint64_t mmio_offset() { return 0x324; }
	static constexpr uint64_t size() { return 32; }
};
/* NOTE: this register does not function with the FPGA Controller */
struct LNKWCHGREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_78 format;
	static constexpr uint64_t mmio_offset() { return 0x328; }
	static constexpr uint64_t size() { return 32; }
};
/* NOTE: this register does not function with the FPGA Controller */
struct LNKWCHGREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_79 format;
	static constexpr uint64_t mmio_offset() { return 0x32c; }
	static constexpr uint64_t size() { return 32; }
};
/* NOTE: this register does not function with the FPGA Controller */
struct LNKWCHGTRGREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_80 format;
	static constexpr uint64_t mmio_offset() { return 0x330; }
	static constexpr uint64_t size() { return 32; }
};
/* NOTE: this register does not function with the FPGA Controller */
struct LNKWCHGTRGREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_81 format;
	static constexpr uint64_t mmio_offset() { return 0x334; }
	static constexpr uint64_t size() { return 32; }
};
struct GLBROISEED {
	typedef cambria_rnr_global_cfgFmt::FORMAT_82 format;
	static constexpr uint64_t mmio_offset() { return 0x400; }
	static constexpr uint64_t size() { return 32; }
};
struct GLBROLSEED {
	typedef cambria_rnr_global_cfgFmt::FORMAT_83 format;
	static constexpr uint64_t mmio_offset() { return 0x404; }
	static constexpr uint64_t size() { return 32; }
};
struct MCROISEED {
	typedef cambria_rnr_global_cfgFmt::FORMAT_84 format;
	static constexpr uint64_t mmio_offset() { return 0x408; }
	static constexpr uint64_t size() { return 32; }
};
struct MCROLSEED {
	typedef cambria_rnr_global_cfgFmt::FORMAT_85 format;
	static constexpr uint64_t mmio_offset() { return 0x40c; }
	static constexpr uint64_t size() { return 32; }
};
struct MCERRCTRLREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_86 format;
	static constexpr uint64_t mmio_offset() { return 0x410; }
	static constexpr uint64_t size() { return 32; }
};
struct MCERRADDR {
	typedef cambria_rnr_global_cfgFmt::FORMAT_87 format;
	static constexpr uint64_t mmio_offset() { return 0x414; }
	static constexpr uint64_t size() { return 32; }
};
struct MCERRUPADDR {
	typedef cambria_rnr_global_cfgFmt::FORMAT_88 format;
	static constexpr uint64_t mmio_offset() { return 0x418; }
	static constexpr uint64_t size() { return 32; }
};
struct MCERRACTDATA {
	typedef cambria_rnr_global_cfgFmt::FORMAT_89 format;
	static constexpr uint64_t mmio_offset() { return 0x41c; }
	static constexpr uint64_t size() { return 32; }
};
struct MCERREXPDATA {
	typedef cambria_rnr_global_cfgFmt::FORMAT_90 format;
	static constexpr uint64_t mmio_offset() { return 0x420; }
	static constexpr uint64_t size() { return 32; }
};
struct MCBYTECNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_91 format;
	static constexpr uint64_t mmio_offset() { return 0x424; }
	static constexpr uint64_t size() { return 32; }
};
struct PMMETRICSREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_92 format;
	static constexpr uint64_t mmio_offset() { return 0x440; }
	static constexpr uint64_t size() { return 32; }
};
struct PMMETRICSREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_93 format;
	static constexpr uint64_t mmio_offset() { return 0x444; }
	static constexpr uint64_t size() { return 32; }
};
struct PMPSECTRL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_94 format;
	static constexpr uint64_t mmio_offset() { return 0x448; }
	static constexpr uint64_t size() { return 32; }
};
struct WAKECTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_95 format;
	static constexpr uint64_t mmio_offset() { return 0x44c; }
	static constexpr uint64_t size() { return 32; }
};
struct PMCTRL0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_96 format;
	static constexpr uint64_t mmio_offset() { return 0x450; }
	static constexpr uint64_t size() { return 32; }
};
struct PMCTRL1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_97 format;
	static constexpr uint64_t mmio_offset() { return 0x454; }
	static constexpr uint64_t size() { return 32; }
};
struct PMCTRL2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_98 format;
	static constexpr uint64_t mmio_offset() { return 0x458; }
	static constexpr uint64_t size() { return 32; }
};
struct PMCTRL3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_99 format;
	static constexpr uint64_t mmio_offset() { return 0x45c; }
	static constexpr uint64_t size() { return 32; }
};
struct PMCTRL4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_100 format;
	static constexpr uint64_t mmio_offset() { return 0x460; }
	static constexpr uint64_t size() { return 32; }
};
/* Register is used in conjuction with the Internal Access vector Start Retrigger Timer bits */
struct RETRIGEVENT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_101 format;
	static constexpr uint64_t mmio_offset() { return 0x464; }
	static constexpr uint64_t size() { return 32; }
};
struct L1LATENCY {
	typedef cambria_rnr_global_cfgFmt::FORMAT_102 format;
	static constexpr uint64_t mmio_offset() { return 0x468; }
	static constexpr uint64_t size() { return 32; }
};
struct PMPSECTRL2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_103 format;
	static constexpr uint64_t mmio_offset() { return 0x470; }
	static constexpr uint64_t size() { return 32; }
};
/* Message must be a hit to a corresponding enabled Message/Vender Code comparator for these bits to take effect. */
struct MSGDATACMPCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_104 format;
	static constexpr uint64_t mmio_offset() { return 0x480; }
	static constexpr uint64_t size() { return 32; }
};
/* Message must be a hit to a corresponding enabled Message/Vender Code comparator for these bits to take effect. */
struct MSGDATACMPCNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_105 format;
	static constexpr uint64_t mmio_offset() { return 0x484; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAEXP0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_106 format;
	static constexpr uint64_t mmio_offset() { return 0x488; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAEXP1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_107 format;
	static constexpr uint64_t mmio_offset() { return 0x48c; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAEXP2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_108 format;
	static constexpr uint64_t mmio_offset() { return 0x490; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAEXP3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_109 format;
	static constexpr uint64_t mmio_offset() { return 0x494; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAMSK0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_110 format;
	static constexpr uint64_t mmio_offset() { return 0x498; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAMSK1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_111 format;
	static constexpr uint64_t mmio_offset() { return 0x49c; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAMSK2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_112 format;
	static constexpr uint64_t mmio_offset() { return 0x4a0; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAMSK3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_113 format;
	static constexpr uint64_t mmio_offset() { return 0x4a4; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAERR0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_114 format;
	static constexpr uint64_t mmio_offset() { return 0x4a8; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAERR1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_115 format;
	static constexpr uint64_t mmio_offset() { return 0x4ac; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAERR2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_116 format;
	static constexpr uint64_t mmio_offset() { return 0x4b0; }
	static constexpr uint64_t size() { return 32; }
};
struct MSGDATAERR3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_117 format;
	static constexpr uint64_t mmio_offset() { return 0x4b4; }
	static constexpr uint64_t size() { return 32; }
};
struct GENCNTCTRL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_118 format;
	static constexpr uint64_t mmio_offset() { return 0x4b8; }
	static constexpr uint64_t size() { return 32; }
};
struct GENCNTREG0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_119 format;
	static constexpr uint64_t mmio_offset() { return 0x4bc; }
	static constexpr uint64_t size() { return 32; }
};
struct GENCNTREG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_120 format;
	static constexpr uint64_t mmio_offset() { return 0x4c0; }
	static constexpr uint64_t size() { return 32; }
};
struct MCGDPATCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_121 format;
	static constexpr uint64_t mmio_offset() { return 0x4c4; }
	static constexpr uint64_t size() { return 32; }
};
struct MCGDPCNT0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_122 format;
	static constexpr uint64_t mmio_offset() { return 0x4c8; }
	static constexpr uint64_t size() { return 32; }
};
struct MCGDPCNT1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_123 format;
	static constexpr uint64_t mmio_offset() { return 0x4cc; }
	static constexpr uint64_t size() { return 32; }
};
struct TCLATCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_124 format;
	static constexpr uint64_t mmio_offset() { return 0x500; }
	static constexpr uint64_t size() { return 32; }
};
struct TCLATERR0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_125 format;
	static constexpr uint64_t mmio_offset() { return 0x504; }
	static constexpr uint64_t size() { return 32; }
};
struct TCLATERR1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_126 format;
	static constexpr uint64_t mmio_offset() { return 0x508; }
	static constexpr uint64_t size() { return 32; }
};
struct TC0LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x50c; }
	static constexpr uint64_t size() { return 32; }
};
struct TC1LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x510; }
	static constexpr uint64_t size() { return 32; }
};
struct TC2LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x514; }
	static constexpr uint64_t size() { return 32; }
};
struct TC3LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x518; }
	static constexpr uint64_t size() { return 32; }
};
struct TC4LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x51c; }
	static constexpr uint64_t size() { return 32; }
};
struct TC5LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x520; }
	static constexpr uint64_t size() { return 32; }
};
struct TC6LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x524; }
	static constexpr uint64_t size() { return 32; }
};
struct TC7LATMON {
	typedef cambria_rnr_global_cfgFmt::FORMAT_127 format;
	static constexpr uint64_t mmio_offset() { return 0x528; }
	static constexpr uint64_t size() { return 32; }
};
struct LIVETMR {
	typedef cambria_rnr_global_cfgFmt::FORMAT_135 format;
	static constexpr uint64_t mmio_offset() { return 0x540; }
	static constexpr uint64_t size() { return 32; }
};
struct TIMESTMP {
	typedef cambria_rnr_global_cfgFmt::FORMAT_136 format;
	static constexpr uint64_t mmio_offset() { return 0x544; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x548; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x54c; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x550; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x554; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x558; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x55c; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x560; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x564; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x568; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x56c; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x570; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x574; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x578; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x57c; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTART7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_137 format;
	static constexpr uint64_t mmio_offset() { return 0x580; }
	static constexpr uint64_t size() { return 32; }
};
struct TSSTOP7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_138 format;
	static constexpr uint64_t mmio_offset() { return 0x584; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_153 format;
	static constexpr uint64_t mmio_offset() { return 0x5a0; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_154 format;
	static constexpr uint64_t mmio_offset() { return 0x5a4; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_155 format;
	static constexpr uint64_t mmio_offset() { return 0x5a8; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_156 format;
	static constexpr uint64_t mmio_offset() { return 0x5ac; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_157 format;
	static constexpr uint64_t mmio_offset() { return 0x5b0; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_158 format;
	static constexpr uint64_t mmio_offset() { return 0x5b4; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_159 format;
	static constexpr uint64_t mmio_offset() { return 0x5b8; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATTHR7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_160 format;
	static constexpr uint64_t mmio_offset() { return 0x5bc; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATERR0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_161 format;
	static constexpr uint64_t mmio_offset() { return 0x5c0; }
	static constexpr uint64_t size() { return 32; }
};
struct TSLATERR1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_162 format;
	static constexpr uint64_t mmio_offset() { return 0x5c4; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5c8; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5cc; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5d0; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5d4; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5d8; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5dc; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5e0; }
	static constexpr uint64_t size() { return 32; }
};
struct TSMAXLAT7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_163 format;
	static constexpr uint64_t mmio_offset() { return 0x5e4; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPERRCTRL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_171 format;
	static constexpr uint64_t mmio_offset() { return 0x600; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPERRADDR {
	typedef cambria_rnr_global_cfgFmt::FORMAT_172 format;
	static constexpr uint64_t mmio_offset() { return 0x604; }
	static constexpr uint64_t size() { return 32; }
};
/* When a data compare error is detected, 8 DWs are stored even though some may not have errors. So, for certain
indices, the error data could have correct [lb]expected[rb] data.[br]
Inactive byte enables are not checked (Message Type and PADs) and will have the expected data pattern in those bytes. */
struct MCTPERRACTDATA {
	typedef cambria_rnr_global_cfgFmt::FORMAT_89 format;
	static constexpr uint64_t mmio_offset() { return 0x608; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPERREXPDATA {
	typedef cambria_rnr_global_cfgFmt::FORMAT_90 format;
	static constexpr uint64_t mmio_offset() { return 0x60c; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPROISEED {
	typedef cambria_rnr_global_cfgFmt::FORMAT_175 format;
	static constexpr uint64_t mmio_offset() { return 0x610; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPROLSEED {
	typedef cambria_rnr_global_cfgFmt::FORMAT_176 format;
	static constexpr uint64_t mmio_offset() { return 0x614; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPSRCID {
	typedef cambria_rnr_global_cfgFmt::FORMAT_177 format;
	static constexpr uint64_t mmio_offset() { return 0x618; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPCMPCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_178 format;
	static constexpr uint64_t mmio_offset() { return 0x61c; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPBYTECNT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_91 format;
	static constexpr uint64_t mmio_offset() { return 0x620; }
	static constexpr uint64_t size() { return 32; }
};
struct MCTPDPATCTL {
	typedef cambria_rnr_global_cfgFmt::FORMAT_180 format;
	static constexpr uint64_t mmio_offset() { return 0x624; }
	static constexpr uint64_t size() { return 32; }
};
struct LTREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_181 format;
	static constexpr uint64_t mmio_offset() { return 0x640; }
	static constexpr uint64_t size() { return 32; }
};
struct L11LATENCY {
	typedef cambria_rnr_global_cfgFmt::FORMAT_182 format;
	static constexpr uint64_t mmio_offset() { return 0x680; }
	static constexpr uint64_t size() { return 32; }
};
struct L12LATENCY {
	typedef cambria_rnr_global_cfgFmt::FORMAT_183 format;
	static constexpr uint64_t mmio_offset() { return 0x684; }
	static constexpr uint64_t size() { return 32; }
};
struct L1SUBCFG1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_184 format;
	static constexpr uint64_t mmio_offset() { return 0x688; }
	static constexpr uint64_t size() { return 32; }
};
struct L1SUBCFG2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_185 format;
	static constexpr uint64_t mmio_offset() { return 0x68c; }
	static constexpr uint64_t size() { return 32; }
};
struct L1SUBSTATUS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_186 format;
	static constexpr uint64_t mmio_offset() { return 0x690; }
	static constexpr uint64_t size() { return 32; }
};
struct EXTCTRLSTS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_187 format;
	static constexpr uint64_t mmio_offset() { return 0x700; }
	static constexpr uint64_t size() { return 32; }
};
struct DFS0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_188 format;
	static constexpr uint64_t mmio_offset() { return 0x704; }
	static constexpr uint64_t size() { return 32; }
};
struct DFS1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_189 format;
	static constexpr uint64_t mmio_offset() { return 0x708; }
	static constexpr uint64_t size() { return 32; }
};
struct ATSCTL0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_190 format;
	static constexpr uint64_t mmio_offset() { return 0x70c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATSCTL1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_191 format;
	static constexpr uint64_t mmio_offset() { return 0x710; }
	static constexpr uint64_t size() { return 32; }
};
struct ITAGACCUM {
	typedef cambria_rnr_global_cfgFmt::FORMAT_192 format;
	static constexpr uint64_t mmio_offset() { return 0x714; }
	static constexpr uint64_t size() { return 32; }
};
struct PASIDREG {
	typedef cambria_rnr_global_cfgFmt::FORMAT_193 format;
	static constexpr uint64_t mmio_offset() { return 0x718; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x800; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x804; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x808; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x80c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x810; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x814; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x818; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x81c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x820; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x824; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x828; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x82c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x830; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x834; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x838; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x83c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x840; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x844; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x848; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x84c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x850; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x854; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x858; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x85c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x860; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x864; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x868; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x86c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x870; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x874; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x878; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x87c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x880; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x884; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x888; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x88c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x890; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x894; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x898; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R4 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x89c; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8a0; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8a4; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8a8; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8ac; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8b0; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8b4; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8b8; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R5 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8bc; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8c0; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8c4; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8c8; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8cc; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8d0; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8d4; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8d8; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R6 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8dc; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW0R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8e0; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW1R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8e4; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW2R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8e8; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATAOPDW3R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_194 format;
	static constexpr uint64_t mmio_offset() { return 0x8ec; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW0R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8f0; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW1R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8f4; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW2R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8f8; }
	static constexpr uint64_t size() { return 32; }
};
struct ATMDATACMPDW3R7 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_198 format;
	static constexpr uint64_t mmio_offset() { return 0x8fc; }
	static constexpr uint64_t size() { return 32; }
};
struct PMSCRATCH0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_258 format;
	static constexpr uint64_t mmio_offset() { return 0x900; }
	static constexpr uint64_t size() { return 32; }
};
struct PMSCRATCH1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_258 format;
	static constexpr uint64_t mmio_offset() { return 0x904; }
	static constexpr uint64_t size() { return 32; }
};
struct GPSBMSTRCTLSTS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_260 format;
	static constexpr uint64_t mmio_offset() { return 0x910; }
	static constexpr uint64_t size() { return 32; }
};
struct GPSBMSTRDAT {
	typedef cambria_rnr_global_cfgFmt::FORMAT_261 format;
	static constexpr uint64_t mmio_offset() { return 0x914; }
	static constexpr uint64_t size() { return 32; }
};
struct GPSBMSTRFLITDW0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_262 format;
	static constexpr uint64_t mmio_offset() { return 0x918; }
	static constexpr uint64_t size() { return 32; }
};
struct GPSBMSTRFLITDW1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_263 format;
	static constexpr uint64_t mmio_offset() { return 0x91c; }
	static constexpr uint64_t size() { return 32; }
};
struct GPSBMSTRFLITDW2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_264 format;
	static constexpr uint64_t mmio_offset() { return 0x920; }
	static constexpr uint64_t size() { return 32; }
};
struct GPSBMSTRFLITDW3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_265 format;
	static constexpr uint64_t mmio_offset() { return 0x924; }
	static constexpr uint64_t size() { return 32; }
};
struct OBFFCTL0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_266 format;
	static constexpr uint64_t mmio_offset() { return 0x940; }
	static constexpr uint64_t size() { return 32; }
};
struct OBFFCTL1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_267 format;
	static constexpr uint64_t mmio_offset() { return 0x944; }
	static constexpr uint64_t size() { return 32; }
};
struct OBFFCTL2 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_268 format;
	static constexpr uint64_t mmio_offset() { return 0x948; }
	static constexpr uint64_t size() { return 32; }
};
struct OBFFCTL3 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_269 format;
	static constexpr uint64_t mmio_offset() { return 0x94c; }
	static constexpr uint64_t size() { return 32; }
};
struct OBFFSTS0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_270 format;
	static constexpr uint64_t mmio_offset() { return 0x950; }
	static constexpr uint64_t size() { return 32; }
};
struct OBFFSTS1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_271 format;
	static constexpr uint64_t mmio_offset() { return 0x954; }
	static constexpr uint64_t size() { return 32; }
};
/* Allows us to observe the IOSF-SB Read Completion Data of a register mirror event */
struct MIRRORREADBACKDW0 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_272 format;
	static constexpr uint64_t mmio_offset() { return 0xa00; }
	static constexpr uint64_t size() { return 32; }
};
/* Allows us to observe the IOSF-SB Read Completion Data of a register mirror event */
struct MIRRORREADBACKDW1 {
	typedef cambria_rnr_global_cfgFmt::FORMAT_272 format;
	static constexpr uint64_t mmio_offset() { return 0xa04; }
	static constexpr uint64_t size() { return 32; }
};
/* Burst Mode Status Register */
struct BURSTSTS {
	typedef cambria_rnr_global_cfgFmt::FORMAT_274 format;
	static constexpr uint64_t mmio_offset() { return 0xb00; }
	static constexpr uint64_t size() { return 32; }
};
/* Watermark Control Register */
struct WATERMARK {
	typedef cambria_rnr_global_cfgFmt::FORMAT_275 format;
	static constexpr uint64_t mmio_offset() { return 0xb04; }
	static constexpr uint64_t size() { return 32; }
};
/* Drain Delay Control Register */
struct DRAINDELAY {
	typedef cambria_rnr_global_cfgFmt::FORMAT_276 format;
	static constexpr uint64_t mmio_offset() { return 0xb08; }
	static constexpr uint64_t size() { return 32; }
};
/* Controls the tx header fifo sizes */
struct TXFIFOSIZE {
	typedef cambria_rnr_global_cfgFmt::FORMAT_277 format;
	static constexpr uint64_t mmio_offset() { return 0xb0c; }
	static constexpr uint64_t size() { return 32; }
};
struct Container {
	typedef cambria_rnr_global_cfg::STRAPSTSREG STRAPSTSREG;
	typedef cambria_rnr_global_cfg::DEVCFGCTL DEVCFGCTL;
	typedef cambria_rnr_global_cfg::NUMREQSREG NUMREQSREG;
	typedef cambria_rnr_global_cfg::VMGLBSRD VMGLBSRD;
	typedef cambria_rnr_global_cfg::MEMSCRATCH0 MEMSCRATCH0;
	typedef cambria_rnr_global_cfg::MEMSCRATCH1 MEMSCRATCH1;
	typedef cambria_rnr_global_cfg::MEMSCRATCH2 MEMSCRATCH2;
	typedef cambria_rnr_global_cfg::MEMSCRATCH3 MEMSCRATCH3;
	typedef cambria_rnr_global_cfg::BRDSTRAPSTS BRDSTRAPSTS;
	typedef cambria_rnr_global_cfg::CBGM CBGM;
	typedef cambria_rnr_global_cfg::PREFETCHCTRL PREFETCHCTRL;
	typedef cambria_rnr_global_cfg::SAIREG SAIREG;
	typedef cambria_rnr_global_cfg::INTDMS INTDMS;
	typedef cambria_rnr_global_cfg::CFGRETRYSTS CFGRETRYSTS;
	typedef cambria_rnr_global_cfg::MSGETRIGREG0 MSGETRIGREG0;
	typedef cambria_rnr_global_cfg::MSGETRIGREG1 MSGETRIGREG1;
	typedef cambria_rnr_global_cfg::MSGETRIGREG2 MSGETRIGREG2;
	typedef cambria_rnr_global_cfg::MSGETRIGREG3 MSGETRIGREG3;
	typedef cambria_rnr_global_cfg::MSGETRIGREG4 MSGETRIGREG4;
	typedef cambria_rnr_global_cfg::MSGETRIGREG5 MSGETRIGREG5;
	typedef cambria_rnr_global_cfg::MSGETRIGREG6 MSGETRIGREG6;
	typedef cambria_rnr_global_cfg::MSGETRIGREG7 MSGETRIGREG7;
	typedef cambria_rnr_global_cfg::INTRCTL INTRCTL;
	typedef cambria_rnr_global_cfg::INTAINTID INTAINTID;
	typedef cambria_rnr_global_cfg::INTBINTID INTBINTID;
	typedef cambria_rnr_global_cfg::INTCINTID INTCINTID;
	typedef cambria_rnr_global_cfg::INTDINTID INTDINTID;
	typedef cambria_rnr_global_cfg::INTACNT INTACNT;
	typedef cambria_rnr_global_cfg::INTBCNT INTBCNT;
	typedef cambria_rnr_global_cfg::INTCCNT INTCCNT;
	typedef cambria_rnr_global_cfg::INTDCNT INTDCNT;
	typedef cambria_rnr_global_cfg::INTCNTREG INTCNTREG;
	typedef cambria_rnr_global_cfg::INTIDCLRREG INTIDCLRREG;
	typedef cambria_rnr_global_cfg::SPOLLMSGCODE SPOLLMSGCODE;
	typedef cambria_rnr_global_cfg::SPOLLVNDCODE SPOLLVNDCODE;
	typedef cambria_rnr_global_cfg::VNDMSGCODE0 VNDMSGCODE0;
	typedef cambria_rnr_global_cfg::VNDMSGCODE1 VNDMSGCODE1;
	typedef cambria_rnr_global_cfg::VNDMSGCODE2 VNDMSGCODE2;
	typedef cambria_rnr_global_cfg::VNDMSGCODE3 VNDMSGCODE3;
	typedef cambria_rnr_global_cfg::TGPDLYREG0 TGPDLYREG0;
	typedef cambria_rnr_global_cfg::TGPDLYREG1 TGPDLYREG1;
	typedef cambria_rnr_global_cfg::TGPCFGERRINJ TGPCFGERRINJ;
	typedef cambria_rnr_global_cfg::SPCTLSTS SPCTLSTS;
	typedef cambria_rnr_global_cfg::EXTINPSE EXTINPSE;
	typedef cambria_rnr_global_cfg::MSIETRIGD0 MSIETRIGD0;
	typedef cambria_rnr_global_cfg::MSIETRIGD1 MSIETRIGD1;
	typedef cambria_rnr_global_cfg::MSIETRIG MSIETRIG;
	typedef cambria_rnr_global_cfg::MSIETLA0 MSIETLA0;
	typedef cambria_rnr_global_cfg::MSIETHA0 MSIETHA0;
	typedef cambria_rnr_global_cfg::MSIETLA1 MSIETLA1;
	typedef cambria_rnr_global_cfg::MSIETHA1 MSIETHA1;
	typedef cambria_rnr_global_cfg::MSIETLA2 MSIETLA2;
	typedef cambria_rnr_global_cfg::MSIETHA2 MSIETHA2;
	typedef cambria_rnr_global_cfg::MSIETLA3 MSIETLA3;
	typedef cambria_rnr_global_cfg::MSIETHA3 MSIETHA3;
	typedef cambria_rnr_global_cfg::MSTRCTL MSTRCTL;
	typedef cambria_rnr_global_cfg::QTACTRL QTACTRL;
	typedef cambria_rnr_global_cfg::LNKSTSREG LNKSTSREG;
	typedef cambria_rnr_global_cfg::CPLTOREG CPLTOREG;
	typedef cambria_rnr_global_cfg::CMPLTOINFO CMPLTOINFO;
	typedef cambria_rnr_global_cfg::CMPLTOADDR0 CMPLTOADDR0;
	typedef cambria_rnr_global_cfg::CMPLTOADDR1 CMPLTOADDR1;
	typedef cambria_rnr_global_cfg::SQENTRYSTS SQENTRYSTS;
	typedef cambria_rnr_global_cfg::ERRCNTREG0 ERRCNTREG0;
	typedef cambria_rnr_global_cfg::ERRCNTREG1 ERRCNTREG1;
	typedef cambria_rnr_global_cfg::ERRCNTREG2 ERRCNTREG2;
	typedef cambria_rnr_global_cfg::ERRCNTREG3 ERRCNTREG3;
	typedef cambria_rnr_global_cfg::EXTTLSTSREG0 EXTTLSTSREG0;
	typedef cambria_rnr_global_cfg::EXTTLSTSREG1 EXTTLSTSREG1;
	typedef cambria_rnr_global_cfg::EXTTLMSKREG0 EXTTLMSKREG0;
	typedef cambria_rnr_global_cfg::EXTTLMSKREG1 EXTTLMSKREG1;
	typedef cambria_rnr_global_cfg::LTRVALUEREG LTRVALUEREG;
	typedef cambria_rnr_global_cfg::LTRCTLREG LTRCTLREG;
	typedef cambria_rnr_global_cfg::LTRERRCNT LTRERRCNT;
	typedef cambria_rnr_global_cfg::LTRMAXNPO LTRMAXNPO;
	typedef cambria_rnr_global_cfg::LTRMAXPO LTRMAXPO;
	typedef cambria_rnr_global_cfg::CRSCTRLREG CRSCTRLREG;
	typedef cambria_rnr_global_cfg::FLRCTLREG FLRCTLREG;
	typedef cambria_rnr_global_cfg::LNKWCHGREG0 LNKWCHGREG0;
	typedef cambria_rnr_global_cfg::LNKWCHGREG1 LNKWCHGREG1;
	typedef cambria_rnr_global_cfg::LNKWCHGTRGREG0 LNKWCHGTRGREG0;
	typedef cambria_rnr_global_cfg::LNKWCHGTRGREG1 LNKWCHGTRGREG1;
	typedef cambria_rnr_global_cfg::GLBROISEED GLBROISEED;
	typedef cambria_rnr_global_cfg::GLBROLSEED GLBROLSEED;
	typedef cambria_rnr_global_cfg::MCROISEED MCROISEED;
	typedef cambria_rnr_global_cfg::MCROLSEED MCROLSEED;
	typedef cambria_rnr_global_cfg::MCERRCTRLREG MCERRCTRLREG;
	typedef cambria_rnr_global_cfg::MCERRADDR MCERRADDR;
	typedef cambria_rnr_global_cfg::MCERRUPADDR MCERRUPADDR;
	typedef cambria_rnr_global_cfg::MCERRACTDATA MCERRACTDATA;
	typedef cambria_rnr_global_cfg::MCERREXPDATA MCERREXPDATA;
	typedef cambria_rnr_global_cfg::MCBYTECNT MCBYTECNT;
	typedef cambria_rnr_global_cfg::PMMETRICSREG0 PMMETRICSREG0;
	typedef cambria_rnr_global_cfg::PMMETRICSREG1 PMMETRICSREG1;
	typedef cambria_rnr_global_cfg::PMPSECTRL PMPSECTRL;
	typedef cambria_rnr_global_cfg::WAKECTL WAKECTL;
	typedef cambria_rnr_global_cfg::PMCTRL0 PMCTRL0;
	typedef cambria_rnr_global_cfg::PMCTRL1 PMCTRL1;
	typedef cambria_rnr_global_cfg::PMCTRL2 PMCTRL2;
	typedef cambria_rnr_global_cfg::PMCTRL3 PMCTRL3;
	typedef cambria_rnr_global_cfg::PMCTRL4 PMCTRL4;
	typedef cambria_rnr_global_cfg::RETRIGEVENT RETRIGEVENT;
	typedef cambria_rnr_global_cfg::L1LATENCY L1LATENCY;
	typedef cambria_rnr_global_cfg::PMPSECTRL2 PMPSECTRL2;
	typedef cambria_rnr_global_cfg::MSGDATACMPCTL MSGDATACMPCTL;
	typedef cambria_rnr_global_cfg::MSGDATACMPCNT MSGDATACMPCNT;
	typedef cambria_rnr_global_cfg::MSGDATAEXP0 MSGDATAEXP0;
	typedef cambria_rnr_global_cfg::MSGDATAEXP1 MSGDATAEXP1;
	typedef cambria_rnr_global_cfg::MSGDATAEXP2 MSGDATAEXP2;
	typedef cambria_rnr_global_cfg::MSGDATAEXP3 MSGDATAEXP3;
	typedef cambria_rnr_global_cfg::MSGDATAMSK0 MSGDATAMSK0;
	typedef cambria_rnr_global_cfg::MSGDATAMSK1 MSGDATAMSK1;
	typedef cambria_rnr_global_cfg::MSGDATAMSK2 MSGDATAMSK2;
	typedef cambria_rnr_global_cfg::MSGDATAMSK3 MSGDATAMSK3;
	typedef cambria_rnr_global_cfg::MSGDATAERR0 MSGDATAERR0;
	typedef cambria_rnr_global_cfg::MSGDATAERR1 MSGDATAERR1;
	typedef cambria_rnr_global_cfg::MSGDATAERR2 MSGDATAERR2;
	typedef cambria_rnr_global_cfg::MSGDATAERR3 MSGDATAERR3;
	typedef cambria_rnr_global_cfg::GENCNTCTRL GENCNTCTRL;
	typedef cambria_rnr_global_cfg::GENCNTREG0 GENCNTREG0;
	typedef cambria_rnr_global_cfg::GENCNTREG1 GENCNTREG1;
	typedef cambria_rnr_global_cfg::MCGDPATCTL MCGDPATCTL;
	typedef cambria_rnr_global_cfg::MCGDPCNT0 MCGDPCNT0;
	typedef cambria_rnr_global_cfg::MCGDPCNT1 MCGDPCNT1;
	typedef cambria_rnr_global_cfg::TCLATCTL TCLATCTL;
	typedef cambria_rnr_global_cfg::TCLATERR0 TCLATERR0;
	typedef cambria_rnr_global_cfg::TCLATERR1 TCLATERR1;
	typedef cambria_rnr_global_cfg::TC0LATMON TC0LATMON;
	typedef cambria_rnr_global_cfg::TC1LATMON TC1LATMON;
	typedef cambria_rnr_global_cfg::TC2LATMON TC2LATMON;
	typedef cambria_rnr_global_cfg::TC3LATMON TC3LATMON;
	typedef cambria_rnr_global_cfg::TC4LATMON TC4LATMON;
	typedef cambria_rnr_global_cfg::TC5LATMON TC5LATMON;
	typedef cambria_rnr_global_cfg::TC6LATMON TC6LATMON;
	typedef cambria_rnr_global_cfg::TC7LATMON TC7LATMON;
	typedef cambria_rnr_global_cfg::LIVETMR LIVETMR;
	typedef cambria_rnr_global_cfg::TIMESTMP TIMESTMP;
	typedef cambria_rnr_global_cfg::TSSTART0 TSSTART0;
	typedef cambria_rnr_global_cfg::TSSTOP0 TSSTOP0;
	typedef cambria_rnr_global_cfg::TSSTART1 TSSTART1;
	typedef cambria_rnr_global_cfg::TSSTOP1 TSSTOP1;
	typedef cambria_rnr_global_cfg::TSSTART2 TSSTART2;
	typedef cambria_rnr_global_cfg::TSSTOP2 TSSTOP2;
	typedef cambria_rnr_global_cfg::TSSTART3 TSSTART3;
	typedef cambria_rnr_global_cfg::TSSTOP3 TSSTOP3;
	typedef cambria_rnr_global_cfg::TSSTART4 TSSTART4;
	typedef cambria_rnr_global_cfg::TSSTOP4 TSSTOP4;
	typedef cambria_rnr_global_cfg::TSSTART5 TSSTART5;
	typedef cambria_rnr_global_cfg::TSSTOP5 TSSTOP5;
	typedef cambria_rnr_global_cfg::TSSTART6 TSSTART6;
	typedef cambria_rnr_global_cfg::TSSTOP6 TSSTOP6;
	typedef cambria_rnr_global_cfg::TSSTART7 TSSTART7;
	typedef cambria_rnr_global_cfg::TSSTOP7 TSSTOP7;
	typedef cambria_rnr_global_cfg::TSLATTHR0 TSLATTHR0;
	typedef cambria_rnr_global_cfg::TSLATTHR1 TSLATTHR1;
	typedef cambria_rnr_global_cfg::TSLATTHR2 TSLATTHR2;
	typedef cambria_rnr_global_cfg::TSLATTHR3 TSLATTHR3;
	typedef cambria_rnr_global_cfg::TSLATTHR4 TSLATTHR4;
	typedef cambria_rnr_global_cfg::TSLATTHR5 TSLATTHR5;
	typedef cambria_rnr_global_cfg::TSLATTHR6 TSLATTHR6;
	typedef cambria_rnr_global_cfg::TSLATTHR7 TSLATTHR7;
	typedef cambria_rnr_global_cfg::TSLATERR0 TSLATERR0;
	typedef cambria_rnr_global_cfg::TSLATERR1 TSLATERR1;
	typedef cambria_rnr_global_cfg::TSMAXLAT0 TSMAXLAT0;
	typedef cambria_rnr_global_cfg::TSMAXLAT1 TSMAXLAT1;
	typedef cambria_rnr_global_cfg::TSMAXLAT2 TSMAXLAT2;
	typedef cambria_rnr_global_cfg::TSMAXLAT3 TSMAXLAT3;
	typedef cambria_rnr_global_cfg::TSMAXLAT4 TSMAXLAT4;
	typedef cambria_rnr_global_cfg::TSMAXLAT5 TSMAXLAT5;
	typedef cambria_rnr_global_cfg::TSMAXLAT6 TSMAXLAT6;
	typedef cambria_rnr_global_cfg::TSMAXLAT7 TSMAXLAT7;
	typedef cambria_rnr_global_cfg::MCTPERRCTRL MCTPERRCTRL;
	typedef cambria_rnr_global_cfg::MCTPERRADDR MCTPERRADDR;
	typedef cambria_rnr_global_cfg::MCTPERRACTDATA MCTPERRACTDATA;
	typedef cambria_rnr_global_cfg::MCTPERREXPDATA MCTPERREXPDATA;
	typedef cambria_rnr_global_cfg::MCTPROISEED MCTPROISEED;
	typedef cambria_rnr_global_cfg::MCTPROLSEED MCTPROLSEED;
	typedef cambria_rnr_global_cfg::MCTPSRCID MCTPSRCID;
	typedef cambria_rnr_global_cfg::MCTPCMPCTL MCTPCMPCTL;
	typedef cambria_rnr_global_cfg::MCTPBYTECNT MCTPBYTECNT;
	typedef cambria_rnr_global_cfg::MCTPDPATCTL MCTPDPATCTL;
	typedef cambria_rnr_global_cfg::LTREG LTREG;
	typedef cambria_rnr_global_cfg::L11LATENCY L11LATENCY;
	typedef cambria_rnr_global_cfg::L12LATENCY L12LATENCY;
	typedef cambria_rnr_global_cfg::L1SUBCFG1 L1SUBCFG1;
	typedef cambria_rnr_global_cfg::L1SUBCFG2 L1SUBCFG2;
	typedef cambria_rnr_global_cfg::L1SUBSTATUS L1SUBSTATUS;
	typedef cambria_rnr_global_cfg::EXTCTRLSTS EXTCTRLSTS;
	typedef cambria_rnr_global_cfg::DFS0 DFS0;
	typedef cambria_rnr_global_cfg::DFS1 DFS1;
	typedef cambria_rnr_global_cfg::ATSCTL0 ATSCTL0;
	typedef cambria_rnr_global_cfg::ATSCTL1 ATSCTL1;
	typedef cambria_rnr_global_cfg::ITAGACCUM ITAGACCUM;
	typedef cambria_rnr_global_cfg::PASIDREG PASIDREG;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R0 ATMDATAOPDW0R0;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R0 ATMDATAOPDW1R0;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R0 ATMDATAOPDW2R0;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R0 ATMDATAOPDW3R0;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R0 ATMDATACMPDW0R0;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R0 ATMDATACMPDW1R0;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R0 ATMDATACMPDW2R0;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R0 ATMDATACMPDW3R0;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R1 ATMDATAOPDW0R1;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R1 ATMDATAOPDW1R1;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R1 ATMDATAOPDW2R1;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R1 ATMDATAOPDW3R1;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R1 ATMDATACMPDW0R1;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R1 ATMDATACMPDW1R1;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R1 ATMDATACMPDW2R1;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R1 ATMDATACMPDW3R1;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R2 ATMDATAOPDW0R2;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R2 ATMDATAOPDW1R2;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R2 ATMDATAOPDW2R2;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R2 ATMDATAOPDW3R2;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R2 ATMDATACMPDW0R2;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R2 ATMDATACMPDW1R2;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R2 ATMDATACMPDW2R2;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R2 ATMDATACMPDW3R2;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R3 ATMDATAOPDW0R3;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R3 ATMDATAOPDW1R3;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R3 ATMDATAOPDW2R3;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R3 ATMDATAOPDW3R3;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R3 ATMDATACMPDW0R3;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R3 ATMDATACMPDW1R3;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R3 ATMDATACMPDW2R3;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R3 ATMDATACMPDW3R3;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R4 ATMDATAOPDW0R4;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R4 ATMDATAOPDW1R4;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R4 ATMDATAOPDW2R4;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R4 ATMDATAOPDW3R4;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R4 ATMDATACMPDW0R4;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R4 ATMDATACMPDW1R4;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R4 ATMDATACMPDW2R4;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R4 ATMDATACMPDW3R4;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R5 ATMDATAOPDW0R5;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R5 ATMDATAOPDW1R5;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R5 ATMDATAOPDW2R5;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R5 ATMDATAOPDW3R5;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R5 ATMDATACMPDW0R5;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R5 ATMDATACMPDW1R5;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R5 ATMDATACMPDW2R5;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R5 ATMDATACMPDW3R5;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R6 ATMDATAOPDW0R6;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R6 ATMDATAOPDW1R6;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R6 ATMDATAOPDW2R6;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R6 ATMDATAOPDW3R6;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R6 ATMDATACMPDW0R6;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R6 ATMDATACMPDW1R6;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R6 ATMDATACMPDW2R6;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R6 ATMDATACMPDW3R6;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW0R7 ATMDATAOPDW0R7;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW1R7 ATMDATAOPDW1R7;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW2R7 ATMDATAOPDW2R7;
	typedef cambria_rnr_global_cfg::ATMDATAOPDW3R7 ATMDATAOPDW3R7;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW0R7 ATMDATACMPDW0R7;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW1R7 ATMDATACMPDW1R7;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW2R7 ATMDATACMPDW2R7;
	typedef cambria_rnr_global_cfg::ATMDATACMPDW3R7 ATMDATACMPDW3R7;
	typedef cambria_rnr_global_cfg::PMSCRATCH0 PMSCRATCH0;
	typedef cambria_rnr_global_cfg::PMSCRATCH1 PMSCRATCH1;
	typedef cambria_rnr_global_cfg::GPSBMSTRCTLSTS GPSBMSTRCTLSTS;
	typedef cambria_rnr_global_cfg::GPSBMSTRDAT GPSBMSTRDAT;
	typedef cambria_rnr_global_cfg::GPSBMSTRFLITDW0 GPSBMSTRFLITDW0;
	typedef cambria_rnr_global_cfg::GPSBMSTRFLITDW1 GPSBMSTRFLITDW1;
	typedef cambria_rnr_global_cfg::GPSBMSTRFLITDW2 GPSBMSTRFLITDW2;
	typedef cambria_rnr_global_cfg::GPSBMSTRFLITDW3 GPSBMSTRFLITDW3;
	typedef cambria_rnr_global_cfg::OBFFCTL0 OBFFCTL0;
	typedef cambria_rnr_global_cfg::OBFFCTL1 OBFFCTL1;
	typedef cambria_rnr_global_cfg::OBFFCTL2 OBFFCTL2;
	typedef cambria_rnr_global_cfg::OBFFCTL3 OBFFCTL3;
	typedef cambria_rnr_global_cfg::OBFFSTS0 OBFFSTS0;
	typedef cambria_rnr_global_cfg::OBFFSTS1 OBFFSTS1;
	typedef cambria_rnr_global_cfg::MIRRORREADBACKDW0 MIRRORREADBACKDW0;
	typedef cambria_rnr_global_cfg::MIRRORREADBACKDW1 MIRRORREADBACKDW1;
	typedef cambria_rnr_global_cfg::BURSTSTS BURSTSTS;
	typedef cambria_rnr_global_cfg::WATERMARK WATERMARK;
	typedef cambria_rnr_global_cfg::DRAINDELAY DRAINDELAY;
	typedef cambria_rnr_global_cfg::TXFIFOSIZE TXFIFOSIZE;
};
} // namespace cambria_rnr_global_cfg

#endif // __CAMBRIA_RNR_GLOBAL_CFG_REGS_H__
