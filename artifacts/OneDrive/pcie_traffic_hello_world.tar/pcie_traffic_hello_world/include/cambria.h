#ifndef __CAMBRIA_H__
#define __CAMBRIA_H_

#include <abstract.h>
#include <cstring>

const int VM_COUNT = 4;
const unsigned int MMR_SIZE = 4;

struct Register {
    uint8_t *baseAddress;
    uint32_t value;
};

class VectorMachine {
    private:
        void WriteOutMMR() { memcpy(mmr.baseAddress, &(mmr.value), MMR_SIZE); }
    public:
        unsigned int index;
        uint8_t *bufferBaseAddr;
        unsigned int bufferSize = 128000;
        Register mmr;
        Register ErrorControl;
        Register ErrorLowerAddr;
        Register ErrorUpperAddr;
        Register ErrorActualData;
        Register ErrorExpectedData;

        void Enable();
        bool IsEnabled();
        void Start();
        bool IsFinished();
        bool PollUntilDone();
        bool DidReadError();
        void LogErrors();
        uint64_t GetErrorAddress();
        uint32_t GetExpectedData();
        uint32_t GetActualData();
};

class VirtualTarget {
    private:
    public:
        unsigned int index;
        uint8_t *targetBaseAddr;
        uint64_t targetBaseAddrPhys;
        unsigned int targetSize;
        Register ErrorControl;
        Register ErrorAddr;
        Register ErrorUpperAddr;
        Register ErrorActualData;
        Register ErrorExpectedData;

        int Read(uint8_t *buffer, unsigned int offset, unsigned int length);
        int Write(uint8_t *buffer, unsigned int offset, unsigned int length);
        bool DidWriteError();
        void LogErrors();
        uint64_t GetErrorAddress();
        uint32_t GetExpectedData();
        uint32_t GetActualData();
};

class CambriaCard {
    private:
    public:
        CambriaCard(abstract_pci_info_t *pi);  
        VectorMachine vm[VM_COUNT];
        VirtualTarget vt[VM_COUNT];
};

#endif
