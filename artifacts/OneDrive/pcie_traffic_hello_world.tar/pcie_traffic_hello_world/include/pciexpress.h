/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2022 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details
/// contains pci express common capabilities
//
// The PCI Express Capabilities, Device Capabilities, Device Status, and Device Control registers are
// required for all PCI Express device Functions. Device Capabilities 2, Device Status 2, and Device
// Control 2 registers are required for all PCI Express device Functions that implement capabilities
// requiring those registers. For device Functions that do not implement the Device Capabilities 2,
// Device Status 2, and Device Control 2 registers, these spaces must be hardwired to 0b.
// The Link Capabilities, Link Status, and Link Control registers are required for all Root Ports, Switch
// Ports, Bridges, and Endpoints that are not Root Complex Integrated Endpoints. For Functions that
// do not implement the Link Capabilities, Link Status, and Link Control registers, these spaces must
// be hardwired to 0. Link Capabilities 2, Link Status 2, and Link Control 2 registers are required for
// all Root Ports, Switch Ports, Bridges, and Endpoints (except for Root Complex Integrated
// Endpoints) that implement capabilities requiring those registers. For Functions that do not
// implement the Link Capabilities 2, Link Status 2, and Link Control 2 registers, these spaces must be
// hardwired to 0b.
// Slot Capabilities, Slot Status, and Slot Control registers are required for Switch Downstream and
// Root Ports if a slot is implemented on the Port (indicated by the Slot Implemented bit in the PCI
// Express Capabilities register). For Functions that do not implement the Slot Capabilities, Slot
// Status, and Slot Control registers, these spaces must be hardwired to 0b, with the exception of the
// Presence Detect State bit in the Slot Status register of Downstream Ports, which must be hardwired
// to 1b (see Section 7.8.11). Slot Capabilities 2, Slot Status 2, and Slot Control 2 registers are required
// for Switch Downstream and Root Ports if a slot is implemented on the Port and the Function
// implements capabilities requiring those registers. For Functions that do not implement the Slot
// Capabilities 2, Slot Status 2, and Slot Control 2 registers, these spaces must be hardwired to 0b.
// Root Ports and Root Complex Event Collectors must implement the Root Capabilities, Root Status,
// and Root Control registers. For Functions that do not implement the Root Capabilities, Root
// Status, and Root Control registers, these spaces must be hardwired to 0b.
#pragma once
#ifndef __MAESTRO_PCI_COMMON_H__
#define __MAESTRO_PCI_COMMON_H__

#include <stdint.h>

#define PCI_ADDRESS_ECAM(pciexbar, b, d, f, o)                                                                         \
	((pciexbar | ((uint32_t)b << 20) | ((uint32_t)d << 15) | ((uint32_t)f << 12)) + o)

// PCIe capabilities register [7:4]
enum class DevicePortType {
	Endpoint = 0,
	LegacyEndpoint = 1,
	Rootport = 4,
	UpstreamPort = 5,
	DownstreamPort = 6,
	BridgeToPci = 7,
	BridgeFromPci = 8,
	RCiEP = 9,
	EventCollector = 10
};

// TODO: Refactor subrange management and move this somewhere else
enum class CompletionErrorKind { None, Corrupt, UnsupportedRequest, Timeout, Abort };

// Link Speed Vectors
enum class LinkSpeed {
	NoChange = 0, // No speed Change
	Gen1 = 1,     // 2.5G transfers per second
	Gen2 = 2,     // 5G transfers per second
	Gen3 = 3,     // 8G transfers per second
	Gen4 = 4,     // 16G transfers per second
	Gen5 = 5,     // 32G transfers per second
	Gen6 = 6,     // 64G transfers per second
};

enum class LinkWidth { NoChange = 0x0, x1 = 0x01, x2 = 0x02, x4 = 0x04, x8 = 0x08, x12 = 0x0C, x16 = 0x10, x32 = 0x20 };

enum class DllpType {
	Ack = 0,
	PmEnterL1 = 0x20,
	PmEnterL23 = 0x21,
	PmActiveStateReqL1 = 0x23,
	PmReqAck = 0x24,
};

enum class MsgRoute { RootComplex = 0, Address, ID, Broadcast, Local, Gathered, Rsvd1, Rsvd2 };
enum class MsgCode {
	Unlock = 0x0,
	InvalidateRequest = 0x1,
	InvalidateCompletion = 0x2,
	PageRequest = 0x4,
	PRGResponse = 0x5,
	LatencyToleranceReport = 0x10,
	OptimizedBufferFlushFill = 0x12,
	PmActiveStateNack = 0x14,
	PmPme = 0x18,
	PmeTurnOff = 0x19,
	PmeTurnOffAck = 0x1B,
	AssertIntA = 0x20,
	AssertIntB = 0x21,
	AssertIntC = 0x22,
	AssertIntD = 0x23,
	DeassertIntA = 0x24,
	DeassertIntB = 0x25,
	DeassertIntC = 0x26,
	DeassertIntD = 0x27,
	ErrCorr = 0x30,
	ErrNonFatal = 0x31,
	ErrFatal = 0x33,
	AttentionIndicatorOff = 0x40,
	AttentionIndicatorOn = 0x41,
	AttentionIndicatorBlink = 0x43,
	PowerIndicatorOff = 0x44,
	PowerIndicatorOn = 0x45,
	PowerIndicatorBlink = 0x47,
	AttentionButtonPressed = 0x48,
	SetSlotPowerLimit = 0x50,
	PtmRequest = 0x52,
	PtmResponse = 0x53,
	VendorDefinedType0 = 0x7E,
	VendorDefinedType1 = 0x7F,
};

// Section 2 Capability IDs of PCI CODE and ID Assignment Specification Rev
// 1.5
// Originally from Appendix H of PCI Local Bus Specification Rev 3.0
enum class PCICapability_t {
	NULL_CAPABILITY = 0x00,
	PCI_POWER_MANAGEMENT_INTERFACE = 0x01,
	AGP = 0x02,
	VPD = 0x03,
	SLOT_IDENTIFICATION = 0x04,
	MESSAGE_SIGNALED_INTERRUPTS = 0x05,
	COMPACTPCI_HOT_SWAP = 0x06,
	PCI_X = 0x07,
	HYPERTRANSPORT = 0x08,
	VENDOR_SPECIFIC = 0x09,
	DEBUG_PORT = 0x0A,
	COMPACTPCI_CENTRAL_RESOURCE_CONTROL = 0x0B,
	PCI_HOT_PLUG = 0x0C,
	PCI_BRIDGE_SUBSYSTEM_VENDOR_ID = 0x0D,
	AGP_8X = 0x0E,
	SECURE_DEVICE = 0x0F,
	PCI_EXPRESS = 0x10,
	MSI_X = 0x11,
	SERIAL_ATA_DATA_INDEX_CONFIGURATION = 0x12,
	ADVANCED_FEATURES = 0x13,
	ENHANCE_ALLOCATION = 0x14,
	FLATTENING_PORTAL_BRIDGE = 0x15,

	COUNT,
};

// Section 3 Extended Capability IDs of PCI CODE and ID Assignment
// Specification Rev 1.5
enum class PCIExtendedCapability_t {
	NULL_CAPABILITY = 0x0000,
	ADVANCED_ERROR_REPORTING = 0x0001,
	VIRTUAL_CHANNEL = 0x0002,
	DEVICE_SERIAL_NUMBER = 0x0003,
	POWER_BUDGETING = 0x0004,
	ROOT_COMPLEX_LINK_DECLARATION = 0x0005,
	ROOT_COMPLEX_INTERNAL_LINK_CONTROL = 0x0006,
	ROOT_COMPLEX_EVENT_COLLECTOR_ENDPOINT_ASSOCIATION = 0x0007,
	MULTI_FUNCTION_VIRTUAL_CHANNEL = 0x0008,
	MFVC_VIRTUAL_CHANNEL = 0x0009,
	ROOT_COMPLEX_REGISTER_BLOCK_HEADER = 0x000A,
	VENDOR_SPECIFIC_EXTENDED_CAPABILITY = 0x000B,
	CONFIGURATION_ACCESS_CORRELATION = 0x000C,
	ACCESS_CONTROL_SERVICES = 0x000D,
	ALTERNATIVE_ROUTING_ID_INTERPRETATION = 0x000E,
	ADDRESS_TRANSLATION_SERVICES = 0x000F,
	SINGLE_ROOT_IO_VIRTUALIZATION = 0x0010,
	MULTI_ROOT_IO_VIRTUALIZATION = 0x0011,
	MULTICAST = 0x0012,
	PAGE_REQUEST = 0x0013,
	RESERVED_FOR_AMD = 0x0014,
	RESIZABLE_BAR = 0x0015,
	DYNAMIC_POWER_ALLOCATION = 0x0016,
	TLP_PROCESSING_HINTS = 0x0017,
	LATENCY_TOLERANCE_REPORTING = 0x0018,
	SECONDARY_PCI_EXPRESS = 0x0019,
	PROTOCOL_MULTIPLEXING = 0x001A,
	PROCESS_ADDRESS_SPACE_ID = 0x001B,
	LN_REQUESTER = 0x001C,
	DOWNSTREAM_PORT_CONTAINMENT = 0x001D,
	L1_PM_SUBSTATES = 0x001E,
	PRECISION_TIME_MEASUREMENT = 0x001F,
	PCI_EXPRESS_OVER_MPHY = 0x0020,
	FRS_QUEUEING = 0x0021,
	READINESS_TIME_REPORTING = 0x0022,
	DESIGNATED_VENDOR_SPECIFIC_EXTENDED_CAPABILITY = 0x0023,
	VF_RESIZABLE_BAR = 0x0024,
	DATA_LINK_FEATURE = 0x0025,
	PHYSICAL_LAYER_16GT = 0x0026,
	LANE_MARGINING_AT_RECEIVER = 0x0027,
	HIERARCHY_ID = 0x0028,
	NATIVE_PCIE_ENCLOUSURE_MANAGEMENT = 0x0029,
	PHYSICAL_LAYER_32GT = 0x002A,
	ALTERNATE_PROTOCOL = 0x002B,
	SYSTEM_FIRMWARE_INTERMEDIARY = 0x002C,
	SHADOW_FUNCTIONS = 0x002D,
	DATA_OBJECT_EXCHANGE = 0x002E,
	DEVICE_3 = 0x002F,
	INTEGRITY_AND_DATA_ENCRYPTION = 0x0030,
	PHYSICAL_LAYER_64GT = 0x0031,
	FLIT_LOGGING = 0x0032,
	FLIT_PERFORMANCE_MESUREMENT = 0x0033,
	FLIT_ERROR_INJECTION = 0x0034,
	COUNT,
};

union ReqTLPHeader {

	uint32_t dwords[4] = {0, 0, 0, 0};
	struct {
		struct {
			uint32_t type : 5;
			uint32_t fmt : 3;

			uint32_t th : 1;
			uint32_t ln : 1;
			uint32_t attr_2 : 1;
			uint32_t tag_8 : 1;
			uint32_t tc : 3;
			uint32_t tag_9 : 1;

			uint32_t length_msb : 2;
			uint32_t at : 2;
			uint32_t attr : 2;
			uint32_t ep : 1;
			uint32_t td : 1;

			uint32_t length_lsb : 8;
		};
		struct {
			uint32_t reqid_msb : 8;
			uint32_t reqid_lsb : 8;
			uint32_t tag : 8;
			uint32_t be : 8;
		};
		struct {
			uint32_t dw2_addr_31_24 : 8;
			uint32_t dw2_addr_23_16 : 8;
			uint32_t dw2_addr_15_8 : 8;
			uint32_t dw2_ph : 2;
			uint32_t dw2_addr_7_2 : 6;
		};
		struct {
			uint32_t dw3_addr_31_24 : 8;
			uint32_t dw3_addr_23_16 : 8;
			uint32_t dw3_addr_15_8 : 8;
			uint32_t dw3_ph : 2;
			uint32_t dw3_addr_7_2 : 6;
		};
	};
};

union CplTlpHeader {

	uint32_t dwords[3] = {0, 0, 0};
	struct {
		struct {
			uint32_t length : 10;
			uint32_t at : 2;
			uint32_t attr : 2;
			uint32_t ep : 1;
			uint32_t td : 1;
			uint32_t th : 1;
			uint32_t ln : 1;
			uint32_t attr_2 : 1;
			uint32_t tag_8 : 1;
			uint32_t tc : 3;
			uint32_t tag_9 : 1;
			uint32_t type : 5;
			uint32_t fmt : 3;
		};
		struct {
			uint32_t bc : 12;
			uint32_t bcm : 1;
			uint32_t status : 3;
			uint32_t cplid : 16;
		};
		struct {
			uint32_t lowaddr : 7;
			uint32_t rsvd : 1;
			uint32_t tag : 8;
			uint32_t reqid : 16;
		};
	};
};


#endif // __MAESTRO_PCI_COMMON_H__
