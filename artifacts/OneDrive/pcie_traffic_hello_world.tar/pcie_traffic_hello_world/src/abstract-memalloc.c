/*******************************************************************************
********************************************************************************
***                                                                           **
***                           INTEL CONFIDENTIAL                              **
***                                                                           **
***                  Copyright (c) 2021 Intel Corporation.                    **
***                           All Rights Reserved.                            **
***                                                                           **
***  The source code contained or described herein and all documents related  **
***  to the source code ("Material") are owned by Intel Corporation or its    **
***  suppliers or licensors.  Title to the Material remains with Intel        **
***  Corporation or its suppliers and licensors.  The Material contains trade **
***  secrets and proprietary and confidential information of Intel or its     **
***  suppliers and licensors.  The Material is protected by worldwide         **
***  copyright and trade secret laws and treaty provisions. No part of the    **
***  Material may be used, copied, reproduced, modified, published, uploaded, **
***  posted, transmitted, distributed, or disclosed in any way without        **
***  Intel's prior express written permission.                                **
***                                                                           **
***  No license under any patent, copyright, trade secret or other            **
***  intellectual property right is granted to or conferred upon you by       **
***  disclosure or delivery of the Materials, either expressly, by            **
***  implication, inducement, estoppel or otherwise.  Any license under such  **
***  intellectual property rights must be express and approved by Intel in    **
***  writing.                                                                 **
***                                                                           **
********************************************************************************
******** 10 ****** 20 ****** 30 ****** 40 ****** 50 ****** 60 ****** 70 *******/

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include "abstract.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <syscall.h>
#include <sched.h>
#include <unistd.h>
#include <errno.h>

#include <sv/sv.h>
#include <sv/svlib.h>
#include <sv/intrapi.h>
#include <sv/msrcreg.h>

#include <sys/queue.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define MAP_HUGE_2MB (21 << MAP_HUGE_SHIFT)

#define PAGE_PRESENT	(1ULL << 63)
#define PFN_MASK	((1ULL << 54) - 1)

typedef struct abstract_allocator {
	void *(*memalloc)(size_t length, int flags, size_t alignment);
	void *(*memalloc_phys)(void *phys, size_t length, int flags, size_t alignment);
	int (*memfree)(void *addr, size_t length);
	void *(*memalloc_virt_to_phys)(void *virt);
} abstract_allocator_t;

typedef struct {
	const char *name;
	const int abstract_type;
	const unsigned long svos_mem_type;
} cache_type_map_t;

typedef struct svos_target_item {
	void *target;
	void *virt_addr_begin;
	void *virt_addr_end;
	void *virt_aligned;
	void *phys_addr;
	void *phys_aligned;
	ssize_t size;
	LIST_ENTRY(svos_target_item) list_items;
} svos_target_item_t;

const cache_type_map_t cache_type_map[] = {
	/*
	 * name, abstr,	svos			Maestro TAL 		Maestro MemAlloc
	 */
	{ "UC",	MEM_UC,	SVuncachableMemory,	/* NonCached */		/* cache_attr_non_cached */ },
	{ "WB", MEM_WB, SVwriteBackMemory,	/* WriteBack */		/* cache_attr_write_back */  },
	{ "WC", MEM_WC, SVwriteCombiningMemory,	/* WriteCombined */	/* cache_attr_write_combined */ },
	{ "WT",	MEM_WT, SVwriteThroughMemory,	/* WriteThrough */	/* cache_attr_write_through */ },
	/* write protected makes no sense for breker */
	{ "WP", MEM_WP, SVwriteProtectMemory,	/* not defined */	/* not defined */ },
	{ NULL, 0,	~0UL }
};

/*
 *  The SVOS memory allocatore requires some of the MemTargetStuct
 *  information to help with the free'ing. To facilitate this, we track
 *  all allocations on a simple linked list.
 */
LIST_HEAD(listhead, svos_target_item);

struct listhead head;

static void *svos_alloc_phys(void *phys_base, size_t length, int flags, size_t alignment)
{
	unsigned long which = 0;
	size_t i;
	int ret;
	uint64_t size;
	void *virt;
	//volatile uint8_t *ptr;
	uint64_t phys;
	uintptr_t virt_aligned, phys_aligned;
	const char *name = NULL;
	svos_target_item_t *item;

	if (length + alignment < alignment)	/* Check for wrap around */
		return NULL;
	size = (uint64_t)(length + alignment);
	for (i = 0; cache_type_map[i].name; i++) {
		if (cache_type_map[i].abstract_type == flags) {
			name = cache_type_map[i].name;
			which = cache_type_map[i].svos_mem_type;
			break;
		}
	}
	if (!name) {
		fprintf(stderr, "%s: SVOS MemTargetAllocate not possible with cache type %d\n", __func__, flags);
		return NULL;
	}

	item = (svos_target_item_t *)calloc(sizeof(*item), 1);
	if (!item)
		return NULL;
 	which |= SVallowAliasing | SVreadMapping | SVwriteMapping | SVsharedMapping | SVexecMapping;
	virt = NULL;
	phys = (uint64_t)phys_base;

	ret = getMemoryTarget64(which, &item->target, &size, &virt, &phys);
	if (ret < 0) {
		if (geteuid() != 0)
			fprintf(stderr, "%s: SVOS alloc failed, ret=%d (%s), try running with root privilege\n",
				__func__, ret, strerror(-ret));
		else
			fprintf(stderr, "%s: SVOS alloc @ %p failed 0x%zx bytes, ret=%d (%s)\n",
				__func__, phys_base, size, ret, strerror(-ret));
		free(item);
		return NULL;
	}

	item->virt_addr_begin = virt;
	item->virt_addr_end = (void *)((uintptr_t)virt + size);
	item->phys_addr = (void *)phys;
	virt_aligned = (uintptr_t)virt;
	phys_aligned = (uintptr_t)phys;
	if (alignment) {
		virt_aligned += alignment;
		virt_aligned &= ~(alignment - 1);
		phys_aligned += alignment;
		phys_aligned &= ~(alignment - 1);
	}
	item->virt_aligned = (void *)virt_aligned;
	item->phys_aligned = (void *)phys_aligned;
	item->size = size;

	LIST_INSERT_HEAD(&head, item, list_items);

#if 0
	fprintf(stderr, "%s: size 0x%zx, flags %s, alignment 0x%zd -> Virt %p\n",
		__func__, size, name, alignment, (void *)virt_aligned);
#endif

	return (void *)virt_aligned;
}

void *svos_alloc_virt_to_phys(void *virt)
{
	svos_target_item_t *item;
	void *phys;

	/* First check if it's in the SVOS allocate range */
	LIST_FOREACH(item, &head, list_items) {
		if ((virt >= item->virt_addr_begin) && (virt < item->virt_addr_end)) {
			const uintptr_t offset = (uintptr_t)virt - (uintptr_t)item->virt_addr_begin;
			const uintptr_t phys = (uintptr_t)item->phys_addr + offset;

			return (void *)phys;
		}
	}

	/* Next check if its in the data/stack/heap/mmap VM range */
	phys = (void *)abstract_virt_to_phys(virt);
	if (phys)
		return phys;
	fprintf(stderr, "%s: failed to map virtual address %p to physical address\n", __func__, virt);
	errno = EINVAL;
	return NULL;
}

static int svos_free(void *addr, size_t length)
{
	svos_target_item_t *item;

	(void)length;

	LIST_FOREACH(item, &head, list_items) {
		if (addr == (void *)item->virt_aligned) {
			releaseMemoryTarget(item->target);
			LIST_REMOVE(item, list_items);
			free(item);
			return 0;
		}
	}
	fprintf(stderr, "svos free: failed to find %p\n", addr);
	errno = EINVAL;
	return -1;
}

static void *svos_alloc(size_t length, int flags, size_t alignment)
{
	return svos_alloc_phys(NULL, length, flags, alignment);
}

static abstract_allocator_t abstract_allocator = {
        svos_alloc,
	svos_alloc_phys,
	svos_free,
	svos_alloc_virt_to_phys,
};

static inline size_t abstract_power_of_two(size_t val)
{
	return (val & (val - 1)) == 0;
}

void *abstract_memalloc(size_t length, int flags, size_t alignment)
{
	if (!abstract_power_of_two(alignment))
		return NULL;
	if (abstract_allocator.memalloc)
		return abstract_allocator.memalloc(length, flags, alignment);
	return NULL;
}

void *abstract_memalloc_phys(void *phys, size_t length, int flags, size_t alignment)
{
	if (!abstract_power_of_two(alignment))
		return NULL;
	if (abstract_allocator.memalloc)
		return abstract_allocator.memalloc_phys(phys, length, flags, alignment);
	return NULL;
}

int abstract_memfree(void *addr, size_t length)
{
	if (abstract_allocator.memfree)
		return abstract_allocator.memfree(addr, length);
	return -EINVAL;
}

void *abstract_memalloc_virt_to_phys(void *virt)
{
	return abstract_allocator.memalloc_virt_to_phys(virt);
}
