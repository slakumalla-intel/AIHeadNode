#include "cambria.h"
#include <unistd.h>

/*
 * VectorMachine
 */

void VectorMachine::Enable() {  // Write all values to MMR to enable running
    mmr.value &= 0xffffffff << 2; // VMxM      - VM Mode set to Normal
    mmr.value |= 1 << 2;          // VMxE      - VM enable
    mmr.value |= 1 << 4;          // VMxES     - Clear end status
    mmr.value |= 1 << 5;          // VMxARAMPC - reset ARAM fetch pointer 
    mmr.value |= 1 << 7;          // VMxECVMx  - Clear streams from VM queue

    WriteOutMMR();
}

bool VectorMachine::IsEnabled() {
    int isEnabled = (*(mmr.baseAddress) >> 2) & 1; // Check VMxE bit
    return isEnabled ? true : false;
}

void VectorMachine::Start() {    // Write start bit
    mmr.value |= 1 << 16;  // SVMx - Start bit
    WriteOutMMR();
} 

bool VectorMachine::IsFinished() {
    int isFinished =  (*(mmr.baseAddress) >> 4) & 1;
    return isFinished ? true : false;
}

bool VectorMachine::PollUntilDone() {
    for (int i = 0; i < 10; i++) {
        sleep(1);
        if (IsFinished()) 
            return true;
	}
    return false;
}

bool VectorMachine::DidReadError() {
    uint8_t buf[4];
    memcpy(buf, ErrorControl.baseAddress, 4);
    return ((buf[2] & 0xf) != 0);   // Checking EVI<0-3>
}

void VectorMachine::LogErrors() {
    printf("Failing TLP: ");
    switch (*((uint32_t *) ErrorControl.baseAddress) & 0xf)
    {
        case 0x1:
            printf("Memory Read/Atomic\n");
            break;
        case 0x2:
            printf("Memory Read Lock\n");
            break;
        case 0x4:
            printf("IO Read\n");
            break;
        case 0x8:
            printf("Configuration Read\n");
            break;
        default:
            printf("None\n");
    }

    for (uint8_t i = 0; i < 8; i++) {
        printf("Error %u | ", i);
        printf("Address: %lx | ", GetErrorAddress());
        printf("Expected: %lx | ", GetExpectedData());
        printf("Actual: %lx \n", GetActualData());

        *((uint32_t *) ErrorControl.baseAddress) |= i << 8; // Set Error Index (EI)
    }

    return;
}

uint64_t VectorMachine::GetErrorAddress() {
    uint64_t addr = 0;
    addr |= *((uint32_t *) ErrorUpperAddr.baseAddress);
    addr = addr << 32;
    addr |= *((uint32_t *) ErrorLowerAddr.baseAddress) & 0xfffffffffffffffc;
    return addr;
}

uint32_t VectorMachine::GetExpectedData() {
    return *((uint32_t *) ErrorExpectedData.baseAddress);
}

uint32_t VectorMachine::GetActualData() {
    return *((uint32_t *) ErrorActualData.baseAddress);
}


/*
 * VirtualTarget
 */

int VirtualTarget::Read(uint8_t *buffer, unsigned int offset, unsigned int length) {
    if (offset + length > targetSize)
        length = targetSize - offset;

    memcpy(buffer, targetBaseAddr + offset, length);
    return length;
}

int VirtualTarget::Write(uint8_t *buffer, unsigned int offset, unsigned int length) {
    if (offset + length > targetSize)
        length = targetSize - offset;
    
    memcpy(targetBaseAddr + offset, buffer, length);
    return length;
}

bool VirtualTarget::DidWriteError() {  
    return (((*((uint8_t *) ErrorControl.baseAddress)) & (0x1 << 16)) != 0);  // Checking Target Range Error Valid (TREV)
}

void VirtualTarget::LogErrors() {
    printf("Failing TLP: ");
    switch (*((uint32_t *) ErrorControl.baseAddress) & 0xf)
    {
        case 0x3:
            printf("Memory Write\n");
            break;
        case 0x5:
            printf("IO Write\n");
            break;
        default:
            printf("None\n");
    }

    for (uint8_t i = 0; i < 8; i++) {
        printf("Error %u | ", i);
        printf("Address: %lx | ", GetErrorAddress());
        printf("Expected: %lx | ", GetExpectedData());
        printf("Actual: %lx \n", GetActualData());

        *((uint32_t *) ErrorControl.baseAddress) |= i << 8; // Set Error Index (EI)
    }

    return;
}

uint64_t VirtualTarget::GetErrorAddress() {
    uint64_t addr = 0;
    addr |= *((uint32_t *) ErrorUpperAddr.baseAddress);
    addr = addr << 32;
    addr |= *((uint32_t *) ErrorAddr.baseAddress);
    return addr;
}

uint32_t VirtualTarget::GetExpectedData() {
    return *((uint32_t *) ErrorExpectedData.baseAddress);
}

uint32_t VirtualTarget::GetActualData() {
    return *((uint32_t *) ErrorActualData.baseAddress);
}

/*
 * CambriaCard
 */

CambriaCard::CambriaCard(abstract_pci_info_t *pi) {
    char *mmrAddr, *bufferAddr, *targetAddr;
    unsigned int targetSize = pi->bar[4].size / VM_COUNT; 
    for (int i = 0; i < VM_COUNT; i++) {
        vm[i].index = i;
        vm[i].bufferBaseAddr = ((uint8_t *) pi->bar[0].virt_addr) + (i*0x20000);  // Offsets from Cambria-R base spec
        vm[i].mmr.baseAddress = ((uint8_t*) pi->bar[0].virt_addr) + 0xe5000 + (0x2000*i);
        vm[i].ErrorControl.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xe5020 + (0x2000*i);
        vm[i].ErrorLowerAddr.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xe5040 + (0x2000*i);
        vm[i].ErrorUpperAddr.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xe5044 + (0x2000*i);
        vm[i].ErrorActualData.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xe5048 + (0x2000*i);
        vm[i].ErrorExpectedData.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xe504c + (0x2000*i);

        vt[i].index = i;
        vt[i].targetBaseAddr = ((uint8_t *) pi->bar[4].virt_addr) + (i*targetSize);
        vt[i].targetBaseAddrPhys = pi->bar[4].phys_addr + (i*targetSize);
        vt[i].targetSize = targetSize;
        vt[i].ErrorControl.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xf1010 + (i*0x2000);
        vt[i].ErrorAddr.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xf1018 + (i*0x2000);
        vt[i].ErrorUpperAddr.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xf101c + (i*0x2000);
        vt[i].ErrorActualData.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xf1020 + (i*0x2000);
        vt[i].ErrorExpectedData.baseAddress = ((uint8_t *) pi->bar[0].virt_addr) + 0xf1024 + (i*0x2000);
        
    }
}


