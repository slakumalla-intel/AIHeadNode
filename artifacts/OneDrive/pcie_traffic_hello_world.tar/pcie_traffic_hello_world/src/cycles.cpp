/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2022 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details This file implements CambriaCycles methods

//#include "StandardRuntime/BigEndian.h" - STANDALONE
//#include "StandardRuntime/MaestroLog.h" - STANDALONE
//#include "StandardRuntime/LoggingIP.h" - STANDALONE
#include "cambria-datagen/cycles.h"
#include "cambria-registers/cambria_rnr_global_cfgRegs.h"
#include "cambria-registers/cambria_rnr_func0_cfgRegs.h"

//#define DBG(msg) MAESTRO_LOG_CATEGORY(IPs::PCIe, "cambria", "[Cambria] " << msg) - STANDALONE

using namespace cambria_rnr_global_cfg;
using namespace cambria_rnr_func0_cfg;

//MAESTRO_GLOBAL_CODE - STANDALONE
void CambriaCycle::Serialize(VectorFormat *base, unsigned *offset)
{
	// Save the vector offset

	m_offset = *offset;
	//DBG("Saving offset: " << *offset << endl); - STANDALONE
	//DBG("Saved offset: " << m_offset << endl); - STANDALONE

	// Write vector data by dword
	base[*offset].dword0 = m_format.dword0;
	base[*offset].dword1 = m_format.dword1;
	base[*offset].dword2 = m_format.dword2;
	base[*offset].dword3 = m_format.dword3;

	// Increment the pointer
	(*offset)++;
}

void CambriaCycle::LogCycle()
{
	//LOG_INFO(m_format.dword0 << " " << m_format.dword1 << " " << m_format.dword2 << " " << m_format.dword3 << endl); - STANDALONE
	return;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PauseVector::PauseVector(enum PauseVector::PauseType pauseType, enum PauseVector::PmPauseType pmPauseType,
    enum PauseVector::PmPauseType2 pmPauseType2, uint16_t delay, Granularity gran)
    : CambriaCycle(VectorType::Pause)
{
	SetPauseType(pauseType);
	SetPmPauseType(pmPauseType);
	SetPmPauseType2(pmPauseType2);
	SetDelay(delay, gran);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void PauseVector::SetDelay(uint16_t count, Granularity gran)
{
	m_pause->delayCount = count;
	m_pause->gran = static_cast<unsigned>(gran);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
LoopStart::LoopStart(uint8_t count) : LoopVector()
{
	SetCount(count);
	SetEnd();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
LoopEnd::LoopEnd() : LoopVector()
{
	SetCommand();
	SetEnd();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
SinglePollLoopStart::SinglePollLoopStart() { SetEnd(); }

//MAESTRO_GLOBAL_CODE - STANDALONE
SinglePollLoopEnd::SinglePollLoopEnd() { SetCommand(); }

//MAESTRO_GLOBAL_CODE - STANDALONE
void InternalAccess::ProgramCommandA(
    unsigned offset, uint32_t data, uint8_t be, LockBit lock, Retrigger retrigger, EndBit endbit)
{
	SetAddressA(offset);
	SetByteEnablesA(be);
	SetDataA(data);
	if (lock == LockBit::On) {
		SetLockA();
	}
	if (retrigger == Retrigger::On) {
		SetRetriggerA();
	}
	if (endbit == EndBit::On) {
		SetEndA();
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void InternalAccess::ProgramCommandB(
    unsigned offset, uint32_t data, uint8_t be, LockBit lock, Retrigger retrigger, EndBit endbit)
{
	SetAddressB(offset);
	SetByteEnablesB(be);
	SetDataB(data);
	if (lock == LockBit::On) {
		SetLockB();
	}
	if (retrigger == Retrigger::On) {
		SetRetriggerB();
	}
	if (endbit == EndBit::On) {
		SetEndB();
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void InternalAccess::SetAddressA(unsigned addr)
{
	m_internalaccess->a16 = (addr >> 16) & 0x1;
	m_internalaccess->address = (addr >> 2) & 0x3FFF;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void InternalAccess::SetAddressB(unsigned addr)
{
	m_internalaccess->b16 = (addr >> 16) & 0x1;
	m_internalaccess->bAddress = (addr >> 2) & 0x3FFF;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void InternalAccess::SetCmd(Command cmd)
{
	m_internalaccess->cmd = static_cast<unsigned>(cmd);
	if ((cmd == Command::IntSinglePollNotSticky) || (cmd == Command::InternalSinglePollLocalSticky)) {
		m_internalaccess->endA = 1;
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void InternalAccess::SetDataB(uint32_t value)
{
	m_internalaccess->bdataLower = value & 0xffff;
	m_internalaccess->bdataUpper = (value >> 16) & 0xffff;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void InternalAccess::SetSinglePoll(enum SinglePollType type)
{
	m_internalaccess->ip = type & SinglePollType::Internal ? 1 : 0;
	m_internalaccess->ps = type & SinglePollType::PMEStatusZero ? 1 : 0;
	m_internalaccess->to = type & SinglePollType::PMETurnOff ? 1 : 0;
	m_internalaccess->dx = type & SinglePollType::NotInD0 ? 1 : 0;
	m_internalaccess->d0 = type & SinglePollType::InD0 ? 1 : 0;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
DummyVector::DummyVector(uint32_t data, LockBit lock, EndBit endbit)
{
	SetAddressA(UPDREG3::cfg_offset());
	SetAddressB(UPDREG3::cfg_offset());
	SetByteEnablesA(0xF);
	SetByteEnablesB(0xF);
	SetDataA(data);
	SetDataB(data);
	if (lock == LockBit::On) {
		SetLockA();
		SetLockB();
	}
	if (endbit == EndBit::On) {
		SetEndA();
		SetEndB();
	}

	SetCmd(InternalAccess::Command::WriteToReg);
}

IntAccessWriteReg::IntAccessWriteReg() { SetCmd(InternalAccess::Command::WriteToReg); }

IntAccessWriteReg::IntAccessWriteReg(
    unsigned offset, uint32_t data, uint8_t be, LockBit lock, Retrigger retrigger, EndBit endbit)
{
	SetCmd(InternalAccess::Command::WriteToReg);

	// RNR port logic registers are at 0x140000.
	if (offset > 0x140000) {
		offset -= 0x140000;
		SetAddressRange();
	}

	ProgramCommandA(offset, data, be, lock, retrigger, endbit);
	ProgramCommandB(offset, data, be, lock, retrigger, endbit);
}

SetRegisterBits::SetRegisterBits(unsigned offset, uint32_t mask, LockBit lock, EndBit endbit)
{
	// Calculate byte enable based on bitmask
	uint8_t be = 0xF;
	if (mask & 0x000000FF) {
		be &= 0xE;
	}
	if (mask & 0x0000FF00) {
		be &= 0xD;
	}
	if (mask & 0x00FF0000) {
		be &= 0xB;
	}
	if (mask & 0xFF000000) {
		be &= 0x7;
	}

	SetCmd(InternalAccess::Command::WriteToReg);
	ProgramCommandA(offset, mask, be, lock, Retrigger::Off, endbit);
	ProgramCommandB(offset, mask, be, lock, Retrigger::Off, endbit);
}

SetRegisterBit::SetRegisterBit(unsigned offset, uint32_t bitpos, LockBit lock, EndBit endbit)
{
	uint32_t data = 1 << bitpos;

	// Calculate byte enable based on bitmask
	uint8_t be = 0xF;
	if (bitpos < 8) {
		be &= 0xE;
	} else if (bitpos < 16) {
		be &= 0xD;
	} else if (bitpos < 24) {
		be &= 0xB;
	} else if (bitpos < 32) {
		be &= 0x7;
	}

	SetCmd(InternalAccess::Command::WriteToReg);
	ProgramCommandA(offset, data, be, lock, Retrigger::Off, endbit);
	ProgramCommandB(offset, data, be, lock, Retrigger::Off, endbit);
}

ClearRegisterBit::ClearRegisterBit(unsigned offset, uint32_t bitpos, LockBit lock, EndBit endbit)
{
	// Calculate byte enable based on bitmask
	uint8_t be = 0xF;
	if (bitpos < 8) {
		be &= 0xE;
	} else if (bitpos < 16) {
		be &= 0xD;
	} else if (bitpos < 24) {
		be &= 0xB;
	} else if (bitpos < 32) {
		be &= 0x7;
	}

	SetCmd(InternalAccess::Command::WriteToReg);
	ProgramCommandA(offset, 0, be, lock, Retrigger::Off, endbit);
	ProgramCommandB(offset, 0, be, lock, Retrigger::Off, endbit);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
ReadCfgToSticky::ReadCfgToSticky(unsigned offset, uint8_t be, LockBit lock)
{
	SetAddressA(offset);
	SetAddressB(offset);
	SetByteEnablesA(be);
	SetByteEnablesB(be);
	if (lock == LockBit::On) {
		SetLockA();
		SetLockB();
	}
	// SetSinglePoll(SinglePollType::LocalSticky); // Not sure this is needed but SVOS had it
	SetCmd(InternalAccess::Command::ReadCfgRegToLocalSticky);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
WriteCfgFromSticky::WriteCfgFromSticky(unsigned offset, uint8_t be, LockBit lock)
{
	SetAddressA(offset);
	SetAddressB(offset);
	SetByteEnablesA(be);
	SetByteEnablesB(be);
	if (lock == LockBit::On) {
		SetLockA();
		SetLockB();
	}
	SetCmd(InternalAccess::Command::WriteToCfgFromLocalSticky);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PollSingle::PollSingle(enum SinglePollType type)
{
	SetCmd(Command::IntSinglePollNotSticky);
	SetSinglePoll(type);
	SetEndA();
	SetLockA();
	SetLockB();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PollSingleLocalSticky::PollSingleLocalSticky(uint32_t compare, uint32_t mask)
{
	SetCmd(Command::InternalSinglePollLocalSticky);
	SetDataA(compare);
	SetDataB(mask);
	SetEndA();
	SetLockA();
	SetLockB();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
DelayVector::DelayVector(uint16_t count, Granularity gran, uint16_t signal) : CambriaCycle(VectorType::Delay)
{
	SetDelay(count, gran);
	SetSignal(signal);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void DelayVector::SetDelay(uint16_t count, Granularity gran)
{
	m_delay->delayCount = count;
	m_delay->gran = static_cast<unsigned>(gran);
}

void DelayVector::SetSignal(uint16_t signal) { m_delay->extSignal.signal = signal; }

//MAESTRO_GLOBAL_CODE - STANDALONE
void UpperAddressVector::SetAltRouting(const uint8_t bus, const uint8_t number)
{
	m_upperaddress->busNum = bus;
	m_upperaddress->devNum = (number >> 3) & 0x1F;
	m_upperaddress->funcNum = number & 0x7;
	m_upperaddress->pattGenAddr = 0;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void UpperAddressVector::SetRequestorId(unsigned busNum, unsigned devNum, unsigned funcNum)
{
	m_upperaddress->busNum = busNum;
	m_upperaddress->devNum = devNum;
	m_upperaddress->funcNum = funcNum;
	m_upperaddress->pattGenAddr = 0;
}

void UpperAddressVector::LogCycle()
{
// In the ARAM image the physical address will be updated to the actual physical address by a fixup. The CambriaCycle
// class will not be updated, so we have to grab the address directly from the memory target.
#ifdef ENV_METAL
	// Physical address is not known at compile-time
// if (!maestro::IsCompileTime())
#endif
	{
		// Upper 32 bits of physical address.
		//	m_upperaddress->address = (m_targetBuffer->PhysicalAddress() >> 32);
	}

	CambriaCycle::LogCycle();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PMVector::PMVector(PMVector::Command cmd, LockBit lock, BusMasterOverride bmo)
    : CambriaCycle(VectorType::PowerManagement)
{
	SetCommand(cmd);

	if (lock == LockBit::On) {
		SetLock();
	}

	if (bmo == BusMasterOverride::On) {
		SetBusMasterOverride();
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
GenericSuperLock::GenericSuperLock(bool enter, EndBit endbit)
    : PMVector(Command::GenericSuperLock, (enter ? LockBit::On : LockBit::Off))
{
	if (endbit == EndBit::On) {
		SetEnd();
	}
}

PciPmSuperLock::PciPmSuperLock(bool enter, EndBit endbit)
    : PMVector(Command::PciPmSuperLock, (enter ? LockBit::On : LockBit::Off))
{
	if (endbit == EndBit::On) {
		SetEnd();
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
AspmSuperLock::AspmSuperLock(bool enter, EndBit endbit)
    : PMVector(Command::AspmSuperLock, (enter ? LockBit::On : LockBit::Off))
{
	if (endbit == EndBit::On) {
		SetEnd();
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MemoryVector::SetNextFDBE(unsigned next)
{
	if ((next != static_cast<unsigned>(NextByteEnable::Constant)) && (GetLength() >= 2)) {
		m_memory->nbef = static_cast<unsigned>(NextByteEnable::Shift);
	} else {
		m_memory->nbef = next;
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MemoryVector::SetNextLDBE(unsigned next)
{
	if ((next != static_cast<unsigned>(NextByteEnable::Constant)) && (GetLength() >= 2)) {
		m_memory->nbel = static_cast<unsigned>(NextByteEnable::Shift);
	} else {
		m_memory->nbel = next;
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MemoryVector::SetLength(unsigned len)
{
	if (len == 0) {
		m_memory->length = 0;
		m_sizeInBytes = 0;
		SetZeroLength();
		SetFirstBE(0);
		SetLastBE(0);
		return;
	}

	if (len == 1) {
		SetLastBE(0);
		if (GetFirstBE() == 0) {
			m_memory->length = 0;
			m_sizeInBytes = 0;
			SetZeroLength();
			return;
		}
	}

	m_memory->z = 0;
	m_memory->length = len - 1;
	m_sizeInBytes = len * 4;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MemoryVector::SetAddress(uint64_t address)
{
	SetLowAddress(address & 0xFFFFFFFF);
	GetUpperAddress().SetHighAddress((address >> 32) & 0xFFFFFFFF);
}

void MemoryVector::SetAltRouting(const uint8_t bus, const uint8_t number)
{
	m_memory->reqID = 1;

	GetUpperAddress().SetAltRouting(bus, number);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MemoryVector::Serialize(VectorFormat *base, unsigned *offset)
{
	// Serialize the Upper Address first
	m_upperAddr.Serialize(base, offset);

	// Call the base class to serialize our raw data
	CambriaCycle::Serialize(base, offset);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MemoryVector::CalcTotalTransferLength()
{
	unsigned repeats = GetRepeat();
	unsigned length = 0;
	unsigned len = GetLength() - 1;
	unsigned addrAdv = GetAddressAdvance();

	for (unsigned r = 0; r <= repeats; r++) {
		if (r == repeats) {
			length += ((len + 1) * sizeof(uint32_t));
			break;
		}

		length += (((len + 1) * sizeof(uint32_t)) + (addrAdv * sizeof(uint32_t)));

		UpdateNextAddressAdvance(addrAdv);
		UpdateNextLength(len);
	}

	m_sizeInBytes = length;
}

//__attribute__((optnone))
void MemoryVector::UpdateNextFeatures(unsigned r, uint8_t &fbe, uint8_t &lbe, unsigned &addrAdv, unsigned &length)
{
	UpdateNextAddressAdvance(addrAdv);
	UpdateNextLength(length);
	UpdateNextFBE(r, fbe);
	UpdateNextLBE(r, lbe);
}

void MemoryVector::UpdateNextAddressAdvance(unsigned &addrAdv)
{
	// change the address advance based on the next addr adv
	const unsigned naa = GetNextAddressAdvance();
	if (naa == static_cast<unsigned>(NextFeatures::Increment)) {
		addrAdv = ((addrAdv + 1) & 0x3ff);
	} else if (naa == static_cast<unsigned>(NextFeatures::Decrement)) {
		if (addrAdv == 0) {
			addrAdv = 1023;
		} else {
			addrAdv--;
		}
	}
}

void MemoryVector::UpdateNextLength(unsigned &length)
{
	// change the length based on next length
	const unsigned nl = GetNextLength();
	if (nl == static_cast<unsigned>(NextFeatures::Increment)) {
		length = ((length + 1) & 0x3ff);
	} else if (nl == static_cast<unsigned>(NextFeatures::Decrement)) {
		if (length == 0) {
			length = 1023;
		} else {
			length--;
		}
	}
}

void MemoryVector::UpdateNextFBE(unsigned r, uint8_t &fbe)
{
	// change the first BE based on nfbe
	const unsigned nfbe = GetNextFDBE();
	const uint8_t ofbe = ~GetFirstBE() & 0xF; // invert byte enables for cambria encoding

	if (nfbe == static_cast<unsigned>(NextByteEnable::Increment)) {
		fbe = ((fbe + 1) & 0xf);
	} else if (nfbe == static_cast<unsigned>(NextByteEnable::Shift)) {
		// the fbe returns to the orginal value every 4 repeats
		if (((r + 1) % 4) == 0) {
			switch (ofbe) {
				case 0x5:
				case 0x9:
				case 0xD:
					fbe = 0x1;
					break;
				case 0x2:
				case 0x4:
				case 0x6:
				case 0x8:
				case 0xA:
				case 0xC:
				case 0xE:
					fbe = 0x0;
					break;
				case 0xB:
					fbe = 0x3;
					break;
				case 0xf:
					fbe = 0x7;
					break;
				default:
					fbe = (ofbe & 0xf);
					break;
			}
		} else {
			fbe = ~((~(fbe)&0xf) << 1) & 0xf;
			if (fbe == 0xf) {
				fbe = 0x0;
			}
		}
	} else if (nfbe == static_cast<unsigned>(NextByteEnable::Invert)) {
		fbe = (~(fbe)&0xf);
	}
}

void MemoryVector::UpdateNextLBE(unsigned r, uint8_t &lbe)
{
	// change the last BE based on nlbe
	const unsigned nlbe = GetNextLDBE();
	uint8_t olbe = ~GetLastBE() & 0xF; // invert byte enables for cambria encoding

	if (nlbe == static_cast<unsigned>(NextByteEnable::Increment)) {
		lbe = ((lbe + 1) & 0xf);
	} else if (nlbe == static_cast<unsigned>(NextByteEnable::Shift)) {
		// the lbe returns to the orginal value every 4 repeats
		if (((r + 1) % 4) == 0) {
			switch (olbe) {
				case 0x1:
				case 0x2:
				case 0x3:
				case 0x4:
				case 0x5:
				case 0x6:
				case 0x7:
					lbe = 0;
					break;
				case 0x9:
				case 0xA:
				case 0xB:
					lbe = 0x8;
					break;
				case 0xD:
					lbe = 0xC;
					break;
				case 0xF:
					lbe = 0xE;
					break;
				default:
					lbe = (olbe & 0xf);
					break;
			}
		} else {
			lbe = ~((~(lbe)&0xf) >> 1) & 0xf;
			if (lbe == 0xf) {
				lbe = 0x0;
			}
		}
	} else if (nlbe == static_cast<unsigned>(NextByteEnable::Invert)) {
		lbe = (~(lbe)&0xf);
	}
}

void MemoryVector::LogCycle()
{
	// Log UAV (not a separate entry in vector container)
	GetUpperAddress().LogCycle();

// In the ARAM image the physical address will be updated to the actual physical address by a fixup. The CambriaCycle
// class will not be updated, so we have to grab the address directly from the memory target.
#ifdef ENV_METAL
	// Physical address is not known at compile-time
// if (!maestro::IsCompileTime())
#endif
	{
		// Lower 32 bits of physical address. Mask off two bottom bits because Cambria uses dword addresses
		// m_memory->address = ((m_targetBuffer->PhysicalAddress() & 0xFFFF'FFFF) >> 2);
		// Check if UAV is needed (address greater 4GB)
		// m_memory->addr64 = (m_targetBuffer->PhysicalAddress() >= 0x1'000'000);
	}

	CambriaCycle::LogCycle();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
AtomicData::AtomicData()
{
	m_data.m_LowerData = 0;
	m_data.m_UpperData = 0;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
AtomicData::AtomicData(uint64_t lowerData, uint64_t upperData)
{
	m_data.m_LowerData = lowerData;
	m_data.m_UpperData = upperData;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
AtomicVector::AtomicVector(
    const AtomicOpType type, const unsigned length, const AtomicData &operand, const AtomicData &compare)
    : MemReadVector(length), m_operand(operand), m_compare(compare), m_pauseOnTag(PauseVector::PauseType::TaggedVector)
{
	SetAtomicOp(type);
	SetAtomicIndex(0); // TODO: Decide how to manage different indexes
	SetTag();

	// Now that we know the operation, call set length for atomics specific handling
	SetLength(length);
	ClearByteEnables();

	CreateSequence(length);
	CalculateVerify(length);
}

AtomicVector::~AtomicVector()
{
	for (auto cycle : m_sequence) {
		delete cycle;
	}
}

int AtomicVector::GetCount()
{
	int count = m_pauseOnTag.GetCount();
	for (unsigned i = 0; i < m_sequence.size(); i++) {
		count += m_sequence[i]->GetCount();
	}

	return count + MemoryVector::GetCount();
}

void AtomicVector::SetLength(unsigned len)
{
	if (GetAtomicOp() == AtomicOpType::CAS) {
		m_memory->length = (len * 2) - 1;
		m_sizeInBytes = len * 4;
		return;
	}
	m_memory->length = len - 1;
	m_sizeInBytes = len * 4;
}

unsigned AtomicVector::GetLength()
{
	if (GetAtomicOp() == AtomicOpType::CAS) {
		return (m_sizeInBytes / 4);
	} else {
		return MemoryVector::GetLength();
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void AtomicVector::CreateSequence(unsigned lengthInDwords)
{
	unsigned atomicIndex = GetAtomicIndex();

	// Create init sequence
	for (unsigned reg = 0; reg < lengthInDwords; reg++) {

		// Set Operand
		m_sequence.push_back(new IntAccessWriteReg(
		    0x2000 + ATMDATAOPDW0R0::mmio_offset() + (atomicIndex * 0x20) + (reg * 4), m_operand.m_data.dwords[reg], 0));

		// Set Compare
		m_sequence.push_back(
		    new IntAccessWriteReg(0x2000 + ATMDATACMPDW0R0::mmio_offset() + (atomicIndex * 0x20) + (reg * 4),
		        m_compare.m_data.dwords[reg], 0));
	}

	// Insert dummies
	m_sequence.push_back(new DummyVector(0x12345678));
	m_sequence.push_back(new DummyVector(0x12345678));
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void AtomicVector::CalculateVerify(unsigned lengthInDwords)
{
	if (GetAtomicOp() == AtomicOpType::FetchAdd) {
		if (lengthInDwords == 1) {
			m_verify.m_data.dwords[0] = m_compare.m_data.dwords[0] + m_operand.m_data.dwords[0];
		} else {
			m_verify.m_data.m_LowerData = m_compare.m_data.m_LowerData + m_operand.m_data.m_LowerData;
		}
	} else {
		m_verify.m_data.m_LowerData = m_operand.m_data.m_LowerData;
		m_verify.m_data.m_UpperData = m_operand.m_data.m_UpperData;
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void AtomicVector::Serialize(VectorFormat *base, unsigned *offset)
{
	// Serialize the init sequence
	for (unsigned i = 0; i < m_sequence.size(); i++) {
		m_sequence[i]->Serialize(base, offset);
	}

	// Serialize the UA/MemRead vectors
	MemoryVector::Serialize(base, offset);

	// Add the pause on tag
	m_pauseOnTag.Serialize(base, offset);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
IoVector::IoVector(const VectorType type) : CambriaCycle(type) {}

//MAESTRO_GLOBAL_CODE - STANDALONE
ConfigVector::ConfigVector(const VectorType type, unsigned bus, unsigned device, unsigned function, unsigned offset)
    : CambriaCycle(type)
{
	SetBus(bus);
	SetDevice(device);
	SetFunction(function);
	SetOffset(offset);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void ConfigVector::SetOffset(unsigned offset)
{
	m_config->regNum = (offset & 0xFF) >> 2;
	m_config->extRegAddr = (offset >> 8) & 0xf;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
MessageVector::MessageVector(const MsgCode code, const enum MsgRoute route, LockBit lock, BusMasterOverride bmo)
    : CambriaCycle(VectorType::Message)
{
	SetCode(code);
	SetRoute(route);

	if (lock == LockBit::On) {
		SetLock();
	}

	if (bmo == BusMasterOverride::On) {
		SetBusMasterOverride();
	}
}

MessageVector::~MessageVector()
{
	if (m_upperAddr) {
		delete m_upperAddr;
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MessageVector::Serialize(VectorFormat *base, unsigned *offset)
{
	// Serialize the upper address vector if necessary
	if (m_upperAddr) {
		m_upperAddr->Serialize(base, offset);
	}

	// Call the base class to serialize our raw data
	CambriaCycle::Serialize(base, offset);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
UpperAddressVector *MessageVector::GetOrCreateUpperAddress()
{
	if (!m_upperAddr) {
		m_upperAddr = new UpperAddressVector();
	}

	return m_upperAddr;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MessageVector::SetLength(unsigned len)
{
	if (len == 0) {
		return;
	}

	m_message->length = len - 1;
	SetWithData();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
MsgRoute MessageVector::GetRoute() { return static_cast<MsgRoute>(m_message->route); }

//MAESTRO_GLOBAL_CODE - STANDALONE
void MessageVector::SetRoute(enum MsgRoute route) { m_message->route = static_cast<unsigned>(route); }

bool MessageVector::IsVDM() { return (GetCode() == 0x7E) || (GetCode() == 0x7F); }

void MessageVector::SetDestinationID(uint16_t id)
{
	uint32_t val = GetHeaderDword2();
	val &= 0xFFFF; // Clear out any existing data

	if (GetRoute() == MsgRoute::ID) {
		val |= (id << 16);
	}

	SetHeaderDword2(val);
}

void MessageVector::SetVendorID(uint16_t id)
{
	uint32_t val = GetHeaderDword2();
	val &= 0xFFFF0000; // Clear out any existing data
	val |= id;
	SetHeaderDword2(val);
}

void MessageVector::SetVendorDef(uint32_t def) { SetHeaderDword3(def); }

void MessageVector::SetHeaderDword3(uint32_t dword3)
{
	m_message->address = dword3 >> 2;
	m_message->addrLow = dword3 & 0x3;
}

LtrMessageVector::LtrMessageVector(uint32_t ltrVal) : MessageVector(MsgCode::LatencyToleranceReport, MsgRoute::Local)
{
	SetHeaderDword3(ltrVal);
}

//MAESTRO_GLOBAL_CODE - STANDALONE
MctpMessageVector::MctpMessageVector(const MsgRoute route) : MessageVector(MsgCode::VendorDefinedType1, route)
{
	SetMP();
	SetNoSnoop();

	// Set Vendor ID = DMTF for MCTP
	SetHeaderDword2(VendorIdDmtfVdms);

	SetDataPattern(0x2); // only analog pattern works for message
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MctpMessageVector::SetPciTargetId(uint16_t target, MsgRoute route)
{
	if (MsgRoute::ID == route) {
		uint32_t dword2 = GetHeaderDword2();
		dword2 &= 0x0000FFFF;
		SetHeaderDword2(dword2 | ((target & 0xFFFF) << 16));
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void MctpMessageVector::SetMctpTransportHeader(
    uint8_t dstEpId, uint8_t srcEpId, uint8_t som, uint8_t eom, uint8_t pktSeqNum, uint8_t to, uint8_t msgTag)
{
	// Set Cambria Message Vector Address with MCTP Packet bytes 12:15 (big endian)
	uint32_t mctpTransportHeader = MctpHdrVer | ((dstEpId & 0xFF) << 8) | ((srcEpId & 0xFF) << 16) |
	                               ((som & 0x1) << 31) | ((eom & 0x1) << 30) | ((pktSeqNum & 0x3) << 28) |
	                               ((to & 0x1) << 27) | (msgTag & 0x7);

	// Reverse bytes from big endian
	MessageVector::SetHeaderDword3(mctpTransportHeader);
	//MessageVector::SetHeaderDword3(SwapBytes(mctpTransportHeader)); - STANDALONE
}
