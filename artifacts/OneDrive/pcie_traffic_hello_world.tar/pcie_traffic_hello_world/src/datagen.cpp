/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2021 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details This file implements CambriaDataGen methods

#include "cambria-datagen/datagen.h"

//#include "StandardRuntime/MaestroLog.h" - STANDALONE

#include "cambria-registers/cambria_rnr_global_cfgRegs.h"
#include "cambria-registers/cambria_rnr_func0_cfgRegs.h"

//#define DBG LOG("CambriaDataGen") << "[CambriaDataGen] " - STANDALONE

using namespace cambria_rnr_global_cfg;
using namespace cambria_rnr_func0_cfg;

//MAESTRO_GLOBAL_CODE - STANDALONE
Stream::Stream(unsigned maxVectors) : m_maxVectors(maxVectors) {}

Stream::~Stream()
{
	for (auto cycle : m_cycles) {
		delete cycle;
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
bool Stream::CheckSpace(unsigned count)
{
	if ((m_numVectors + count) > m_maxVectors) {
		return false;
	}

	return true;
}

//MAESTRO_GLOBAL_CODE - STANDALONE
CambriaCycle *Stream::AddCycle(CambriaCycle *cyc, bool checkSpace)
{
	if (!cyc) {
		// LOG_ERROR("Cycle pointer is NULL"); - STANDALONE
	}

	if (checkSpace && !CheckSpace(cyc->GetCount())) {
		return nullptr;
	}

	m_numVectors += cyc->GetCount();
	m_cycles.push_back(cyc);
	return cyc;
}

void Stream::Serialize(uint32_t *buffer)
{
	if (buffer == nullptr) {
		// LOG_FATAL("Pointer to ARAM buffer is NULL.  Unable to serialize vector stream" << endl); - STANDALONE
	}

	//DBG << "Stream Vector size: " << m_cycles.size() << endl; - STANDALONE
	//DBG << "Stream Vector count: " << m_numVectors << endl; - STANDALONE

	if (!HasCycles()) {
		return;
	}

	unsigned offset = 0;
	VectorFormat *aramPtr = reinterpret_cast<VectorFormat *>(buffer);
	for (const auto &cyc : m_cycles) {
		cyc->Serialize(aramPtr, &offset);
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
TrafficStream::TrafficStream(unsigned maxVectors) : Stream(maxVectors) {}

//MAESTRO_GLOBAL_CODE - STANDALONE
EventStream::EventStream(unsigned maxVectors) : Stream(maxVectors) {}

//MAESTRO_GLOBAL_CODE - STANDALONE
void EventStream::ClearEventStatus()
{
	PMCTRL1::format pmctrl1{};
	pmctrl1.GPMPMECC = 1; // Global PM_PME Status Single Poll Continue Counter
	pmctrl1.GPMETOCC = 1; // Global PME_Turn_Off TLP in D3 Single Poll Continue Counter
	pmctrl1.GPMRACC = 1;  // Global PM_Request_Ack DLLP Single Poll Continue Counter
	AddCycle(new IntAccessWriteReg(PMCTRL1::mmio_offset() + 0x2000, pmctrl1.val, 0xD, LockBit::On));

	PMCTRL4::format pmctrl4{};
	pmctrl4.GCCSE = 1; // GCCSE for Pause on Valid D-State Change in Non-D0
	AddCycle(new IntAccessWriteReg(PMCTRL4::mmio_offset() + 0x2000, pmctrl4.val, 0xD, LockBit::On));

	PMPSECTRL::format pmpsectrl{};
	// pmpsectrl.GPMRADLLPCCC = 1; // (Reserved) Global PM_Req_Ack DLLP Status Pause Continue Counter Clear
	pmpsectrl.GPMASNCCC = 1;   // Global PM_Active_State_Nak Msg Status Pause Continue Counter Clear
	pmpsectrl.GPMPMECCC = 1;   // Global PM_PME Status Pause Continue Counter Clear
	pmpsectrl.GPMTOMD3CCC = 1; // Global PM_Turn_Off Msg Status in D3 Pause Continue Counter Clear
	pmpsectrl.GRECCC = 1;      // Global Recovery Entry Pause Countinue Counter Clear
	AddCycle(new IntAccessWriteReg(PMPSECTRL::mmio_offset() + 0x2000, pmpsectrl.val, 0xD, LockBit::On));
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void EventStream::InsertPollForLTSSM(uint32_t state, uint32_t mask)
{
	// Loop until we hit the requested link state
	AddCycle(new SinglePollLoopStart());

	// Read Current LTSSM State into local sticky (23:16)
	AddCycle(new ReadCfgToSticky(LNKSTSREG::mmio_offset() + 0x2000, 0, LockBit::On));

	// Insert 2 dummy vectors
	AddCycle(new DummyVector(0x12345678));
	AddCycle(new DummyVector(0x12345678));

	// End single poll loop
	AddCycle(new SinglePollLoopEnd());

	// Local Sticky Data matches
	AddCycle(new PollSingleLocalSticky(state, mask));
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void EventStream::InsertDebugVectors(uint8_t value)
{
	if (!GetPortTrace()) {
		return;
	}

	uint16_t extVal = 0;
	uint16_t signal = 0;
	uint8_t highVal = (value >> 4) & 0x0F;
	uint8_t lowVal = (value >> 0) & 0x0F;
	const uint8_t vectStartBit = 4;

	for (int bitpos = 0; bitpos < 4; bitpos++) {
		if (highVal & (1 << bitpos)) {
			// b0 = 0x01 -> 0x01
			// b1 = 0x02 -> 0x04
			// b2 = 0x04 -> 0x10
			// b3 = 0x08 -> 0x40
			extVal |= (1 << (2 * bitpos));
		}
		// set valid bit for every bit
		if (1) {
			// if (VBPM_DEBUG_VECT_SET_VALID_BIT) {
			extVal |= (2 << (2 * bitpos));
		}
	}
	signal = extVal << (2 * vectStartBit);
	AddCycle(new DelayVector(3, Granularity::_8nsPerTick, signal));

	extVal = 0;
	for (int bitpos = 0; bitpos < 4; bitpos++) {
		if (lowVal & (1 << bitpos)) {
			// b0 = 0x01 -> 0x01
			// b1 = 0x02 -> 0x04
			// b2 = 0x04 -> 0x10
			// b3 = 0x08 -> 0x40
			extVal |= (1 << (2 * bitpos));
		}
		// set valid bit for every bit
		if (1) {
			//        if (VBPM_DEBUG_VECT_SET_VALID_BIT) {
			extVal |= (2 << (2 * bitpos));
		}
	}
	signal = extVal << (2 * vectStartBit);
	AddCycle(new DelayVector(3, Granularity::_8nsPerTick, signal));

	// now send zero...
	signal = 0x00AA << (2 * vectStartBit);
	AddCycle(new DelayVector(3, Granularity::_8nsPerTick, signal));
}

//MAESTRO_GLOBAL_CODE - STANDALONE
void EventStream::DisableTxL0s() { /*LOG_WARN("Not implemented" << endl);*/ }

//MAESTRO_GLOBAL_CODE - STANDALONE
void EventStream::RestoreTxL0s() { /*LOG_WARN("Not implemented" << endl);*/ }

void EventStream::InsertSwitchToLocalClock() { /*LOG_WARN("Not implemented" << endl);*/ }

void EventStream::InsertDeassertClockReq() { /*LOG_WARN("Not implemented" << endl);*/ }

void EventStream::InsertAssertClockReq() { /*LOG_WARN("Not implemented" << endl);*/ }

void EventStream::InsertSwitchToSlotClock() { /*LOG_WARN("Not implemented" << endl);*/ }

void EventStream::InsertErrorInjectSequence(EventStream::ErrorKind kind) { /*LOG_WARN("Not implemented" << endl);*/ }

void EventStream::TagVectorSent() { /*LOG_WARN("Not implemented" << endl);*/ }

//MAESTRO_GLOBAL_CODE - STANDALONE
ActiveL1TransitionEvent::ActiveL1TransitionEvent(unsigned vm, unsigned maxVectors) : EventStream(maxVectors)
{
	m_vm = vm;
}

void ActiveL1TransitionEvent::Generate()
{
	//DBG << "Generating ActiveL1TransitionEvent vector flow" << endl; - STANDALONE

	AddCycle(new AspmSuperLock(true));

	// Increment generic counter 0
	AddCycle(new IntAccessWriteReg(GENCNTCTRL::mmio_offset() + 0x2000, 0x1, 0, LockBit::On));

	PMCTRL1::format pmctrl1{};
	pmctrl1.GL1ICS = 1;   // Command select for L1.Idle (0=A, 1=B)
	pmctrl1.GPMASNCC = 1; // Clear NAK continue counter
	AddCycle(new IntAccessWriteReg(PMCTRL1::mmio_offset() + 0x2000, pmctrl1.val, 0x9, LockBit::On));

	// Insert 2 dummy vectors
	AddCycle(new DummyVector(0x12345678));
	AddCycle(new DummyVector(0x12345678));

	// TODO: Add L0s->L1 property

	// Pause for L1 idle (Command B) or NAK (Command A)
	AddCycle(new PauseVector(PauseVector::PauseType::PauseNone, PauseVector::PmPauseType::PmActiveStateNakMsgTlpRcvd,
	    PauseVector::PmPauseType2::L1Idle));

	// Note: If we get stuck here because of RootPort bug (not responding and not entering L1)
	// Cambria will hang.  SW will need to check the NAK counter and use the emergency pause release

	// Abort flow on a NAK
	const uint32_t enddata = (0x4 | TrafficStream) << (TrafficVM * 3);
	IntAccessWriteReg *iaWrite = static_cast<IntAccessWriteReg *>(AddCycle(new IntAccessWriteReg()));
	iaWrite->ProgramCommandA(INTPSE::cfg_offset(), enddata, 0, LockBit::Off, Retrigger::Off, EndBit::On);
	iaWrite->ProgramCommandB(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::On);

	_createWakePause();

	// Exit L1
	AddCycle(new PMVector(PMVector::Command::ExitL1, LockBit::On, BusMasterOverride::On)); // toggle app_xfer_pending

	// for Cambria-W we may need to send a packet
	// TODO: see if we can trigger UFCP, Ack, or some Msg (PME)

	AddCycle(new AspmSuperLock(false));

	// Quit by triggering the caller
	AddCycle(new IntAccessWriteReg(INTPSE::cfg_offset(), enddata, 0, LockBit::Off, Retrigger::Off, EndBit::On));

	return;
}

void ActiveL1TransitionEvent::_createWakePause()
{
	PauseVector::PmPauseType pmPauseType =
	    ExitFromAspmL1Timer ? PauseVector::PmPauseType::PmWakeDelayTimerExpire : PauseVector::PmPauseType::PmPauseNone;
	PauseVector::PmPauseType2 pmPauseType2 = PauseVector::PmPauseType2::PmPause2None;
	if (GuaranteedDevExit) {
		// nothing added
	} else if (GuaranteedHostExit) {
		pmPauseType2 = (pmPauseType2 | PauseVector::PmPauseType2::L0);
	} else {
		pmPauseType = pmPauseType | PauseVector::PmPauseType::PmWakeDelayTimerExpire |
		              PauseVector::PmPauseType::CplToSend | PauseVector::PmPauseType::ErrMsgToSend;
		pmPauseType2 = (pmPauseType2 | PauseVector::PmPauseType2::L0);
	}

	if ((pmPauseType != PauseVector::PmPauseType::PmPauseNone) ||
	    (pmPauseType2 != PauseVector::PmPauseType2::PmPause2None)) {
		AddCycle(new PauseVector(
		    PauseVector::PauseType::PauseNone, pmPauseType, pmPauseType2, ExitPauseCount, ExitPauseGran));
	}
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PciPmBaseEvent::PciPmBaseEvent(unsigned maxVectors) : EventStream(maxVectors) {}

//MAESTRO_GLOBAL_CODE - STANDALONE
void PciPmBaseEvent::_DoPmeMessaging()
{
	//------------------------------------------------------------
	// Begin Top Loop
	//------------------------------------------------------------

	// Loop until PM_PME response or D0
	AddCycle(new SinglePollLoopStart());

	// Send PM_PME
	AddCycle(new MessageVector(MsgCode::PmPme, MsgRoute::RootComplex, LockBit::On, BusMasterOverride::On));

	// Insert 2 dummy vectors
	AddCycle(new DummyVector(0x12345678));
	AddCycle(new DummyVector(0x12345678));

	// Pause until resend timer expires or we receive
	// D0 (Command A), PM_PME_STATUS (Command B), PME_TurnOff (Command B)
	PauseVector::PmPauseType pmWakeDelayTimerPause = PmeResendTimerPauseCount()
	                                                     ? PauseVector::PmPauseType::PmWakeDelayTimerExpire
	                                                     : PauseVector::PmPauseType::PmPauseNone;
	AddCycle(new PauseVector(PauseVector::PauseType::PauseNone,
	    pmWakeDelayTimerPause | PauseVector::PmPauseType::PmPmeStatus | PauseVector::PmPauseType::D0State |
	        PauseVector::PmPauseType::PmTurnOffMsgTlpRcvdInD3,
	    PauseVector::PmPauseType2::PmPause2None, PmeResendTimerPauseCount(), PmeResendTimerPauseGran()));

	// End single poll loop
	AddCycle(new SinglePollLoopEnd());

	// Local Sticky Data matches
	AddCycle(new PollSingle(InternalAccess::SinglePollType::PMEStatusZero | InternalAccess::SinglePollType::InD0 |
	                        InternalAccess::SinglePollType::PMETurnOff));

	//------------------------------------------------------------
	// End Top Loop
	//------------------------------------------------------------

	// If we were placed in D0 continue, else quit
	IntAccessWriteReg *iaWrite = static_cast<IntAccessWriteReg *>(AddCycle(new IntAccessWriteReg()));
	iaWrite->ProgramCommandA(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::On);
	iaWrite->ProgramCommandB(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::Off, Retrigger::Off, EndBit::On);

	//------------------------------------------------------------
	// Begin Bottom Loop
	//------------------------------------------------------------

	// Loop until PM_PME response
	AddCycle(new SinglePollLoopStart());

	// Send PM_PME
	AddCycle(new MessageVector(MsgCode::PmPme, MsgRoute::RootComplex, LockBit::On, BusMasterOverride::On));

	// Insert 2 dummy vectors
	AddCycle(new DummyVector(0x12345678));
	AddCycle(new DummyVector(0x12345678));

	// Pause until we receive PM_PME_STATUS
	AddCycle(new PauseVector(PauseVector::PauseType::PauseNone, PauseVector::PmPauseType::PmPmeStatus));

	// End single poll loop
	AddCycle(new SinglePollLoopEnd());

	// Local Sticky Data matches
	AddCycle(new PollSingle(InternalAccess::SinglePollType::PMEStatusZero));

	//------------------------------------------------------------
	// End Bottom Loop
	//------------------------------------------------------------
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PciPmL1BaseEvent::PciPmL1BaseEvent(unsigned maxVectors) : PciPmBaseEvent(maxVectors) {}

//MAESTRO_GLOBAL_CODE - STANDALONE
void PciPmL1BaseEvent::_EnterL1()
{
	// TODO: Add L0s->L1 property

	// Stall PCIPM L1 entry as if the device were taking its sweet time
	// between seeing the write to D3 and when it actually responds with a request to enter L1
	AddCycle(new DelayVector(StallL1DStatePauseCount(), StallL1DStatePauseGran()));

	// pause for D0 (Command A) or L1 idle (Command B)
	AddCycle(new PauseVector(
	    PauseVector::PauseType::PauseNone, PauseVector::PmPauseType::D0State, PauseVector::PmPauseType2::L1Idle));

	// If we were placed in D0 quit, else continue
	IntAccessWriteReg *iaWrite = static_cast<IntAccessWriteReg *>(AddCycle(new IntAccessWriteReg()));
	iaWrite->ProgramCommandA(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::Off, Retrigger::Off, EndBit::On);
	iaWrite->ProgramCommandB(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::On);

	// Pause for L0 (Command A) or Timer Wake (Command B)
	PauseVector::PmPauseType pmWakeDelayTimerPause =
	    PmeTimerPauseCount() ? PauseVector::PmPauseType::PmWakeDelayTimerExpire : PauseVector::PmPauseType::PmPauseNone;
	AddCycle(new PauseVector(PauseVector::PauseType::PauseNone, pmWakeDelayTimerPause, PauseVector::PmPauseType2::L0,
	    PmeTimerPauseCount(), PmeTimerPauseGran()));

	// Exit L1
	AddCycle(new PMVector(PMVector::Command::ExitL1, LockBit::On, BusMasterOverride::On)); // toggle app_xfer_pending

	// if NOT_L1.IDLE/L0 (Not Timer wake), then exit with retrigger
	Retrigger retrig = RequestReentryToL1() ? Retrigger::On : Retrigger::Off;
	iaWrite = static_cast<IntAccessWriteReg *>(AddCycle(new IntAccessWriteReg()));
	iaWrite->ProgramCommandA(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::Off, retrig, EndBit::On);
	iaWrite->ProgramCommandB(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::On);

	// Unblock completions in ASPM/PCIPM
	// PMCTRL3::format pmctrl3{};
	// pmctrl3.UCW = 1;
	// AddCycle(new IntAccessWriteReg(PMCTRL3::mmio_offset() + 0x2000, pmctrl3.val, 0xD, LockBit::On));

	// Insert PME messaging loops
	_DoPmeMessaging();

	// Block completions in ASPM/PCIPM
	// pmctrl3.UCW = 0;
	// AddCycle(new IntAccessWriteReg(PMCTRL3::mmio_offset() + 0x2000, pmctrl3.val, 0xD, LockBit::On));

	// Release superlock
	AddCycle(new PciPmSuperLock(false, EndBit::On));
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PciPmL1TransitionEvent::PciPmL1TransitionEvent(unsigned maxVectors) : PciPmL1BaseEvent(maxVectors) {}

void PciPmL1TransitionEvent::Generate()
{
	//DBG << "Generate PciPmL1TransitionEvent vector flow" << endl; - STANDALONE

	// Grab superlock
	AddCycle(new PciPmSuperLock(true));

	// Increment generic counter 1
	AddCycle(new IntAccessWriteReg(GENCNTCTRL::mmio_offset() + 0x2000, 0x2, 0, LockBit::On));

	PMCTRL1::format pmctrl1{};
	pmctrl1.GL1ICS = 1; // Command select for L1.Idle (0=A, 1=B)
	AddCycle(new IntAccessWriteReg(PMCTRL1::mmio_offset() + 0x2000, pmctrl1.val, 0xB, LockBit::On));

	// Clear related event status bits
	ClearEventStatus();

	// Program Retrigger event event stream number
	if (RequestReentryToL1()) {
		PMCTRL3::format pmctrl3{};
		pmctrl3.REDT = RetriggerTimer();
		AddCycle(new IntAccessWriteReg(PMCTRL3::mmio_offset() + 0x2000, pmctrl3.val, 0x3, LockBit::On));

		uint32_t retr = (RetriggerStream() | 4) << (3 * m_vm);
		AddCycle(new IntAccessWriteReg(RETRIGEVENT::mmio_offset() + 0x2000, retr, 0, LockBit::On));
	}

	_EnterL1();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PciPmL1RetrigEvent::PciPmL1RetrigEvent(unsigned maxVectors) : PciPmL1BaseEvent(maxVectors) {}

void PciPmL1RetrigEvent::Generate()
{
	//DBG << "Generate PciPmL1RetrigEvent vector flow" << endl; - STANDALONE

	// Grab superlock
	AddCycle(new PciPmSuperLock(true));

	// Increment generic counter 2
	AddCycle(new IntAccessWriteReg(GENCNTCTRL::mmio_offset() + 0x2000, 0x4, 0, LockBit::On));

	PMCTRL1::format pmctrl1{};
	pmctrl1.GL1ICS = 1; // Command select for L1.Idle (0=A, 1=B)
	AddCycle(new IntAccessWriteReg(PMCTRL1::mmio_offset() + 0x2000, pmctrl1.val, 0xB, LockBit::On));

	// Clear related event status bits
	ClearEventStatus();

	// Check current D-State
	// D0 (Command A), Non-D0 (Command B)
	AddCycle(new PauseVector(
	    PauseVector::PauseType::PauseNone, PauseVector::PmPauseType::D0State | PauseVector::PmPauseType::NonD0State));

	// If we were placed in D0 quit, else continue
	IntAccessWriteReg *iaWrite = static_cast<IntAccessWriteReg *>(AddCycle(new IntAccessWriteReg()));
	iaWrite->ProgramCommandA(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::Off, Retrigger::Off, EndBit::On);
	iaWrite->ProgramCommandB(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::On);

	// Check for valid D-State change
	// Valid (Command A), Non-Valid (Command B)
	AddCycle(new PauseVector(PauseVector::PauseType::PauseNone,
	    PauseVector::PmPauseType::ValidDSateChangeInNonD0 | PauseVector::PmPauseType::ValidNoDStateChangeInNonD0));

	// Continue on valid change, else quit
	iaWrite = static_cast<IntAccessWriteReg *>(AddCycle(new IntAccessWriteReg()));
	iaWrite->ProgramCommandA(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::Off, Retrigger::Off, EndBit::On);
	iaWrite->ProgramCommandB(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::On);

	_EnterL1();
}

//MAESTRO_GLOBAL_CODE - STANDALONE
PciPmL23TransitionEvent::PciPmL23TransitionEvent(unsigned maxVectors) : PciPmBaseEvent(maxVectors) {}

void PciPmL23TransitionEvent::Generate()
{
	//DBG << "Generate PciPmL23TransitionEvent vector flow" << endl; - STANDALONE

	// Unblock Completions
	// PMCTRL3::format pmctrl3{};
	// pmctrl3.UCW = 1;
	// AddCycle(new IntAccessWriteReg(PMCTRL3::mmio_offset() + 0x2000, pmctrl3.val, 0xD, LockBit::On));

	// Change command selects for Cpl/ErrMsg to Send
	PMCTRL4::format pmctrl4{};
	pmctrl4.GEM = 1;   // Command select for Error Msg To Send (0=A, 1=B)
	pmctrl4.GCTS = 1;  // Command select for Cpl To Send (0=A, 1=B)
	pmctrl4.GND0P = 1; // Preserve default in byte 0
	pmctrl4.GNVDS = 1; // Preserve default in byte 0
	AddCycle(new IntAccessWriteReg(PMCTRL4::mmio_offset() + 0x2000, pmctrl4.val, 0xE, LockBit::On));

	// NOTE: in past we disabled TxL0s here to ensure we could transmit ENTER_L2, don't think we need this for SNPS

	// Grab superlock
	AddCycle(new PciPmSuperLock(true));

	// Increment generic counter 3
	AddCycle(new IntAccessWriteReg(GENCNTCTRL::mmio_offset() + 0x2000, 0x8, 0, LockBit::On));

	PauseVector *pause = static_cast<PauseVector *>(AddCycle(new PauseVector()));
	pause->SetWaitAllVmEmpty();

	AddCycle(new DelayVector(StallL23DStatePauseCount(), StallL23DStatePauseGran()));
	if (EnterL1InsteadOfL23) {
		//LOG_ERROR("Cambria cannot initiate L1 from event flow for EnterL1InsteadOfL23") - STANDALONE
		// AddCycle(new PMVector(PMVector::Command::EnterL1, LockBit::On, BusMasterOverride::On));
	} else {
		AddCycle(new PMVector(PMVector::Command::EnterL2L3, LockBit::On, BusMasterOverride::On));
	}

	// Clear related event status bits
	ClearEventStatus();

	// Set PERST# Mask (if L23_DYNAMIC_RESET_MASK_ENABLED)

	// NOTE: may need to figure out if/how to handle a "quick" L2
	AddCycle(new PauseVector(
	    PauseVector::PauseType::PauseNone, PauseVector::PmPauseType::PmPauseNone, PauseVector::PmPauseType2::L2Idle));
	/*
	    if (AssertClkReq) {
	        InsertSwitchToLocalClock();
	        InsertDeassertClockReq();
	        AddCycle(new DelayVector(ClkReqDeassertDelayCount, ClkReqDeassertDelayGran));
	    }
	*/
	// Pause for L0 (Command A) or Cpl/ErrMSg to Send (Command B) or Timer Wake (Command B)
	// L0 is safer for eidle exit than NotL2Idle because when PERST asserts we might not be in L2Idle
	PauseVector::PmPauseType pmWakeDelayTimerPause = WakeTimerPauseCount()
	                                                     ? PauseVector::PmPauseType::PmWakeDelayTimerExpire
	                                                     : PauseVector::PmPauseType::PmPauseNone;
	AddCycle(new PauseVector(PauseVector::PauseType::PauseNone,
	    pmWakeDelayTimerPause | PauseVector::PmPauseType::CplToSend | PauseVector::PmPauseType::ErrMsgToSend,
	    PauseVector::PmPauseType2::L0, WakeTimerPauseCount(), WakeTimerPauseGran()));
	/*
	    if (AssertClkReq) {
	        InsertAssertClockReq();s
	        AddCycle(new DelayVector(ClkReqAssertDelayCount, ClkReqAssertDelayGran));
	        InsertSwitchToSlotClock(); // how do we handle even later refclk ?
	    }
	*/
	// Block completions
	// pmctrl3.UCW = 0;
	// AddCycle(new IntAccessWriteReg(PMCTRL3::mmio_offset() + 0x2000, pmctrl3.val, 0xD, LockBit::On));

	// If we're in L0 exit, else continue
	IntAccessWriteReg *iaWrite = static_cast<IntAccessWriteReg *>(AddCycle(new IntAccessWriteReg()));
	iaWrite->ProgramCommandA(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::Off, Retrigger::On, EndBit::On);
	iaWrite->ProgramCommandB(UPDREG0::cfg_offset(), 0x12345678, 0xF, LockBit::On);

	// TRIG-IN (PERST#)
	AddCycle(new PMVector(PMVector::Command::AssertWakebPin, LockBit::On, BusMasterOverride::On));

	// Laguna would ideally pause for PERST, then for RX_EIDLE_EXIT, then Exit L23

	// TODO : PAUSE or LOOP for PERST# deassertion (nice DFX)

	// Wait for L0
	AddCycle(new PauseVector(
	    PauseVector::PauseType::PauseNone, PauseVector::PmPauseType::PmPauseNone, PauseVector::PmPauseType2::L0));

	// asserts xmit_pme (this is used by SNPS to trigger wake, but Cambria is in Bypass and drives Wake directly)
	AddCycle(new PMVector(PMVector::Command::ExitL2L3, LockBit::On, BusMasterOverride::On));

	// Release superlock
	AddCycle(new PciPmSuperLock(false));

	// Insert PME messaging loops
	_DoPmeMessaging();

	// Block completions in ASPM/PCIPM
	// pmctrl3.UCW = 0;
	// AddCycle(new IntAccessWriteReg(PMCTRL3::mmio_offset() + 0x2000, pmctrl3.val, 0xD, LockBit::On));

	// Insert dummy vector with end status bit -- we're done!
	AddCycle(new DummyVector(0x12345678, LockBit::Off, EndBit::On));
}
