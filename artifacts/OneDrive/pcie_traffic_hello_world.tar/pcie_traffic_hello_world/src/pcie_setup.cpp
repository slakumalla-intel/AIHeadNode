#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <ctype.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <limits.h>
#include <dirent.h>
#include <errno.h>

//#include "pcie_setup.h"
#include "abstract.h"

#define ABSTRACT_PCI_DEBUG 1
#define PAGE_PRESENT	(1ULL << 63)
#define PFN_MASK	((1ULL << 54) - 1)

/*
 * Example of how to read/write or mmap PCI device config or resources
 * See: https://www.kernel.org/doc/html/latest/PCI/sysfs-pci.html
 */

typedef struct acpi_mcfg_config {
	uint64_t	base_address;
	uint16_t	pci_segment_group;
	uint8_t		start_bus;
	uint8_t		end_bus;
	uint8_t		reserved[4];
} __attribute__ ((packed)) acpi_mcfg_config_t;

typedef struct acpi_mcfg {
	char		signature[4];
	uint32_t	length;
	uint8_t		revision;
	uint8_t		checksum;
	char		oem_id[6];
	char		oem_table_id[8];
	uint32_t	oem_revision;
	char		creator_id[4];
	uint32_t	creator_revision;
	uint64_t	reserved;
	//acpi_mcfg_config_t config[0];
} __attribute__ ((packed)) acpi_mcfg_t;


static uint64_t pci_config_addr_min = ~(uint64_t)0;
static uint64_t pci_config_addr_max = (uint64_t)0;
static abstract_pci_info_t *abstract_pci_info_list_head = NULL;
static abstract_pci_info_t *abstract_pci_info_list_tail = NULL;

uint64_t abstract_virt_to_phys(const void *addr)
{
	off_t pm_offset;
	uint64_t pageinfo;
	ssize_t n;
	const uint64_t page_size = 4096;
	const uint64_t page_mask = (page_size - 1);
	const uint64_t virt_addr = (uintptr_t)addr;
	uint64_t phys_addr = 0ULL;
	int fd_mem = -1, fd_pm = -1;

	fd_mem = open("/dev/mem", O_RDWR | O_SYNC);
	if (fd_mem < 0) {
		fprintf(stderr, "%s: cannot open /proc/self/pagemap, errno=%d (%s)\n",
			__func__, errno, strerror(errno));
		goto err;
	}

	fd_pm = open("/proc/self/pagemap", O_RDONLY);
	if (fd_pm < 0) {
		fprintf(stderr, "%s: cannot open /proc/self/pagemap, errno=%d (%s)\n",
			__func__, errno, strerror(errno));
		goto err;
	}

	pm_offset = (off_t)((virt_addr / page_size) * sizeof(uint64_t));
	if (lseek(fd_pm, pm_offset, SEEK_SET) != pm_offset) {
		fprintf(stderr, "%s: cannot seek on address %p in /proc/self/pagemap, errno=%d (%s)\n",
			__func__, (void *)virt_addr, errno, strerror(errno));
		goto err;
	}
	n = read(fd_pm, &pageinfo, sizeof(pageinfo));
	if (n < 0) {
		fprintf(stderr, "%s: cannot read address %p in /proc/self/pagemap, errno=%d (%s)\n",
			__func__, (void *)virt_addr, errno, strerror(errno));
		goto err;
	} else if (n != (ssize_t)sizeof(pageinfo)) {
		fprintf(stderr, "%s: read address %p in /proc/self/pagemap returned %zd bytes, expected %zd\n",
			__func__, (void *)virt_addr, (size_t)n, sizeof(pageinfo));
		goto err;
	}

	if (pageinfo & PAGE_PRESENT) {
		const uint64_t pfn = pageinfo & PFN_MASK;

		phys_addr = pfn * page_size;
		phys_addr |= (virt_addr & page_mask);
	} else {
		fprintf(stderr, "%s: page not present (not physically backed)\n", __func__);
	}
err:
	if (fd_pm >= 0)
		(void)close(fd_pm);
	if (fd_mem >= 0)
		(void)close(fd_mem);
	return phys_addr;
}

void *abstract_pci_mmap_phys(const char *file, off_t offset, const size_t sz, bool writable)
{
	void *ptr;
	int fd, mode, prot;
	off_t lret;

	if (writable) {
		mode = O_RDWR;
		prot = PROT_READ | PROT_WRITE;
	} else {
		mode = O_RDONLY;
		prot = PROT_READ;
	}

	fd = open(file, mode | O_LARGEFILE);
	if (fd < 0)
		return NULL;

	lret = lseek(fd, offset, SEEK_SET);
	if (lret != offset)
		fprintf(stderr, "Cannot seek to offset %p, errno=%d (%s)\n", (void *)offset, errno, strerror(errno));
	ptr = mmap(NULL, sz, prot, MAP_SHARED, fd, offset);
	if (ptr != MAP_FAILED) {
		(void)close(fd);
		return ptr;
	}
	fprintf(stderr, "%s: mmap failed, errno=%d (%s)\n", __func__, errno, strerror(errno));
	(void)close(fd);
	return NULL;
}

static void abstract_pci_config_info(abstract_pci_info_t *pi, const char *name)
{
	char path[PATH_MAX];
	struct stat statbuf;

	(void)snprintf(path, sizeof(path), "%s/%s", pi->path, name);
	if (stat(path, &statbuf) < 0)
		return;
	if (statbuf.st_size == 0)
		return;
	pi->cfg.size = statbuf.st_size;
}

static void abstract_pci_resource_info(abstract_pci_info_t *pi, const char *name)
{
	char path[PATH_MAX];
	char buffer[1024];
	FILE *fp;
	int index = 0;

	(void)snprintf(path, sizeof(path), "%s/%s", pi->path, name);

	fp = fopen(path, "r");
	if (!fp) {
		fprintf(stderr, "cannot open %s\n", path);
		return;
	}
	while (fgets(buffer, sizeof(buffer), fp) != NULL && index < MAX_BARS) {
		uintptr_t begin, end;
		size_t size;
		uint64_t mode;
		int n;

		n = sscanf(buffer, "%" SCNxPTR " %" SCNxPTR " %" SCNx64, &begin, &end, &mode);
		if (n != 3)
			goto next;
		if ((begin != 0) && (end != 0)) {
			void *virt;

			size = (size_t)(1 + end - begin);
#if ABSTRACT_PCI_DEBUG
			(void)fprintf(stderr, "  %s%d: (length 0x%zx)\n", name, index, size);
#endif

			pi->bar[index].size = (uint64_t)size;
			pi->bar[index].phys_addr = (uint64_t) begin;

			virt = abstract_pci_mmap_phys("/dev/mem", (off_t)begin, size, true);
			if (virt) {
				pi->bar[index].writable = true;
			} else {
				virt = abstract_pci_mmap_phys("/dev/mem", (off_t)begin, size, false);
			}
			pi->bar[index].virt_addr = virt;
			pi->bar[index].virt_addr_uc = virt;

#if ABSTRACT_PCI_DEBUG
			(void)fprintf(stderr, "    PHYS: 0x%16.16" PRIxPTR "-0x%16.16" PRIxPTR "\n",
				begin, end);
			(void)fprintf(stderr, "    VIRT: 0x%16.16" PRIxPTR "-0x%16.16" PRIxPTR " %s\n",
				(uint64_t)virt, (uint64_t)virt + size,
				pi->bar[index].writable ? "wr" : "rd");
#endif
		}
next:
		index++;
	}
	(void)fclose(fp);
}

/*
 *  abstract_pci_exercise()
 *	abstract_exercise all PCI files in a given PCI info path
 */
void abstract_pci_mmap(abstract_pci_info_t *pi)
{
	int i, n;
    bool config_loaded = false;
    bool resource_loaded = false;
	struct dirent **list = NULL;
	char *pi_path = strdup(pi->path);

	n = scandir(pi_path, &list, NULL, alphasort);
#if ABSTRACT_PCI_DEBUG
	fprintf(stderr, "Device %4.4" PRIx16 ":%4.4" PRIx16 " cfg:%" PRIx64 " %s\n",
		pi->vendor_id, pi->device_id, pi->cfg.phys_addr, pi->path);
#endif
	for (i = 0; i < n; i++) {
        if (config_loaded && resource_loaded)   // TODO: Remove this check and free all dirent
            break;
        
		char *name = list[i]->d_name;
		if (strcmp(name, "config") == 0) {
			abstract_pci_config_info(pi, name);
            config_loaded = true;
        }
		else if (strcmp(name, "resource") == 0) {
			abstract_pci_resource_info(pi, name);
            resource_loaded = true;
        }
        free(list[i]);
	}
#if ABSTRACT_PCI_DEBUG
	fprintf(stderr, "\n");
#endif
	free(list);
}

static uint64_t abstract_pci_get_config_address(const uint8_t bus, const uint8_t dev, const uint8_t func)
{
	int fd;
	uint64_t addr = 0;
	ssize_t ret;
	char buf[65536];
	acpi_mcfg_t *mcfg = (acpi_mcfg_t *)buf;
	acpi_mcfg_config_t *config;
	size_t min_size = sizeof(acpi_mcfg_t) + sizeof(acpi_mcfg_config_t);
	int i, n;

	fd = open("/sys/firmware/acpi/tables/MCFG", O_RDONLY);
	if (fd < 0)
		return addr;
	ret = read(fd, buf, sizeof(buf));
	if (ret < (ssize_t)min_size)
		return addr;
	(void)close(fd);

	n = (ret - sizeof(acpi_mcfg_t)) / sizeof(acpi_mcfg_config_t);
	config = (acpi_mcfg_config_t *)(buf + sizeof(* mcfg));
	for (i = 0; i < n; i++, config++) {
		//fprintf(stderr, "PCI MMCONFIG @ %p\n", (void *)config->base_address);
		//fprintf(stderr, "BUS %x BUS RANGE: %x .. %x\n", bus, config->start_bus, config->end_bus);

		if ((config->start_bus <= bus) && (bus <= config->end_bus)) {
			addr = config->base_address +
			       (((uint64_t)(bus - config->start_bus)) << 20) +
			       (((uint64_t)dev) << 15) +
			       (((uint64_t)func) << 12);

			if (pci_config_addr_min > addr)
				pci_config_addr_min = addr;
			if (pci_config_addr_max < addr + 4096)
				pci_config_addr_max = addr + 4096;
			return addr;
		}
	}
	return 0;
}

static uint16_t abstract_pci_info_get_id(const char *path, const char *id_name)
{
	char name[PATH_MAX + 64];
	FILE *fp;
	uint16_t id;

	(void)snprintf(name, sizeof(name), "%s/%s", path, id_name);
	fp = fopen(name, "r");
	if (!fp) {
		id = 0xffff;
		goto err;
	}
	if (fscanf(fp, "%" SCNx16, &id) != 1)
		id = 0xffff;
	(void)fclose(fp);
err:
	return id;

}

/*
 *  abstract_pci_filter()
 *	scandir filter on /sys/devices/pci[0-9]*
 */
static int abstract_pci_filter(const struct dirent *d)
{
	if (strlen(d->d_name) < 4)
		return 0;
	if (strncmp(d->d_name, "pci", 3))
		return 0;
	if (isdigit((int)d->d_name[3]))
		return 1;
	return 0;
}

/*
 *  abstract_pci_dev_filter()
 *	scandir filter on /sys/devicex/pci[0-9]/xxxx:xx:xx.x where x is a hex
 */
static int abstract_pci_dev_filter(const struct dirent *d)
{
	unsigned int dummy[4];

	/* Check it meets format 0000:00:00.0 */
	if (sscanf(d->d_name, "%x:%x:%x.%x",
		&dummy[0], &dummy[1], &dummy[2], &dummy[3]) == 4)
		return 1;
	return 0;
}

/*
 *  abstract_pci_info_get()
 *	get a list of PCI device paths of pci_info items
 */
abstract_pci_info_t *abstract_pci_info_get(const uint16_t vendor_id, const uint16_t device_id)
{
	struct dirent **list = NULL;
	static const char sys_devices[] = "/sys/devices";
	int i, n;

	n = scandir(sys_devices, &list, abstract_pci_filter, alphasort);
	for (i = 0; i < n; i++) {
		int j, n_devs;
		char path[PATH_MAX];
		struct dirent **pci_list = NULL;

		(void)memset(path, 0, sizeof(path));
		(void)snprintf(path, sizeof(path), "%s/%s", sys_devices, list[i]->d_name);
		n_devs = scandir(path, &pci_list, abstract_pci_dev_filter, alphasort);
		for (j = 0; j < n_devs; j++) {
			int k, n_child_devs;
            char pci_path[PATH_MAX];
            struct dirent **pci_child_list = NULL;
			
            (void)memset(pci_path, 0, sizeof(pci_path));
			(void)snprintf(pci_path, sizeof(pci_path),
				"%s/%s/%s", sys_devices,
				list[i]->d_name, pci_list[j]->d_name);
            n_child_devs = scandir(pci_path, &pci_child_list, abstract_pci_dev_filter, alphasort);
            for (k = 0; k < n_child_devs; k++) {    // Adding one more step down /sys/devices tree to find test card
                char pci_child_path[PATH_MAX];
                abstract_pci_info_t *pi;

                (void)snprintf(pci_child_path, sizeof(pci_child_path),
				"%s/%s/%s/%s", sys_devices,
				list[i]->d_name, pci_list[j]->d_name, pci_child_list[k]->d_name);

                if (abstract_pci_info_get_id(pci_child_path, "vendor") != vendor_id)
                    continue;
                if (abstract_pci_info_get_id(pci_child_path, "device") != device_id)
                    continue;

                pi = (abstract_pci_info_t *)calloc(1, sizeof(*pi));
                if (pi) {
                    int n;
                    uint64_t config_address;
                    uint16_t domain;
                    uint8_t bus, dev, func;
                    char config_path[PATH_MAX + 16];

                    n = sscanf(pci_child_list[k]->d_name, "%" SCNx16 ":%" SCNx8 ":%" SCNx8 ".%" SCNx8,
                        &domain, &bus, &dev, &func);
                    if (n != 4) {
                        free(pi);
                        continue;
                    }

                    pi->path = strdup(pci_child_path);
                    if (!pi->path) {
                        free(pi);
                        continue;
                    }
                    (void)snprintf(config_path, sizeof(config_path), "%s/config", pci_child_path);
                    pi->config_path = strdup(config_path);
                    if (!pi->config_path) {
                        free(pi->path);
                        free(pi);
                        continue;
                    }
                    config_address = abstract_pci_get_config_address(bus, dev, func);

                    pi->vendor_id = vendor_id;
                    pi->device_id = device_id;
                    pi->cfg.phys_addr = config_address;
                    pi->cfg.virt_addr = (void *)config_address;
                    pi->cfg.virt_addr_uc = (void *)config_address;
                    pi->cfg_bus = bus;
                    pi->cfg_dev = dev;
                    pi->cfg_func = func;

                    abstract_pci_mmap(pi);

                    if (abstract_pci_info_list_head)
                        abstract_pci_info_list_tail->next = pi;
                    else
                        abstract_pci_info_list_head = pi;
                    abstract_pci_info_list_tail = pi;
                }
                free(pci_child_list[k]);
			}
            free(pci_child_list);
			free(pci_list[j]);
		}
		free(pci_list);
		free(list[i]);
	}
	free(list);

	return abstract_pci_info_list_head;
}

void print_pcie_info(abstract_pci_info_t *pcie_info) {

	printf("PCI path:                  %s\n", pcie_info->path);
	printf("Config path:               %s\n", pcie_info->config_path);
	printf("Vendor ID:                 %x\n", pcie_info->vendor_id);
	printf("Device ID:                 %x\n", pcie_info->device_id);
	printf("Config bus:                %x\n", pcie_info->cfg_bus);
	printf("Config dev:                %x\n", pcie_info->cfg_dev);
	printf("Config func:               %x\n", pcie_info->cfg_func);
	printf("Config space writable:     %u\n",  pcie_info->cfg.writable);
	printf("Config space size:         %u\n",  pcie_info->cfg.size);
	printf("Config space phys address: %lx\n", pcie_info->cfg.phys_addr);
	printf("Config space virt_addr_uc: %lx\n", pcie_info->cfg.virt_addr_uc);
	printf("Config space virt_addr:    %lx\n", pcie_info->cfg.virt_addr);
	printf("\n");

	for (int i = 0; i < MAX_BARS; i++) {
		if (!pcie_info->bar[i].phys_addr) {
			printf("BAR%d unavailable\n\n", i);
			continue;
		}
		printf("BAR%d space writable:     %u\n", i, pcie_info->bar[i].writable);
		printf("BAR%d space size:         %u\n", i, pcie_info->bar[i].size);
		printf("BAR%d space phys address: %lx\n", i, pcie_info->bar[i].phys_addr);
		printf("BAR%d space virt_addr_uc: %lx\n", i, pcie_info->bar[i].virt_addr_uc);
		printf("BAR%d space virt_addr:    %lx\n", i, pcie_info->bar[i].virt_addr);
		printf("\n");
	}

	printf("next...: %x\n", pcie_info->next);
	return;
}

