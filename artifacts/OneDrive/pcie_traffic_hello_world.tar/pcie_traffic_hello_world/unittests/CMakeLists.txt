set(SOURCES
  Main.cpp
  CambriaDataGen.cpp
  )

add_sv_unittest(
    name cambria_datagen_tests
    SOURCES ${SOURCES}
    )
target_link_libraries(cambria_datagen_tests PRIVATE randlib cambria_datagen)

file(COPY traffic_vectors aspml1_vectors pcipml1_vectors retrig_vectors pcipml23_vectors DESTINATION ${CMAKE_CURRENT_BINARY_DIR})
file(COPY BlingTestData.bl2 BlingFileList.txt DESTINATION ${CMAKE_CURRENT_BINARY_DIR})
