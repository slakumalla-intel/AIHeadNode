/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2021 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details     Tests for the Cambria Data Generator
#include <gtest/gtest.h>
#include <filesystem>
#include <fstream>
#include "cambria-datagen/datagen.h"

using namespace maestro;
using namespace maestro::cambria;

namespace
{
/// This function gets the execution path
std::filesystem::path GetExecutablePath()
{
	struct stat s;
	if (stat("/proc/self/exe", &s) == 0) {
		std::vector<char> buffer(s.st_size);
		if (readlink("/proc/self/exe", buffer.data(), buffer.size()) >= 0) {
			return buffer.data();
		} else {
			std::cerr << "[ERROR] failed to readlink '/proc/self/exe': " << strerror(errno) << "\n";
		}
	} else {
		std::cerr << "[ERROR] could not stat '/proc/self/exe': " << strerror(errno) << "\n";
	}
	std::cerr << "[ERROR] Failed to get executable path\n";
	std::exit(-1);
}

void ReadVectorFile(const std::string &filename, std::vector<uint32_t> &expected)
{
	const std::filesystem::path executableDirectory = GetExecutablePath().parent_path();
	const std::filesystem::path vectorsFile = executableDirectory / filename;
	std::ifstream inFile(vectorsFile);
	if (not inFile.fail() && inFile.is_open()) {
		for (std::string line; getline(inFile, line);) {
			std::istringstream iss(line);
			uint32_t n;
			while (iss >> std::hex >> n) {
				expected.push_back(n);
			}
		}
	} else {
		std::cerr << "[ERROR] Can't open the file containing vectors; expecting: " << vectorsFile
		          << "\nError code: " << strerror(errno) << "\n";
		std::exit(-1);
	}

	if (expected.size() % 4) {
		std::cerr << "[ERROR] Badly formed vector file: " << vectorsFile
		          << "\nExpected data should to be a multiple of 4.  Found: " << expected.size() << "\n";
		std::exit(-1);
	}
}

bool CheckVectors(std::vector<uint32_t> &expected, std::vector<uint32_t> &actual)
{
	bool retval = true;
	if (expected.size() != actual.size()) {
		std::cerr << std::dec << "[ERROR] Size of Actual(" << actual.size() << ")/Expected(" << expected.size()
		          << ") do not match" << std::endl;
		retval = false;
	}

	unsigned mismatches = 0;
	size_t smallest = expected.size() < actual.size() ? expected.size() : actual.size();
	for (size_t offset = 0; offset < smallest; offset += 4) {
		bool mismatch = false;
		std::cerr << "Offset " << std::hex << std::setfill('0') << std::internal << std::setw(3) << offset << ":"
		          << std::endl;
		std::cerr << "Expected: ";
		for (size_t dword = offset; dword < offset + 4; dword++) {
			std::cerr << std::setw(8) << expected[dword] << " ";
		}
		std::cerr << std::endl << "Actual:   ";
		for (size_t dword = offset; dword < offset + 4; dword++) {
			std::cerr << std::setw(8) << actual[dword] << " ";
			if (expected[dword] != actual[dword]) {
				mismatch = true;
			}
		}
		if (mismatch) {
			mismatches++;
			std::cerr << "MISMATCH";
		}
		std::cerr << std::endl;
	}
	std::cerr << std::dec << "[ERROR] Detected " << mismatches << " vectors mismatched" << std::endl;
	if (mismatches) {
		retval = false;
	}
	return retval;
}

void _createPause(TrafficStream &traffic)
{
	traffic.AddCycle(new PauseVector(PauseVector::PauseType::ExtFlagWrite,
	    PauseVector::PmPauseType::PmTurnOffMsgTlpRcvdInD3, PauseVector::PmPauseType2::RecoveryEntry));
}
void _createLoops(TrafficStream &traffic)
{
	traffic.AddCycle(new LoopStart(100));
	traffic.AddCycle(new LoopEnd());
	traffic.AddCycle(new SinglePollLoopStart());
	traffic.AddCycle(new SinglePollLoopEnd());
}
void _createInternalAccess(TrafficStream &traffic)
{
	InternalAccess *ia = static_cast<InternalAccess *>(traffic.AddCycle(new InternalAccess()));
	ia->SetCmd(InternalAccess::Command::WriteToEVFromLocalSticky);
	ia->ProgramCommandA(0xa4a4, 0xcccccccc, 0xd);
	ia->ProgramCommandB(0xb8b8, 0xdddddddd, 0xe);
	ia = static_cast<InternalAccess *>(traffic.AddCycle(new InternalAccess()));
	ia->SetCmd(InternalAccess::Command::WriteToEVFromLocalSticky);
	ia->ProgramCommandA(0xa4a4, 0xcccccccc, 0xd, LockBit::On, Retrigger::On, EndBit::On);
	ia->ProgramCommandB(0xb8b8, 0xdddddddd, 0xe, LockBit::On, Retrigger::On, EndBit::On);
	traffic.AddCycle(new DummyVector(0x12345678));
	traffic.AddCycle(new IntAccessWriteReg(0x1414, 0x87654321, 0x9));
	traffic.AddCycle(new SetRegisterBits(0x3838, 0xFF0000FF));
	traffic.AddCycle(new SetRegisterBit(0x5c5c, 5));
	traffic.AddCycle(new ClearRegisterBit(0x7474, 8));
	traffic.AddCycle(new ReadCfgToSticky(0x9898, 0, LockBit::Off));
	traffic.AddCycle(new WriteCfgFromSticky(0x1818, 0, LockBit::On));
	traffic.AddCycle(new PollSingle(InternalAccess::SinglePollType::PMETurnOff));
	traffic.AddCycle(new PollSingleLocalSticky(0xdeadbeef, 0xffffffff));
}
void _createDelay(TrafficStream &traffic)
{
	traffic.AddCycle(new DelayVector(0xabcd, Granularity::_1usPerTick, 0x4321));
}
void _createUpperAddress(TrafficStream &traffic)
{
	UpperAddressVector *ua = static_cast<UpperAddressVector *>(traffic.AddCycle(new UpperAddressVector()));
	ua->SetHighAddress(0xAAAAAAAA);
	ua->SetPostedTag(0x11);
	ua->SetNoDataCompare();
	ua->SetBusNum(1);
	ua->SetDeviceNum(2);
	ua->SetFunctionNum(3);
	ua->SetTlErrorType(UpperAddressVector::TransactionError::TdInverted);
	ua->SetTlSideband(0x333);
}
void _createPM(TrafficStream &traffic)
{
	PMVector *pm = static_cast<PMVector *>(traffic.AddCycle(new PMVector(PMVector::Command::ExitL1)));
	pm->SetBusMasterOverride();
	traffic.AddCycle(new AspmSuperLock(true));
	traffic.AddCycle(new AspmSuperLock(false));
	traffic.AddCycle(new GenericSuperLock(true));
	traffic.AddCycle(new GenericSuperLock(false));
	traffic.AddCycle(new PciPmSuperLock(true));
	traffic.AddCycle(new PciPmSuperLock(false));
}
void _createMem(TrafficStream &traffic)
{
	traffic.AddCycle(new MemReadVector(0x0));
	MemReadVector *read = static_cast<MemReadVector *>(traffic.AddCycle(new MemReadVector(0x112)));
	read->SetLowAddress(0xBBBBBBBC);
	read->Set64BitAddress();
	MemWriteVector *write = static_cast<MemWriteVector *>(traffic.AddCycle(new MemWriteVector(0x400)));
	write->SetAddress(0xDDDDDDDDCCCCCCCC);
}
void _createAtomics(TrafficStream &traffic)
{
	traffic.AddCycle(new AtomicVector(
	    AtomicOpType::FetchAdd, 0x1, AtomicData(0x11111111, 0x22222222), AtomicData(0x33333333, 0x44444444)));
	traffic.AddCycle(new AtomicVector(
	    AtomicOpType::Swap, 0x2, AtomicData(0x55555555, 0x66666666), AtomicData(0x77777777, 0x88888888)));
	traffic.AddCycle(new AtomicVector(
	    AtomicOpType::CAS, 0x4, AtomicData(0x99999999, 0xaaaaaaaa), AtomicData(0xbbbbbbbb, 0xcccccccc)));
}
void _createIO(TrafficStream &traffic)
{
	traffic.AddCycle(new IoReadVector());
	traffic.AddCycle(new IoWriteVector());
}
void _createCfg(TrafficStream &traffic)
{
	traffic.AddCycle(new ConfigReadVector(0x1, 0x2, 0x3, 0x0a0));
	traffic.AddCycle(new ConfigWriteVector(0x4, 0x5, 0x6, 0xb0b));
}
void _createMessage(TrafficStream &traffic)
{
	traffic.AddCycle(new MessageVector(MsgCode::PowerIndicatorOn, MsgRoute::Local));
	traffic.AddCycle(new LtrMessageVector(0xaabbccdd));
	traffic.AddCycle(new MctpMessageVector(MsgRoute::RootComplex));
}

bool Traffic()
{
	TrafficStream traffic(0x200);

	_createPause(traffic);
	_createLoops(traffic);
	_createInternalAccess(traffic);
	_createDelay(traffic);
	_createUpperAddress(traffic);
	_createPM(traffic);
	_createMem(traffic);
	_createAtomics(traffic);
	_createIO(traffic);
	_createCfg(traffic);
	_createMessage(traffic);

	traffic.Generate();

	std::vector<uint32_t> expected;
	ReadVectorFile("traffic_vectors", expected);

	std::vector<uint32_t> actual(traffic.VectorCount() * 4, 0);
	traffic.Serialize(actual.data());

	return CheckVectors(expected, actual);
}

bool AspmL1()
{
	ActiveL1TransitionEvent event(0, 0x100);
	event.SetVmNumber(3);
	event.SetStreamNumber(0);
	event.SetTrafficVM(0);
	event.SetTrafficStream(0);

	event.SetGuaranteedHostExit(false);
	event.SetGuaranteedDevExit(false);
	event.SetExitFromAspmL1Timer(true);
	event.SetExitTimerPauseCount(2);
	event.SetExitTimerPauseGran(Granularity::_1usPerTick);

	event.Generate();

	std::vector<uint32_t> expected;
	ReadVectorFile("aspml1_vectors", expected);

	std::vector<uint32_t> actual(event.VectorCount() * 4, 0);
	event.Serialize(actual.data());

	return CheckVectors(expected, actual);
}

bool PciPmL1()
{
	PciPmL1TransitionEvent event(0x100);

	event.StallL1DStatePauseCount(3);
	event.StallL1DStatePauseGran(Granularity::_1usPerTick);
	event.PmeTimerPauseCount(4);
	event.PmeTimerPauseGran(Granularity::_1msPerTick);
	event.PmeResendTimerPauseCount(5);
	event.PmeResendTimerPauseGran(Granularity::_1secPerTick);

	event.Generate();

	std::vector<uint32_t> expected;
	ReadVectorFile("pcipml1_vectors", expected);

	std::vector<uint32_t> actual(event.VectorCount() * 4, 0);
	event.Serialize(actual.data());

	return CheckVectors(expected, actual);
}

bool PciPmL1Retrig()
{
	PciPmL1RetrigEvent event(0x100);

	event.StallL1DStatePauseCount(3);
	event.StallL1DStatePauseGran(Granularity::_1usPerTick);
	event.PmeTimerPauseCount(4);
	event.PmeTimerPauseGran(Granularity::_1msPerTick);
	event.PmeResendTimerPauseCount(5);
	event.PmeResendTimerPauseGran(Granularity::_1secPerTick);

	event.Generate();

	std::vector<uint32_t> expected;
	ReadVectorFile("retrig_vectors", expected);

	std::vector<uint32_t> actual(event.VectorCount() * 4, 0);
	event.Serialize(actual.data());

	return CheckVectors(expected, actual);
}

bool PciPmL23()
{
	PciPmL23TransitionEvent event(0x100);

	event.StallL23DStatePauseCount(6);
	event.StallL23DStatePauseGran(Granularity::_1usPerTick);
	event.WakeTimerPauseCount(7);
	event.WakeTimerPauseGran(Granularity::_1msPerTick);
	event.PmeResendTimerPauseCount(8);
	event.PmeResendTimerPauseGran(Granularity::_1secPerTick);

	event.Generate();

	std::vector<uint32_t> expected;
	ReadVectorFile("pcipml23_vectors", expected);

	std::vector<uint32_t> actual(event.VectorCount() * 4, 0);
	event.Serialize(actual.data());

	return CheckVectors(expected, actual);
}

bool TooSmall()
{
	TrafficStream traffic(1);

	if (!traffic.AddCycle(new DelayVector(0))) {
		std::cerr << "[ERROR] Unable to add first cycle\n";
		return false;
	}

	if (traffic.AddCycle(new DelayVector(0))) {
		std::cerr << "[ERROR] Able to overrun max vectors\n";
		return false;
	}

	return true;
}
} // namespace

TEST(CambriaDataGen, Traffic) { EXPECT_TRUE(Traffic()); }

TEST(CambriaDataGen, AspmL1) { EXPECT_TRUE(AspmL1()); }

TEST(CambriaDataGen, PciPmL1) { EXPECT_TRUE(PciPmL1()); }

TEST(CambriaDataGen, PciPmL1Retrig) { EXPECT_TRUE(PciPmL1Retrig()); }

TEST(CambriaDataGen, PciPmL23) { EXPECT_TRUE(PciPmL23()); }

TEST(CambriaDataGen, TooSmall) { EXPECT_TRUE(TooSmall()); }
