/******************************************************************************
 * INTEL CONFIDENTIAL
 * Copyright 2013-2020 Intel Corporation All Rights Reserved.
 *
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation or its
 * suppliers or licensors. Title to the Material remains with Intel Corporation
 * or its suppliers and licensors. The Material may contain trade secrets and
 * proprietary and confidential information of Intel Corporation and its
 * suppliers and licensors, and is protected by worldwide copyright and trade
 * secret laws and treaty provisions. No part of the Material may be used,
 * copied, reproduced, modified, published, uploaded, posted, transmitted,
 * distributed, or disclosed in any way without Intel's prior express written
 * permission.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery
 * of the Materials, either expressly, by implication, inducement, estoppel or
 * otherwise. Any license under such intellectual property rights must be
 * express and approved by Intel in writing.
 *
 * Include supplier trademarks or logos as supplier requires Intel to use,
 * proceeded by an asterisk. An asterisked footnote can be added as follows:
 * Third Party trademarks are the property of their respective owners.
 * Unless otherwise agreed by Intel in writing, you may not remove or alter
 * this notice or any other notice embedded in Materials by Intel or Intel's
 * suppliers or licensors in any way.
 *****************************************************************************/
/// \details     Test Cambria datagen
#include <gtest/gtest.h>
#include "randlib/RandStream.h"

int main(int argc, char **argv)
{
	// We hardcode the fixed-substream-seed flag here so that the RandStreams are always deterministic
	maestro::RandomSeedManager::Get().AssignSeeds(0);
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
